import { describe, expect, it } from 'vitest';
import { Outbox, SendError, displayState, type KV, type OutboxItem } from '../client/src/lib/outbox';

function memKV(): KV & { data: Map<string, string> } {
  const data = new Map<string, string>();
  return { data, get: (k) => data.get(k) ?? null, set: (k, v) => (data.set(k, v), true) };
}

/** Fake server that is idempotent on client ID, like the real API. */
function fakeServer() {
  const received = new Map<string, { id: string; receivedAt: string }>();
  let online = true;
  let n = 0;
  return {
    received,
    setOnline: (v: boolean) => (online = v),
    send: async (item: OutboxItem) => {
      if (!online) throw new SendError('No connection', false);
      const dup = received.get(item.id);
      if (dup) return { ...dup, ref: 'HC-dup', duplicateSubmission: true };
      const rec = { id: `inc-${++n}`, receivedAt: new Date(Date.parse(item.createdLocalAt) + 120_000).toISOString() };
      received.set(item.id, rec);
      return { ...rec, ref: `HC-${n}`, duplicateSubmission: false };
    },
  };
}

const add = (box: Outbox) => box.add({ kind: 'incident', eventId: 'e', userId: 'u', payload: { description: 'x' } });

describe('offline outbox', () => {
  it('keeps reports queued and NOT delivered while offline', async () => {
    const srv = fakeServer();
    srv.setOnline(false);
    const box = new Outbox(memKV(), srv.send);
    add(box);
    await box.flush();
    const [it0] = box.list();
    expect(it0.state).toBe('failed');
    expect(it0.serverReceivedAt).toBeNull();
    expect(it0.lastError).toMatch(/No connection/);
    expect(srv.received.size).toBe(0);
  });

  it('delivers when connectivity returns, keeping local and server timestamps distinct', async () => {
    const srv = fakeServer();
    srv.setOnline(false);
    const box = new Outbox(memKV(), srv.send);
    add(box);
    await box.flush();
    srv.setOnline(true);
    await box.flush();
    const [it0] = box.list();
    expect(it0.state).toBe('delivered');
    expect(it0.serverReceivedAt).not.toBe(it0.createdLocalAt);
    expect(it0.serverRef).toBe('HC-1');
  });

  it('does not duplicate reports on retry or concurrent flushes', async () => {
    const srv = fakeServer();
    const box = new Outbox(memKV(), srv.send);
    add(box);
    add(box);
    await Promise.all([box.flush(), box.flush(), box.flush()]);
    expect(srv.received.size).toBe(2);
    // Simulate a lost response: item delivered server-side but still pending locally.
    const items = box.list();
    (box as any).save(items.map((i) => ({ ...i, state: 'failed' })));
    await box.flush();
    expect(srv.received.size).toBe(2);
    expect(box.list().every((i) => i.state === 'delivered' && i.duplicateSubmission)).toBe(true);
  });

  it('can flush again after an empty flush (regression: stale in-flight promise)', async () => {
    const srv = fakeServer();
    const box = new Outbox(memKV(), srv.send);
    await box.flush(); // empty queue
    add(box);
    await box.flush();
    expect(box.list()[0].state).toBe('delivered');
  });

  it('marks server-rejected reports as rejected and does not retry them', async () => {
    let calls = 0;
    const box = new Outbox(memKV(), async () => {
      calls++;
      throw new SendError('description: too short', true);
    });
    add(box);
    await box.flush();
    await box.flush();
    expect(box.list()[0].state).toBe('rejected');
    expect(calls).toBe(1);
  });

  it('shows the four user-facing states and the last successful sync', async () => {
    const srv = fakeServer();
    srv.setOnline(false);
    const box = new Outbox(memKV(), srv.send);
    add(box);
    expect(displayState(box.list()[0])).toBe('saved');
    await box.flush();
    expect(displayState(box.list()[0])).toBe('waiting');
    await box.flush();
    await box.flush();
    expect(displayState(box.list()[0])).toBe('action'); // 3 failed attempts → needs attention
    expect(box.lastSyncAt()).toBeNull();
    srv.setOnline(true);
    await box.flush();
    expect(displayState(box.list()[0])).toBe('confirmed');
    expect(box.lastSyncAt()).not.toBeNull();
  });

  it('survives corrupt storage', () => {
    const kv = memKV();
    kv.data.set('hc.outbox.v1', '{not json');
    expect(new Outbox(kv, async () => ({ id: '', ref: null, receivedAt: '', duplicateSubmission: false })).list()).toEqual([]);
  });
});
