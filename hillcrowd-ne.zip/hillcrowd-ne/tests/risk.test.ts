import { describe, expect, it } from 'vitest';
import { assessZone, type RiskInputs } from '../shared/risk';
import { DEFAULT_SETTINGS } from '../shared/constants';
import type { Facility, Incident, RouteNode, RouteSegment, Zone } from '../shared/types';

const NOW = new Date('2026-10-15T10:00:00Z');
const minsAgo = (m: number) => new Date(NOW.getTime() - m * 60_000).toISOString();

const zone: Zone = { id: 'z', eventId: 'e', name: 'Z', polygon: [], capacity: 1000, watchPct: 80, elevatedPct: 95, criticalPct: 110, requiredExitIds: ['ex1'], exitIds: ['ex1', 'ex2'], notes: '', commsFallback: '' };
const fac = (id: string, kind: Facility['kind'], nodeId: string, status: Facility['status'] = 'open'): Facility => ({
  id, eventId: 'e', kind, name: id, lat: 0, lng: 0, zoneId: null, nodeId, status, statusReason: null, statusUpdatedAt: minsAgo(1), capacityPerMin: null, notes: '',
});
const nodes: RouteNode[] = ['n1', 'n2', 'nap'].map((id) => ({ id, eventId: 'e', name: id, lat: 0, lng: 0, facilityId: null }));
const seg = (id: string, a: string, b: string): RouteSegment => ({
  id, eventId: 'e', name: id, fromNode: a, toNode: b, distanceM: 50, modes: ['foot'], access: 'public', status: 'open', statusReason: null, statusSource: null, statusUpdatedAt: minsAgo(1), approved: true, constraintNote: '', terrainNote: '', weatherExposed: false, path: [],
});
const inc = (p: Partial<Incident>): Incident => ({
  id: Math.random().toString(36), ref: 'HC-1', eventId: 'e', clientId: null, category: 'crowd_congestion', zoneId: 'z', lat: null, lng: null, description: 'x', severityEstimate: 'moderate', confirmedSeverity: null, urgent: false,
  status: 'submitted', reporterId: 'u1', ownerId: null, createdLocalAt: minsAgo(1), receivedAt: minsAgo(1), updatedAt: minsAgo(1), verifiedAt: null, assignedAt: null, acknowledgedAt: null, resolvedAt: null, closedAt: null,
  mergedInto: null, possibleDuplicateOf: [], reopenCount: 0, isDemo: false, attachmentNote: null, ...p,
});

function inputs(p: Partial<RiskInputs> = {}): RiskInputs {
  return {
    zone,
    observations: [{ id: 'o', zoneId: 'z', value: 500, observedAt: minsAgo(2), source: 'test', reportedBy: null }],
    incidents: [],
    facilities: [fac('ex1', 'exit', 'n1'), fac('ex2', 'exit', 'n2'), fac('ap', 'assembly', 'nap')],
    nodes,
    segments: [seg('s1', 'n1', 'nap'), seg('s2', 'n2', 'nap')],
    advisories: [],
    checklist: [],
    settings: DEFAULT_SETTINGS,
    now: NOW,
    ...p,
  };
}
const occ = (value: number, m = 2) => [{ id: 'o', zoneId: 'z', value, observedAt: minsAgo(m), source: 'test', reportedBy: null }];

describe('explainable risk engine', () => {
  it('is Normal with no conditions', () => {
    const r = assessZone(inputs());
    expect(r.level).toBe('normal');
    expect(r.conditions).toEqual([]);
  });

  it('applies configured occupancy thresholds with reasons', () => {
    expect(assessZone(inputs({ observations: occ(850) })).level).toBe('watch');
    expect(assessZone(inputs({ observations: occ(960) })).level).toBe('elevated');
    const crit = assessZone(inputs({ observations: occ(1150) }));
    expect(crit.level).toBe('critical');
    expect(crit.conditions[0].code).toBe('OCCUPANCY_CRITICAL');
    expect(crit.conditions[0].message).toMatch(/115%/);
    expect(crit.conditions[0].source).toBe('test');
    expect(crit.conditions[0].observedAt).toBeTruthy();
  });

  it('never treats missing occupancy as an empty (safe) zone', () => {
    const r = assessZone(inputs({ observations: [] }));
    expect(r.level).toBe('watch');
    expect(r.missingInputs).toContain('Occupancy estimate');
    expect(r.occupancy.value).toBeNull();
    expect(r.conditions[0].message).toMatch(/NOT assumed to be empty/);
  });

  it('marks stale occupancy as stale and raises a watch flag', () => {
    const r = assessZone(inputs({ observations: occ(500, 40) }));
    expect(r.occupancy.stale).toBe(true);
    expect(r.conditions.some((c) => c.code === 'OCCUPANCY_STALE' && c.stale)).toBe(true);
    expect(r.level).toBe('watch');
  });

  it('keeps a single unverified report visibly unverified (Watch, not Elevated)', () => {
    const r = assessZone(inputs({ incidents: [inc({ status: 'submitted', urgent: true })] }));
    expect(r.level).toBe('watch');
    expect(r.conditions[0].verified).toBe(false);
    expect(r.conditions[0].message).toMatch(/UNVERIFIED/);
  });

  it('raises Elevated for a verified congestion incident', () => {
    const r = assessZone(inputs({ incidents: [inc({ status: 'verified', confirmedSeverity: 'high', verifiedAt: minsAgo(1) })] }));
    expect(r.level).toBe('elevated');
    expect(r.conditions[0].verified).toBe(true);
  });

  it('counts only independent reporters as corroboration', () => {
    const same = assessZone(inputs({ incidents: [inc({ reporterId: 'u1' }), inc({ reporterId: 'u1' })] }));
    expect(same.conditions.some((c) => c.code === 'CORROBORATED')).toBe(false);
    expect(same.level).toBe('watch');
    const two = assessZone(inputs({ incidents: [inc({ reporterId: 'u1' }), inc({ reporterId: 'u2' })] }));
    expect(two.conditions.some((c) => c.code === 'CORROBORATED')).toBe(true);
    expect(two.level).toBe('elevated');
  });

  it('a designated critical condition cannot be hidden by a low aggregate score', () => {
    // Everything else calm; only the required exit is unavailable.
    const r = assessZone(inputs({ facilities: [fac('ex1', 'exit', 'n1', 'closed'), fac('ex2', 'exit', 'n2'), fac('ap', 'assembly', 'nap')] }));
    expect(r.attentionPoints).toBeLessThanOrEqual(10);
    expect(r.level).toBe('critical');
    expect(r.conditions[0]).toMatchObject({ code: 'REQUIRED_EXIT_UNAVAILABLE', critical: true });
  });

  it('a closure that cuts egress from a required exit is critical', () => {
    const segs = [{ ...seg('s1', 'n1', 'nap'), status: 'closed' as const }, seg('s2', 'n2', 'nap')];
    const r = assessZone(inputs({ segments: segs }));
    expect(r.level).toBe('critical');
    expect(r.conditions.some((c) => c.code === 'REQUIRED_EGRESS_BLOCKED')).toBe(true);
  });

  it('ignores expired advisories and labels unknown validity', () => {
    const adv = { id: 'a', eventId: 'e', title: 'Rain', issuer: 'X', sourceUrl: null, coverage: '', body: '', issuedAt: minsAgo(60), verification: 'verified' as const, verifiedBy: null, verifiedAt: null, isSample: true, affectedZoneIds: ['z'], affectedSegmentIds: [], actionsNote: '', createdBy: 'u', createdAt: minsAgo(60) };
    expect(assessZone(inputs({ advisories: [{ ...adv, expiresAt: minsAgo(5) }] })).level).toBe('normal');
    const r = assessZone(inputs({ advisories: [{ ...adv, expiresAt: null }] }));
    expect(r.level).toBe('watch');
    expect(r.conditions[0].message).toMatch(/validity period unknown/);
    expect(r.conditions[0].message).toMatch(/SAMPLE/);
  });

  it('feeds open pre-event findings into the zone', () => {
    const r = assessZone(inputs({ checklist: [{ id: 'c', eventId: 'e', key: 'k', label: 'Narrow passage', status: 'issue_identified', note: 'steep', zoneId: 'z', updatedBy: null, updatedAt: minsAgo(100) }] }));
    expect(r.conditions[0].code).toBe('PLAN_FINDING_OPEN');
  });

  it('reports rising / stable / falling trends from timestamped estimates', () => {
    const series = (vals: number[], step = 4) => vals.map((v, i) => ({ id: `o${i}`, zoneId: 'z', value: v, observedAt: minsAgo((vals.length - 1 - i) * step + 1), source: 'test', reportedBy: null }));
    const up = assessZone(inputs({ observations: series([300, 360, 420, 480]) }));
    expect(up.occupancy.trend.direction).toBe('rising');
    expect(up.occupancy.trend.ratePerMin).toBeCloseTo(15, 0);
    expect(up.occupancy.trend.readings).toHaveLength(4);
    expect(assessZone(inputs({ observations: series([500, 502, 499, 501]) })).occupancy.trend.direction).toBe('stable');
    expect(assessZone(inputs({ observations: series([700, 620, 540, 460]) })).occupancy.trend.direction).toBe('falling');
    expect(assessZone(inputs({ observations: occ(500) })).occupancy.trend.direction).toBe('unknown');
  });

  it('flags a rapid rise before any threshold is reached', () => {
    // 30 people/min on a 1000-capacity zone = 30% per 10 min, while still at 45%.
    const obs = [0, 1, 2, 3].map((i) => ({ id: `o${i}`, zoneId: 'z', value: 360 + i * 30, observedAt: minsAgo(4 - i), source: 'test', reportedBy: null }));
    const r = assessZone(inputs({ observations: obs }));
    expect(r.occupancy.pct).toBeLessThan(80);
    expect(r.conditions.map((c) => c.code)).toContain('OCCUPANCY_RISING');
    expect(r.level).toBe('watch');
  });

  it('flags contradictory estimates from different sources', () => {
    const obs = [
      { id: 'a', zoneId: 'z', value: 400, observedAt: minsAgo(4), source: 'Steward estimate', reportedBy: null },
      { id: 'b', zoneId: 'z', value: 750, observedAt: minsAgo(2), source: 'Gate counter', reportedBy: null },
    ];
    const r = assessZone(inputs({ observations: obs }));
    expect(r.conditions.some((c) => c.code === 'ESTIMATES_CONFLICT')).toBe(true);
    // Same source drifting is a trend, not a contradiction.
    const same = assessZone(inputs({ observations: obs.map((o) => ({ ...o, source: 'Steward estimate' })) }));
    expect(same.conditions.some((c) => c.code === 'ESTIMATES_CONFLICT')).toBe(false);
  });

  it('always provides a recommended next step', () => {
    for (const o of [[], occ(500), occ(1200)]) expect(assessZone(inputs({ observations: o })).recommendedNextStep.length).toBeGreaterThan(10);
  });
});
