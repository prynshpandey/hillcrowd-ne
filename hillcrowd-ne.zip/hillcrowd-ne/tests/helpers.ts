import request from 'supertest';
import { Store } from '../server/db';
import { Bus, type Ctx } from '../server/context';
import { seedBase, seedDemoEvent } from '../server/services/demo';
import { createApp } from '../server/app';
import { DEMO_PASSWORD } from '../server/seed/demoData';

export const EVENT = 'evt-demo-shillong';

/** In-memory app with a controllable clock. */
export function makeApp() {
  let now = new Date('2026-10-15T10:00:00.000Z');
  const ctx: Ctx = { store: new Store(':memory:'), now: () => now, bus: new Bus(), demoMode: true };
  seedBase(ctx);
  seedDemoEvent(ctx);
  const app = createApp(ctx, { staticDir: '/nonexistent' });
  const advance = (minutes: number) => {
    now = new Date(now.getTime() + minutes * 60_000);
  };
  return { ctx, app, advance };
}

export type Agent = ReturnType<typeof request.agent>;

export async function loginAs(app: ReturnType<typeof createApp>, username: string): Promise<Agent> {
  const agent = request.agent(app);
  const res = await agent.post('/api/auth/login').set('x-hillcrowd-client', '1').send({ username, password: DEMO_PASSWORD });
  if (res.status !== 200) throw new Error(`login failed for ${username}: ${res.status} ${JSON.stringify(res.body)}`);
  return agent;
}

export const post = (a: Agent, url: string, body: unknown = {}) => a.post(url).set('x-hillcrowd-client', '1').send(body as object);
export const patch = (a: Agent, url: string, body: unknown = {}) => a.patch(url).set('x-hillcrowd-client', '1').send(body as object);

export const congestion = (extra: Record<string, unknown> = {}) => ({
  category: 'crowd_congestion',
  zoneId: 'zone-b',
  description: 'Queue backing up at Gate B barrier',
  severityEstimate: 'high',
  urgent: true,
  ...extra,
});
