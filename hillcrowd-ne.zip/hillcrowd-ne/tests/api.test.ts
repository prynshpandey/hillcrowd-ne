import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { congestion, EVENT, loginAs, makeApp, patch, post } from './helpers';
import { runScenarioStep, scenarioState, resetDemo } from '../server/services/demo';
import { createEvent } from '../server/services/config';

describe('authentication & CSRF', () => {
  it('rejects bad passwords and requires a session', async () => {
    const { app } = makeApp();
    const bad = await request(app).post('/api/auth/login').set('x-hillcrowd-client', '1').send({ username: 'coord.demo', password: 'wrong' });
    expect(bad.status).toBe(401);
    expect((await request(app).get(`/api/events/${EVENT}/snapshot`)).status).toBe(401);
  });

  it('rejects state-changing requests without the client header', async () => {
    const { app } = makeApp();
    const a = await loginAs(app, 'steward.gateb');
    const res = await a.post(`/api/events/${EVENT}/incidents`).send(congestion());
    expect(res.status).toBe(403);
  });
});

describe('incident workflow', () => {
  it('steward submits a valid incident; it starts unverified', async () => {
    const { app } = makeApp();
    const s = await loginAs(app, 'steward.gateb');
    const res = await post(s, `/api/events/${EVENT}/incidents`, congestion());
    expect(res.status).toBe(201);
    expect(res.body.data.incident).toMatchObject({ status: 'submitted', category: 'crowd_congestion', zoneId: 'zone-b', urgent: true });
    expect(res.body.data.incident.lat).toBeTypeOf('number'); // derived from zone centroid
  });

  it('rejects invalid reports with meaningful messages', async () => {
    const { app } = makeApp();
    const s = await loginAs(app, 'steward.gateb');
    const cases = [
      { ...congestion(), description: '' },
      { ...congestion(), category: 'alien_invasion' },
      { ...congestion(), zoneId: undefined, lat: 999, lng: 91 },
      { ...congestion(), zoneId: undefined },
      { ...congestion(), lat: 25.5 },
      { ...congestion(), zoneId: 'zone-does-not-exist' },
      { ...congestion(), createdLocalAt: '2099-01-01T00:00:00Z' },
    ];
    for (const body of cases) {
      const res = await post(s, `/api/events/${EVENT}/incidents`, body);
      expect(res.status, JSON.stringify(body)).toBe(400);
      expect(res.body.ok).toBe(false);
      expect(res.body.error.message.length).toBeGreaterThan(3);
    }
  });

  it('is idempotent on clientId (offline retry does not duplicate)', async () => {
    const { app, ctx } = makeApp();
    const s = await loginAs(app, 'steward.gateb');
    const body = congestion({ clientId: 'c-retry-0001', createdLocalAt: '2026-10-15T09:55:00Z' });
    const first = await post(s, `/api/events/${EVENT}/incidents`, body);
    const second = await post(s, `/api/events/${EVENT}/incidents`, body);
    expect(first.status).toBe(201);
    expect(second.status).toBe(200);
    expect(second.body.data.duplicateSubmission).toBe(true);
    expect(second.body.data.incident.id).toBe(first.body.data.incident.id);
    expect(ctx.store.incidents(EVENT)).toHaveLength(1);
    // Local creation time and server receipt time are kept separately.
    expect(first.body.data.incident.createdLocalAt).toBe('2026-10-15T09:55:00.000Z');
    expect(first.body.data.incident.receivedAt).toBe('2026-10-15T10:00:00.000Z');
    // Another user cannot hijack the client ID.
    const other = await loginAs(app, 'steward.market');
    expect((await post(other, `/api/events/${EVENT}/incidents`, body)).status).toBe(409);
  });

  it('full lifecycle: verify → assign → acknowledge → en route → on scene → resolved → closed, with preserved history', async () => {
    const { app, advance } = makeApp();
    const s = await loginAs(app, 'steward.gateb');
    const c = await loginAs(app, 'coord.demo');
    const r = await loginAs(app, 'team.alpha');
    const id = (await post(s, `/api/events/${EVENT}/incidents`, congestion())).body.data.incident.id;

    // Cannot assign before verification.
    expect((await post(c, `/api/incidents/${id}/assignments`, { responderId: 'r-alpha' })).status).toBe(409);

    advance(1);
    expect((await post(c, `/api/incidents/${id}/transition`, { to: 'under_review' })).body.data.status).toBe('under_review');
    const v = await post(c, `/api/incidents/${id}/transition`, { to: 'verified', note: 'radio', confirmedSeverity: 'high' });
    expect(v.body.data).toMatchObject({ status: 'verified', confirmedSeverity: 'high' });

    advance(1);
    const asg = await post(c, `/api/incidents/${id}/assignments`, { responderId: 'r-alpha', note: 'check gate' });
    expect(asg.status).toBe(200);
    expect(asg.body.data.route.found).toBe(true);
    const asgId = asg.body.data.id;

    // Another responder cannot act on it.
    const medic = await loginAs(app, 'medic.one');
    expect((await post(medic, `/api/assignments/${asgId}/status`, { status: 'acknowledged' })).status).toBe(403);
    // Out-of-order transitions are rejected.
    expect((await post(r, `/api/assignments/${asgId}/status`, { status: 'on_scene' })).status).toBe(409);

    advance(1);
    await post(r, `/api/assignments/${asgId}/status`, { status: 'acknowledged' });
    await post(r, `/api/assignments/${asgId}/status`, { status: 'en_route' });
    await post(r, `/api/assignments/${asgId}/status`, { status: 'on_scene' });
    expect((await post(r, `/api/assignments/${asgId}/status`, { status: 'resolved' })).status).toBe(400); // note required
    advance(2);
    await post(r, `/api/assignments/${asgId}/status`, { status: 'resolved', note: 'eased' });

    let detail = (await c.get(`/api/incidents/${id}`)).body.data;
    expect(detail.incident.status).toBe('resolved'); // awaits coordinator confirmation
    await post(c, `/api/incidents/${id}/transition`, { to: 'closed' });
    detail = (await c.get(`/api/incidents/${id}`)).body.data;
    expect(detail.incident.status).toBe('closed');
    expect(detail.incident.acknowledgedAt).toBe('2026-10-15T10:03:00.000Z');
    const statuses = detail.history.filter((h: any) => h.toStatus).map((h: any) => h.toStatus);
    expect(statuses).toEqual(['submitted', 'under_review', 'verified', 'assigned', 'acknowledged', 'in_progress', 'resolved', 'closed']);
    expect(detail.history[0].note).toContain('Queue backing up'); // original report retained

    // Analytics derive from recorded timestamps.
    const an = (await c.get(`/api/events/${EVENT}/analytics`)).body.data;
    expect(an.medians.reportToAssignSec).toBe(120);
    expect(an.medians.reportToAckSec).toBe(180);
    expect(an.medians.reportToResolveSec).toBe(300);
    expect(an.isDemo).toBe(true);
    const csv = await c.get(`/api/events/${EVENT}/analytics.csv`);
    expect(csv.headers['content-type']).toMatch(/text\/csv/);
    expect(csv.text).toContain('HC-0001');
  });

  it('declined assignment returns the incident for reassignment', async () => {
    const { app } = makeApp();
    const s = await loginAs(app, 'steward.gateb');
    const c = await loginAs(app, 'coord.demo');
    const r = await loginAs(app, 'team.alpha');
    const id = (await post(s, `/api/events/${EVENT}/incidents`, congestion())).body.data.incident.id;
    await post(c, `/api/incidents/${id}/transition`, { to: 'verified' });
    const asgId = (await post(c, `/api/incidents/${id}/assignments`, { responderId: 'r-alpha' })).body.data.id;
    expect((await post(r, `/api/assignments/${asgId}/status`, { status: 'declined' })).status).toBe(400);
    await post(r, `/api/assignments/${asgId}/status`, { status: 'declined', note: 'Already handling another task' });
    const d = (await c.get(`/api/incidents/${id}`)).body.data;
    expect(d.incident.status).toBe('verified');
    expect(d.incident.ownerId).toBeNull();
  });

  it('coordinator can reject (with reason) and reopen', async () => {
    const { app } = makeApp();
    const s = await loginAs(app, 'steward.gateb');
    const c = await loginAs(app, 'coord.demo');
    const id = (await post(s, `/api/events/${EVENT}/incidents`, congestion())).body.data.incident.id;
    expect((await post(c, `/api/incidents/${id}/transition`, { to: 'rejected' })).status).toBe(400);
    expect((await post(c, `/api/incidents/${id}/transition`, { to: 'rejected', note: 'Normal queue' })).body.data.status).toBe('rejected');
    const re = await post(c, `/api/incidents/${id}/transition`, { to: 'under_review', note: 'second report' });
    expect(re.body.data).toMatchObject({ status: 'under_review', reopenCount: 1 });
  });

  it('flags possible duplicates and merges while retaining source records', async () => {
    const { app, ctx } = makeApp();
    const s1 = await loginAs(app, 'steward.gateb');
    const s2 = await loginAs(app, 'steward.market');
    const c = await loginAs(app, 'coord.demo');
    const a = (await post(s1, `/api/events/${EVENT}/incidents`, congestion())).body.data.incident;
    const b = (await post(s2, `/api/events/${EVENT}/incidents`, congestion({ description: 'Crowd pushing at Gate B' }))).body.data.incident;
    expect(b.possibleDuplicateOf).toEqual([a.id]);

    // Two independent reporters → corroborated (Elevated) while still unverified.
    const snap = (await c.get(`/api/events/${EVENT}/snapshot`)).body.data;
    const zb = snap.risks.find((r: any) => r.zoneId === 'zone-b');
    expect(zb.level).toBe('elevated');
    expect(zb.conditions.map((x: any) => x.code)).toContain('CORROBORATED');

    expect((await post(c, `/api/incidents/${b.id}/merge`, { intoId: a.id, note: 'same queue' })).status).toBe(200);
    const child = ctx.store.incident(b.id)!;
    expect(child.mergedInto).toBe(a.id);
    expect(child.description).toBe('Crowd pushing at Gate B');
    expect(ctx.store.incidents(EVENT)).toHaveLength(2); // nothing deleted
  });

  it('escalates an overdue acceptance stage once, naming who must act', async () => {
    const { app, ctx, advance } = makeApp();
    const { runEscalations } = await import('../server/services/assignments');
    const s = await loginAs(app, 'steward.gateb');
    const c = await loginAs(app, 'coord.demo');
    const id = (await post(s, `/api/events/${EVENT}/incidents`, congestion())).body.data.incident.id;
    await post(c, `/api/incidents/${id}/transition`, { to: 'verified' });
    const asgId = (await post(c, `/api/incidents/${id}/assignments`, { responderId: 'r-alpha' })).body.data.id;
    advance(2);
    expect(runEscalations(ctx, EVENT)).toBe(0);
    advance(2);
    expect(runEscalations(ctx, EVENT)).toBe(1);
    expect(runEscalations(ctx, EVENT)).toBe(0); // idempotent
    expect(ctx.store.assignment(asgId)!.escalationReason).toMatch(/Acceptance has taken 4 min \(target 3 min/);
    expect(ctx.store.assignment(asgId)!.escalationReason).toMatch(/Next: Steward Team Alpha/);
  });
});

describe('permissions are enforced by the backend', () => {
  it('stewards cannot use control-room or admin actions', async () => {
    const { app } = makeApp();
    const s = await loginAs(app, 'steward.gateb');
    const id = (await post(s, `/api/events/${EVENT}/incidents`, congestion())).body.data.incident.id;
    expect((await post(s, `/api/incidents/${id}/transition`, { to: 'verified' })).status).toBe(403);
    expect((await post(s, `/api/segments/s17/status`, { status: 'closed', reason: 'x', source: 'me' })).status).toBe(403);
    expect((await patch(s, `/api/zones/zone-b`, { capacity: 99999 })).status).toBe(403);
    expect((await post(s, `/api/facilities/exit-d/status`, { status: 'closed', reason: 'x' })).status).toBe(403);
    expect((await s.get('/api/users')).status).toBe(403);
    expect((await patch(s, `/api/users/usr-stw-b`, { role: 'admin' })).status).toBe(403);
    expect((await s.get(`/api/events/${EVENT}/audit`)).status).toBe(403);
    expect((await post(s, '/api/demo/reset')).status).toBe(403);
  });

  it('coordinators cannot modify verified safety configuration or manage users', async () => {
    const { app } = makeApp();
    const c = await loginAs(app, 'coord.demo');
    expect((await patch(c, `/api/zones/zone-b`, { capacity: 99999 })).status).toBe(403);
    expect((await patch(c, `/api/segments/s17`, { approved: false })).status).toBe(403);
    expect((await patch(c, `/api/events/${EVENT}`, { settings: { staleMinutes: 99 } })).status).toBe(403);
    expect((await post(c, '/api/users', { username: 'x.user', displayName: 'X', role: 'admin', password: 'longpassword1' })).status).toBe(403);
    expect((await patch(c, '/api/checklist/chk-gate_capacity', { status: 'mitigation_verified', note: 'ok' })).status).toBe(403);
  });

  it('admins cannot change their own role', async () => {
    const { app } = makeApp();
    const a = await loginAs(app, 'admin.demo');
    expect((await patch(a, '/api/users/usr-admin', { role: 'steward' })).status).toBe(403);
    expect((await patch(a, '/api/zones/zone-b', { watchPct: 99, elevatedPct: 90 })).status).toBe(400); // thresholds must increase
    expect((await patch(a, '/api/zones/zone-b', { capacity: 1600 })).status).toBe(200);
  });

  it('stewards see only their own reports; responders only their assignments', async () => {
    const { app } = makeApp();
    const s1 = await loginAs(app, 'steward.gateb');
    const s2 = await loginAs(app, 'steward.market');
    const id = (await post(s1, `/api/events/${EVENT}/incidents`, congestion())).body.data.incident.id;
    expect((await s2.get(`/api/incidents/${id}`)).status).toBe(403);
    expect((await s2.get(`/api/events/${EVENT}/snapshot`)).body.data.incidents).toHaveLength(0);
    const r = await loginAs(app, 'team.alpha');
    const snap = (await r.get(`/api/events/${EVENT}/snapshot`)).body.data;
    expect(snap.view).toBe('responder');
    expect(snap.incidents).toHaveLength(0);
    expect(snap.risks).toBeUndefined();
  });

  it('users cannot access unrelated events', async () => {
    const { app, ctx } = makeApp();
    const admin = ctx.store.userById('usr-admin')!;
    const ev = createEvent(ctx, admin, {
      name: 'Other event', eventType: 'Concert', state: 'Assam', district: 'Kamrup Metropolitan', locationLabel: '', venueName: 'Test venue', venueIsFictional: true,
      startsAt: '2026-10-16T10:00:00Z', endsAt: '2026-10-16T18:00:00Z', expectedAttendance: null, venueCapacity: null, controlContact: '', centerLat: 26.14, centerLng: 91.74, zoom: 16, template: 'demo_layout',
    });
    const c = await loginAs(app, 'coord.demo');
    expect((await c.get(`/api/events/${ev.id}/snapshot`)).status).toBe(403);
    const a = await loginAs(app, 'admin.demo');
    expect((await a.get(`/api/events/${ev.id}/snapshot`)).status).toBe(200);
  });
});

describe('audit integrity', () => {
  it('audit log and incident history are append-only at the database level', async () => {
    const { app, ctx } = makeApp();
    const s = await loginAs(app, 'steward.gateb');
    const id = (await post(s, `/api/events/${EVENT}/incidents`, congestion())).body.data.incident.id;
    expect(() => ctx.store.run("UPDATE audit_log SET action = 'x'")).toThrow(/append-only/);
    expect(() => ctx.store.run('DELETE FROM audit_log')).toThrow(/append-only/);
    expect(() => ctx.store.run("UPDATE incident_updates SET note = 'x'")).toThrow(/append-only/);
    expect(() => ctx.store.run('DELETE FROM incident_updates WHERE incident_id = ?', id)).toThrow(/append-only/);
    expect(() => ctx.store.run('DELETE FROM incidents WHERE id = ?', id)).toThrow(/cannot be deleted/);
  });
});

describe('demo scenario', () => {
  it('runs end-to-end with consistent records, then resets without touching other events', async () => {
    const { app, ctx, advance } = makeApp();
    const c = await loginAs(app, 'coord.demo');
    const zoneLevel = async (z: string) => (await c.get(`/api/events/${EVENT}/snapshot`)).body.data.risks.find((r: any) => r.zoneId === z).level;

    // Initial state: all normal, all routes valid, all responders available.
    let snap = (await c.get(`/api/events/${EVENT}/snapshot`)).body.data;
    expect(snap.risks.every((r: any) => r.level === 'normal')).toBe(true);
    expect(snap.routeValidity.every((v: any) => v.valid)).toBe(true);
    expect(snap.responders.every((r: any) => r.status === 'available')).toBe(true);

    // Out-of-order step is refused.
    expect((await post(c, '/api/demo/scenario/verify')).status).toBe(409);

    await post(c, '/api/demo/scenario/report');
    expect(await zoneLevel('zone-b')).toBe('watch'); // unverified + 92% occupancy
    advance(1);
    await post(c, '/api/demo/scenario/verify');
    expect(await zoneLevel('zone-b')).toBe('elevated');
    snap = (await c.get(`/api/events/${EVENT}/snapshot`)).body.data;
    expect(snap.actions.length).toBeGreaterThan(0); // playbook proposed

    await post(c, '/api/demo/scenario/advisory');
    snap = (await c.get(`/api/events/${EVENT}/snapshot`)).body.data;
    expect(snap.segments.find((s: any) => s.id === 's17').status).toBe('under_review');
    expect(snap.advisories[0].isSample).toBe(true);

    await post(c, '/api/demo/scenario/closure');
    snap = (await c.get(`/api/events/${EVENT}/snapshot`)).body.data;
    const med = snap.routeValidity.find((v: any) => v.routeId === 'nr-med-out');
    expect(med.valid).toBe(false);
    expect(med.alternative.found).toBe(true);
    expect(med.alternative.segmentIds).not.toContain('s17');

    advance(1);
    await post(c, '/api/demo/scenario/assign');
    advance(1);
    await post(c, '/api/demo/scenario/acknowledge');
    advance(2);
    await post(c, '/api/demo/scenario/respond');
    advance(3);
    await post(c, '/api/demo/scenario/resolve');
    await post(c, '/api/demo/scenario/close');
    const state = scenarioState(ctx);
    expect(state.next).toBeNull();
    const an = (await c.get(`/api/events/${EVENT}/analytics`)).body.data;
    expect(an.medians.reportToAckSec).toBe(180);
    expect(an.medians.reportToResolveSec).toBe(480);
    expect(an.closures.some((x: any) => x.segment.startsWith('Lower service road') && x.status === 'closed')).toBe(true);

    // Non-demo event and permanent audit survive a reset.
    const admin = ctx.store.userById('usr-admin')!;
    const other = createEvent(ctx, admin, {
      name: 'Real event', eventType: 'Concert', state: 'Meghalaya', district: 'East Khasi Hills', locationLabel: '', venueName: 'V', venueIsFictional: false,
      startsAt: '2026-10-16T10:00:00Z', endsAt: '2026-10-16T18:00:00Z', expectedAttendance: null, venueCapacity: null, controlContact: '', centerLat: 25.57, centerLng: 91.88, zoom: 16, template: 'blank',
    });
    expect((await post(c, '/api/demo/reset')).status).toBe(200);
    expect(ctx.store.incidents(EVENT)).toHaveLength(0);
    expect(ctx.store.event(other.id)).not.toBeNull();
    expect(ctx.store.get("SELECT 1 FROM audit_log WHERE action = 'event.created' AND entity_id = ?", other.id)).toBeTruthy();
    expect(ctx.store.get("SELECT 1 FROM audit_log WHERE action = 'demo.reset'")).toBeTruthy();
    expect(scenarioState(ctx).next).toBe('report');
    // Replayable after reset.
    runScenarioStep(ctx, 'report');
    expect(ctx.store.incidents(EVENT)).toHaveLength(1);
    resetDemo(ctx, null);
  });
});
