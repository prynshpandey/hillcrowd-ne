/**
 * Browser smoke test: drives the built app in Chromium.
 *   npm run build && npm start   (in another terminal)
 *   BASE_URL=http://localhost:4000 npm run test:e2e
 * Uses playwright-core with a system Chromium (CHROMIUM_PATH) — no browser download.
 */
import { chromium, type Page } from 'playwright-core';
import { mkdirSync } from 'node:fs';

const BASE = process.env.BASE_URL ?? 'http://localhost:4000';
const CHROME = process.env.CHROMIUM_PATH ?? '/opt/pw-browsers/chromium-1194/chrome-linux/chrome';
const OUT = 'tests/e2e/screenshots';
mkdirSync(OUT, { recursive: true });

const errors: string[] = [];
let failures = 0;
const check = (cond: unknown, msg: string) => {
  if (cond) console.log(`  ✓ ${msg}`);
  else {
    failures++;
    console.log(`  ✗ ${msg}`);
  }
};

function watch(page: Page, label: string) {
  page.on('console', (m) => {
    // Map tiles may be unreachable in sandboxed environments; that is a handled fallback, not an app error.
    if (m.type() === 'error' && !/tile\.open|ERR_|Failed to load resource/.test(m.text())) errors.push(`[${label}] ${m.text()}`);
  });
  page.on('pageerror', (e) => errors.push(`[${label}] pageerror: ${e.message}`));
}

async function login(page: Page, username: string) {
  await page.goto(`${BASE}/login`);
  await page.getByRole('button', { name: new RegExp(username.replace('.', '\\.')) }).click();
  await page.waitForURL((u) => !u.pathname.startsWith('/login'));
}

async function main() {
  const browser = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });

  // ---------- Control room (desktop) ----------
  console.log('Control room, desktop 1440×900');
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await ctx.newPage();
  watch(page, 'coord');
  await page.goto(`${BASE}/login`);
  await page.screenshot({ path: `${OUT}/01-login.png` });
  // Reset demo first (as coordinator) so the run is reproducible.
  await login(page, 'coord.demo');
  check(page.url().endsWith('/overview'), 'coordinator lands on Overview');
  const reset = await page.request.post(`${BASE}/api/demo/reset`, { headers: { 'x-hillcrowd-client': '1' } });
  check(reset.ok(), 'demo reset via API');
  await page.reload();
  await page.getByText('Needs action now').waitFor();
  await page.waitForTimeout(800);
  await page.screenshot({ path: `${OUT}/02-overview-initial.png`, fullPage: true });
  check(await page.getByText('Zone A – Main Stage Arena').first().isVisible(), 'zone cards render');

  for (const [path, name, text] of [
    ['/map', '03-live-map', 'Layers'],
    ['/routes', '04-routes', 'Route planner'],
    ['/resilience', '04b-resilience', 'Critical access links'],
    ['/responders', '05-responders', 'Steward Team Alpha'],
    ['/advisories', '06-advisories', 'No live official feed'],
    ['/setup', '07-setup', 'Event details'],
    ['/settings', '08-settings', 'Audit log'],
  ] as const) {
    await page.goto(`${BASE}${path}`);
    await page.getByText(text).first().waitFor({ timeout: 10000 });
    await page.waitForTimeout(700);
    await page.screenshot({ path: `${OUT}/${name}.png`, fullPage: path !== '/map' });
    check(true, `${path} renders`);
  }

  // Run the scenario through the demo panel buttons.
  console.log('Scenario via demo panel');
  await page.goto(`${BASE}/overview`);
  for (let i = 1; i <= 9; i++) {
    const btn = page.getByRole('button', { name: 'Run step' });
    await btn.waitFor({ timeout: 10000 });
    await btn.click();
    await page.getByText('Scenario step completed').first().waitFor({ timeout: 10000 });
    await page.waitForTimeout(400);
    if (i === 2) await page.screenshot({ path: `${OUT}/09-overview-after-verify.png`, fullPage: true });
    if (i === 4) {
      await page.goto(`${BASE}/routes`);
      await page.getByText('INVALID').first().waitFor();
      await page.getByRole('button', { name: /Medical vehicle route/ }).click();
      await page.waitForTimeout(800);
      await page.screenshot({ path: `${OUT}/10-routes-after-closure.png`, fullPage: true });
      check(await page.getByText(/Alternative found within approved network/).first().isVisible(), 'closure invalidates medical route and shows alternative');
      await page.goto(`${BASE}/overview`);
    }
  }
  check(await page.getByText('10. Review the event').isVisible(), 'all scenario steps complete');

  // Resilience Lab: first failure → detour, second failure → no approved route (simulation only).
  console.log('Resilience Lab');
  await page.goto(`${BASE}/resilience`);
  await page.getByRole('button', { name: /Lower service road closed/ }).click();
  await page.getByText(/Detour/).first().waitFor({ timeout: 10000 });
  await page.getByRole('button', { name: /ring-road detour fails/ }).click();
  await page.getByText('No approved route available').first().waitFor({ timeout: 10000 });
  await page.waitForTimeout(600);
  await page.screenshot({ path: `${OUT}/10b-resilience-second-failure.png`, fullPage: true });
  check(await page.getByText('SIMULATION — live data unchanged').isVisible(), 'simulation clearly labelled');
  check(await page.locator('.spof').getByText('Medical access lane').first().isVisible(), 'single point of failure listed');

  // Exercise drawer: inject a live event from any page.
  console.log('Exercise drawer');
  await page.goto(`${BASE}/map`);
  await page.getByRole('button', { name: 'Exercise', exact: true }).click();
  await page.getByRole('button', { name: /Medical incident in Zone D/ }).click();
  await page.getByText(/Simulated: Medical incident in Zone D/).waitFor({ timeout: 10000 });
  await page.waitForTimeout(800);
  await page.screenshot({ path: `${OUT}/10c-exercise-drawer.png` });
  check(true, 'exercise inject applied');
  await page.getByRole('button', { name: 'Exercise', exact: true }).click();

  await page.goto(`${BASE}/incidents`);
  await page.getByRole('tab', { name: 'All', exact: true }).click();
  await page.getByText('HC-0001').first().click();
  await page.getByText('History').first().waitFor();
  check(await page.getByText('Response stages').isVisible(), 'stage timeline shown on incident');
  await page.waitForTimeout(600);
  await page.screenshot({ path: `${OUT}/11-incident-detail.png`, fullPage: true });
  check(await page.getByText('Confirmed & closed').count() === 0, 'closed incident offers no close button');

  await page.goto(`${BASE}/analytics`);
  await page.getByText(/Exercise replay/).waitFor();
  await page.getByRole('button', { name: /Play|Replay/ }).first().click();
  await page.waitForTimeout(1500);
  await page.waitForTimeout(600);
  await page.screenshot({ path: `${OUT}/12-analytics.png`, fullPage: true });
  check(await page.getByText(/DEMO DATA/).first().isVisible(), 'analytics labelled as demo data');

  // ---------- Steward (mobile) with offline queue ----------
  console.log('Steward, mobile 390×844, offline queue');
  const mctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  const m = await mctx.newPage();
  watch(m, 'steward');
  await login(m, 'steward.market');
  check(m.url().endsWith('/field'), 'steward lands on field app');
  await m.getByText('What is happening?').waitFor();
  await m.screenshot({ path: `${OUT}/13-field-report.png`, fullPage: true });

  await mctx.setOffline(true);
  await m.evaluate(() => window.dispatchEvent(new Event('offline')));
  await m.getByRole('button', { name: /Medical/ }).first().click();
  await m.getByRole('button', { name: 'Zone C – Food & Craft Market' }).click();
  await m.getByRole('button', { name: '+ Person fainted' }).click();
  await m.getByRole('button', { name: /Save report|Send report/ }).click();
  await m.getByText(/Saved on device|Waiting to sync/).first().waitFor();
  await m.screenshot({ path: `${OUT}/14-field-offline-queued.png`, fullPage: true });
  check(await m.getByText('Not yet delivered').first().isVisible(), 'offline report shown as NOT delivered');

  await mctx.setOffline(false);
  await m.evaluate(() => window.dispatchEvent(new Event('online')));
  await m.getByText('Server confirmed').first().waitFor({ timeout: 15000 });
  await m.waitForTimeout(500);
  await m.screenshot({ path: `${OUT}/15-field-delivered.png`, fullPage: true });
  check(await m.getByText(/Last successful sync/).isVisible(), 'queued report confirmed after reconnect; last sync shown');

  // Coordinator sees exactly one copy of it.
  const snap = await page.request.get(`${BASE}/api/events/evt-demo-shillong/snapshot`);
  const data = (await snap.json()).data;
  const fainted = data.incidents.filter((i: { description: string }) => i.description.includes('Person fainted'));
  check(fainted.length === 1, `control room has exactly one copy of the queued report (found ${fainted.length})`);

  // ---------- Responder (mobile) ----------
  console.log('Responder, mobile');
  const rctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  const r = await rctx.newPage();
  watch(r, 'responder');
  await login(r, 'team.alpha');
  check(r.url().endsWith('/respond'), 'responder lands on responder app');
  await r.getByText(/Completed \/ closed|No active assignments/).first().waitFor();
  await r.screenshot({ path: `${OUT}/16-responder.png`, fullPage: true });

  // Permission spot-check from the browser session of a steward.
  const forbidden = await m.request.post(`${BASE}/api/segments/s19/status`, { headers: { 'x-hillcrowd-client': '1' }, data: { status: 'closed', reason: 'x', source: 'test' } });
  check(forbidden.status() === 403, 'steward cannot close a route segment (403)');

  await browser.close();
  console.log(`\nConsole/page errors: ${errors.length}`);
  for (const e of errors) console.log('  ' + e);
  if (failures || errors.length) {
    console.log(`\nFAILED: ${failures} check(s), ${errors.length} error(s)`);
    process.exit(1);
  }
  console.log('\nAll browser smoke checks passed.');
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
