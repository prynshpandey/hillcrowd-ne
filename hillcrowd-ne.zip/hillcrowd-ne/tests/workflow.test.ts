import { describe, expect, it } from 'vitest';
import { availableTransitions, assertAssignmentTransition, findTransition, WorkflowError } from '../shared/workflow';
import { can } from '../shared/permissions';

describe('incident state machine', () => {
  it('allows the documented path for the control room', () => {
    expect(findTransition('submitted', 'under_review', 'coordinator').to).toBe('under_review');
    expect(findTransition('under_review', 'verified', 'coordinator').to).toBe('verified');
    expect(findTransition('resolved', 'closed', 'admin').to).toBe('closed');
  });
  it('rejects unauthorised role transitions', () => {
    expect(() => findTransition('submitted', 'verified', 'steward')).toThrow(WorkflowError);
    expect(() => findTransition('submitted', 'verified', 'responder')).toThrow(WorkflowError);
    expect(() => findTransition('resolved', 'closed', 'responder')).toThrow(WorkflowError);
  });
  it('rejects transitions not in the workflow', () => {
    expect(() => findTransition('submitted', 'closed', 'admin')).toThrow(/not permitted/);
    expect(() => findTransition('closed', 'verified', 'admin')).toThrow(/not permitted/);
  });
  it('assignment-driven statuses cannot be set directly', () => {
    expect(() => findTransition('verified', 'assigned', 'coordinator')).toThrow(/assignment workflow/);
    expect(findTransition('verified', 'assigned', 'coordinator', { internal: true }).to).toBe('assigned');
  });
  it('requires a reason to reject or reopen', () => {
    expect(findTransition('submitted', 'rejected', 'coordinator').requiresNote).toBe(true);
    expect(findTransition('closed', 'under_review', 'coordinator').requiresNote).toBe(true);
  });
  it('gives field roles no direct incident transitions', () => {
    expect(availableTransitions('submitted', 'steward')).toEqual([]);
    expect(availableTransitions('in_progress', 'responder')).toEqual([]);
  });
  it('enforces the responder sequence', () => {
    expect(() => assertAssignmentTransition('assigned', 'on_scene')).toThrow();
    expect(() => assertAssignmentTransition('resolved', 'acknowledged')).toThrow();
    expect(() => assertAssignmentTransition('assigned', 'acknowledged')).not.toThrow();
  });
  it('permission matrix keeps admin-only configuration away from other roles', () => {
    for (const r of ['coordinator', 'steward', 'responder'] as const) {
      expect(can(r, 'zone.configure')).toBe(false);
      expect(can(r, 'users.manage')).toBe(false);
    }
    expect(can('admin', 'zone.configure')).toBe(true);
    expect(can('steward', 'incident.create')).toBe(true);
    expect(can(undefined, 'event.view')).toBe(false);
  });
});
