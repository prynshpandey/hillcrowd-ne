import { describe, expect, it } from 'vitest';
import { incidentStages, targetsFor } from '../shared/accountability';
import { DEFAULT_SETTINGS } from '../shared/constants';
import type { Assignment, Incident } from '../shared/types';

const T0 = Date.parse('2026-10-15T10:00:00Z');
const at = (min: number) => new Date(T0 + min * 60_000).toISOString();
const inc = (p: Partial<Incident> = {}): Incident => ({
  id: 'i1', ref: 'HC-1', eventId: 'e', clientId: null, category: 'crowd_congestion', zoneId: 'z', lat: null, lng: null, description: 'x', severityEstimate: 'high', confirmedSeverity: null, urgent: false,
  status: 'submitted', reporterId: 'u', ownerId: null, createdLocalAt: at(0), receivedAt: at(0), updatedAt: at(0), verifiedAt: null, assignedAt: null, acknowledgedAt: null, resolvedAt: null, closedAt: null,
  mergedInto: null, possibleDuplicateOf: [], reopenCount: 0, isDemo: false, attachmentNote: null, ...p,
});
const asg = (p: Partial<Assignment> = {}): Assignment => ({
  id: 'a1', incidentId: 'i1', responderId: 'r1', status: 'assigned', assignedBy: 'c', note: '', assignedAt: at(2), acknowledgedAt: null, enRouteAt: null, onSceneAt: null, resolvedAt: null, closedReason: null, escalatedAt: null, escalationReason: null, route: null, ...p,
});
const name = () => 'Team Alpha';

describe('response accountability stages', () => {
  it('uses severity targets with per-category overrides', () => {
    expect(targetsFor(DEFAULT_SETTINGS, inc()).accept).toBe(3);
    expect(targetsFor(DEFAULT_SETTINGS, inc({ category: 'medical' })).accept).toBe(2);
    expect(targetsFor(DEFAULT_SETTINGS, inc({ confirmedSeverity: 'low' })).verify).toBe(10);
  });

  it('identifies the delayed stage and who must act next', () => {
    const st = incidentStages(inc({ status: 'verified', verifiedAt: at(1) }), [], DEFAULT_SETTINGS, name, new Date(at(6)));
    expect(st.current).toBe('assign');
    expect(st.overdue).toBe(true); // 5 min vs 3 min target
    expect(st.nextActor).toBe('Control room');
    expect(st.stages[0]).toMatchObject({ key: 'verify', state: 'done', durationSec: 60, overdue: false });
  });

  it('attributes acceptance and travel to the assigned responder', () => {
    const i = inc({ status: 'assigned', verifiedAt: at(1), assignedAt: at(2) });
    const st = incidentStages(i, [asg()], DEFAULT_SETTINGS, name, new Date(at(3)));
    expect(st.current).toBe('accept');
    expect(st.overdue).toBe(false);
    expect(st.nextActor).toBe('Team Alpha');
    const st2 = incidentStages({ ...i, status: 'acknowledged' }, [asg({ status: 'acknowledged', acknowledgedAt: at(4) })], DEFAULT_SETTINGS, name, new Date(at(20)));
    expect(st2.current).toBe('arrive');
    expect(st2.overdue).toBe(true);
  });

  it('restarts acceptance for a reassignment', () => {
    const i = inc({ status: 'assigned', verifiedAt: at(1), assignedAt: at(2) });
    const st = incidentStages(i, [asg({ status: 'declined', closedReason: 'busy' }), asg({ id: 'a2', responderId: 'r2', assignedAt: at(10) })], DEFAULT_SETTINGS, (id) => (id === 'r2' ? 'Team Bravo' : 'Team Alpha'), new Date(at(11)));
    expect(st.current).toBe('accept');
    expect(st.elapsedSec).toBe(60);
    expect(st.nextActor).toBe('Team Bravo');
  });

  it('has no open stage once closed, and marks unreached stages as skipped', () => {
    const st = incidentStages(inc({ status: 'closed', verifiedAt: at(1), resolvedAt: at(5), closedAt: at(6) }), [], DEFAULT_SETTINGS, name, new Date(at(30)));
    expect(st.current).toBeNull();
    expect(st.stages.find((s) => s.key === 'assign')!.state).toBe('skipped');
    expect(st.stages.find((s) => s.key === 'confirm')!.state).toBe('done');
  });
});
