import { describe, expect, it } from 'vitest';
import { createRequire } from 'node:module';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { EVENT, loginAs, makeApp, post } from './helpers';
import { liveResilience, simulate } from '../server/services/resilience';
import { Store } from '../server/db';

const { DatabaseSync } = createRequire(import.meta.url)('node:sqlite') as typeof import('node:sqlite');
const link = (r: ReturnType<typeof simulate>, id: string) => r.links.find((l) => l.link.id === id)!;

describe('route resilience engine (demo venue)', () => {
  it('finds single points of failure in the planned network', () => {
    const { ctx } = makeApp();
    const r = liveResilience(ctx, EVENT);
    expect(r.summary.links).toBeGreaterThan(8);
    // The medical post has only one vehicle lane: both approved vehicle routes depend on it.
    const medLane = r.singlePointRanking.find((x) => x.name === 'Medical access lane');
    expect(medLane).toBeTruthy();
    expect(medLane!.links.length).toBeGreaterThanOrEqual(2);
    const medOut = link(r, 'route:nr-med-out');
    expect(medOut.singlePoints.map((x) => x.name)).toContain('Medical access lane');
    expect(medOut.redundancy).toBe(1);
    // Zone walk-outs have two exits, so no single segment cuts them.
    expect(link(r, 'egress:zone-b').singlePoints).toEqual([]);
    expect(link(r, 'egress:zone-b').redundancy).toBeGreaterThanOrEqual(2);
    expect(r.summary.lost).toBe(0);
  });

  it('first failure: approved detour with explained restrictions; second failure: no approved route', () => {
    const { ctx } = makeApp();
    const one = simulate(ctx, EVENT, { closedSegments: ['s17'], closedFacilities: [] });
    const m1 = link(one, 'route:nr-med-out');
    expect(m1.status).toBe('detour');
    expect(m1.detour!.extraDistanceM).toBeGreaterThan(0);
    expect(m1.detour!.removedSegments.map((x) => x.id)).toContain('s17');
    const via = m1.detour!.addedSegments.map((x) => x.id);
    expect(via).toContain('s20');
    expect(m1.detour!.addedSegments.find((x) => x.id === 's20')!.constraint).toMatch(/one ambulance at a time/);

    const two = simulate(ctx, EVENT, { closedSegments: ['s17', 's20'], closedFacilities: [] });
    const m2 = link(two, 'route:nr-med-out');
    expect(m2.status).toBe('lost');
    expect(m2.scenario).toBeNull();
    expect(two.gaps.some((g) => g.severity === 'critical' && /No approved route available/.test(g.message))).toBe(true);
  });

  it('lists the second-failure pairs that would cut a redundant link', () => {
    const { ctx } = makeApp();
    const r = liveResilience(ctx, EVENT);
    const withPairs = r.links.filter((l) => l.secondFailures.length);
    expect(withPairs.length).toBeGreaterThan(0);
    for (const l of withPairs) expect(l.singlePoints).toEqual([]);
  });

  it('stress tests: heavy rain, required exit, team availability and comms fallback', () => {
    const { ctx } = makeApp();
    const rain = simulate(ctx, EVENT, { closedSegments: [], closedFacilities: [], weatherExposedClosed: true });
    expect(link(rain, 'route:nr-med-out').status).toBe('detour');

    const exit = simulate(ctx, EVENT, { closedSegments: [], closedFacilities: ['exit-d'] });
    expect(exit.gaps.some((g) => g.severity === 'critical' && g.area.startsWith('Zone D'))).toBe(true);

    const med = simulate(ctx, EVENT, { closedSegments: [], closedFacilities: [], unavailableResponders: ['r-med1'] });
    // The ambulance (vehicle) can still reach some zones; every zone still lists its coverage explicitly.
    expect(med.coverage).toHaveLength(4);
    expect(med.coverage.every((c) => !c.medical.includes('Medical Team 1 (first aid)'))).toBe(true);

    const comms = simulate(ctx, EVENT, { closedSegments: [], closedFacilities: [], commsLostZones: ['zone-c', 'zone-a'] });
    expect(comms.comms.find((c) => c.zoneId === 'zone-c')!.gap).toBe(true); // no fallback recorded
    expect(comms.comms.find((c) => c.zoneId === 'zone-a')!.gap).toBe(false);
    expect(comms.statement).toMatch(/gap/);
  });

  it('simulation never changes live data, and a clean scenario is not called "safe"', async () => {
    const { app, ctx } = makeApp();
    const c = await loginAs(app, 'coord.demo');
    const before = JSON.stringify(ctx.store.segments(EVENT));
    const res = await post(c, `/api/events/${EVENT}/resilience/simulate`, { scenario: { closedSegments: ['s17', 's20'], closedFacilities: ['exit-d'] } });
    expect(res.status).toBe(200);
    expect(JSON.stringify(ctx.store.segments(EVENT))).toBe(before);
    expect(ctx.store.facilities(EVENT).find((f) => f.id === 'exit-d')!.status).toBe('open');
    const clean = simulate(ctx, EVENT, { closedSegments: [], closedFacilities: [] });
    expect(clean.statement).toMatch(/not a safety certification/);
    expect((await post(c, `/api/events/${EVENT}/resilience/simulate`, { scenario: { closedSegments: ['nope'], closedFacilities: [] } })).status).toBe(400);
  });

  it('records stress tests for the readiness review (stewards cannot)', async () => {
    const { app, ctx } = makeApp();
    const c = await loginAs(app, 'coord.demo');
    const res = await post(c, `/api/events/${EVENT}/stress-tests`, { name: 'Monsoon downpour', scenario: { closedSegments: [], closedFacilities: [], weatherExposedClosed: true } });
    expect(res.status).toBe(200);
    const snap = (await c.get(`/api/events/${EVENT}/snapshot`)).body.data;
    expect(snap.stressTests[0].name).toBe('Monsoon downpour');
    expect(ctx.store.get("SELECT 1 FROM audit_log WHERE action = 'stress_test.run'")).toBeTruthy();
    const s = await loginAs(app, 'steward.gateb');
    expect((await post(s, `/api/events/${EVENT}/stress-tests`, { name: 'x x x', scenario: { closedSegments: [], closedFacilities: [] } })).status).toBe(403);
  });

  it('live closures create an access-gap alert and raise medical-access risk', async () => {
    const { app } = makeApp();
    const c = await loginAs(app, 'coord.demo');
    await post(c, '/api/demo/inject/close_lower_road');
    let snap = (await c.get(`/api/events/${EVENT}/snapshot`)).body.data;
    expect(snap.access.links.find((l: any) => l.link.id === 'route:nr-med-out').status).toBe('detour');
    await post(c, '/api/demo/inject/close_ring_road');
    snap = (await c.get(`/api/events/${EVENT}/snapshot`)).body.data;
    expect(snap.access.links.find((l: any) => l.link.id === 'route:nr-med-out').status).toBe('lost');
    expect(snap.notifications.some((n: any) => n.level === 'critical' && /Medical vehicle route/.test(n.title))).toBe(true);
    // Closing the only walking links from the medical post into Zone B raises that zone.
    await post(c, '/api/segments/s06/status', { status: 'closed', reason: 'test', source: 'test' });
    await post(c, '/api/segments/s07/status', { status: 'closed', reason: 'test', source: 'test' });
    snap = (await c.get(`/api/events/${EVENT}/snapshot`)).body.data;
    const zb = snap.risks.find((r: any) => r.zoneId === 'zone-b');
    expect(zb.conditions.map((x: any) => x.code)).toContain('MEDICAL_ACCESS_LOST');
    expect(['elevated', 'critical']).toContain(zb.level);
  });
});

describe('interactive exercise', () => {
  it('injects labelled simulated events through the normal workflow', async () => {
    const { app, ctx } = makeApp();
    const c = await loginAs(app, 'coord.demo');
    for (const key of ['congestion_gate_b', 'medical_zone_d', 'conflicting_estimate', 'comms_loss_zone_c', 'rain_advisory', 'block_exit_d', 'medical_team_unavailable']) {
      const r = await post(c, `/api/demo/inject/${key}`);
      expect(r.status, key).toBe(200);
    }
    const incs = ctx.store.incidents(EVENT);
    expect(incs.length).toBe(3);
    expect(incs.every((i) => i.description.startsWith('[SIMULATED]') && i.status === 'submitted')).toBe(true);
    expect(ctx.store.all("SELECT * FROM audit_log WHERE action = 'exercise.inject'")).toHaveLength(7);
    const snap = (await c.get(`/api/events/${EVENT}/snapshot`)).body.data;
    expect(snap.risks.find((r: any) => r.zoneId === 'zone-d').level).toBe('critical'); // required exit blocked
    expect(snap.risks.find((r: any) => r.zoneId === 'zone-a').conditions.map((x: any) => x.code)).toContain('ESTIMATES_CONFLICT');
    expect(snap.responders.find((r: any) => r.id === 'r-med1').status).toBe('off_duty');
    expect((await post(c, '/api/demo/inject/block_exit_d')).status).toBe(409); // not repeated
    expect((await post(c, '/api/demo/inject/unknown')).status).toBe(404);
    const s = await loginAs(app, 'steward.gateb');
    expect((await post(s, '/api/demo/inject/medical_zone_d')).status).toBe(403);
  });

  it('responder availability can be toggled with a reason, never mid-assignment', async () => {
    const { app } = makeApp();
    const c = await loginAs(app, 'coord.demo');
    expect((await post(c, '/api/responders/r-alpha/availability', { available: false, reason: '' })).status).toBe(400);
    expect((await post(c, '/api/responders/r-alpha/availability', { available: false, reason: 'Break' })).status).toBe(200);
    expect((await post(c, '/api/responders/r-alpha/availability', { available: false, reason: 'Again' })).status).toBe(409);
    expect((await post(c, '/api/responders/r-alpha/availability', { available: true, reason: 'Back' })).status).toBe(200);
  });
});

describe('robustness', () => {
  it('simultaneous edits: only one of two concurrent verifications succeeds', async () => {
    const { app } = makeApp();
    const s = await loginAs(app, 'steward.gateb');
    const c1 = await loginAs(app, 'coord.demo');
    const c2 = await loginAs(app, 'admin.demo');
    const id = (await post(s, `/api/events/${EVENT}/incidents`, { category: 'medical', zoneId: 'zone-d', description: 'Person fainted', severityEstimate: 'high' })).body.data.incident.id;
    const [a, b] = await Promise.all([post(c1, `/api/incidents/${id}/transition`, { to: 'rejected', note: 'dup' }), post(c2, `/api/incidents/${id}/transition`, { to: 'verified', note: 'radio' })]);
    expect([a.status, b.status].sort()).toEqual([200, 409]);
  });

  it('after a decline, route feasibility is rechecked before reassignment', async () => {
    const { app, ctx } = makeApp();
    const s = await loginAs(app, 'steward.gateb');
    const c = await loginAs(app, 'coord.demo');
    const r = await loginAs(app, 'team.alpha');
    const id = (await post(s, `/api/events/${EVENT}/incidents`, { category: 'crowd_congestion', zoneId: 'zone-b', description: 'Queue', severityEstimate: 'moderate' })).body.data.incident.id;
    await post(c, `/api/incidents/${id}/transition`, { to: 'verified' });
    const asg = (await post(c, `/api/incidents/${id}/assignments`, { responderId: 'r-alpha' })).body.data.id;
    await post(r, `/api/assignments/${asg}/status`, { status: 'unable', note: 'Path blocked by crowd' });
    const h = ctx.store.incidentUpdates(id).find((u) => u.kind === 'feasibility');
    expect(h?.note).toMatch(/Route feasibility rechecked: \d+ of \d+ available team/);
  });

  it('upgrades a database created by the previous schema version', () => {
    const dir = mkdtempSync(join(tmpdir(), 'hc-mig-'));
    const path = join(dir, 'old.db');
    const old = new DatabaseSync(path);
    old.exec(`CREATE TABLE zones (id TEXT PRIMARY KEY, event_id TEXT NOT NULL, name TEXT NOT NULL, polygon TEXT NOT NULL, capacity INTEGER, watch_pct REAL NOT NULL DEFAULT 80, elevated_pct REAL NOT NULL DEFAULT 95, critical_pct REAL, required_exit_ids TEXT NOT NULL DEFAULT '[]', exit_ids TEXT NOT NULL DEFAULT '[]', notes TEXT NOT NULL DEFAULT '');
      CREATE TABLE route_segments (id TEXT PRIMARY KEY, event_id TEXT NOT NULL, name TEXT NOT NULL, from_node TEXT NOT NULL, to_node TEXT NOT NULL, distance_m REAL NOT NULL, modes TEXT NOT NULL, access TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open', status_reason TEXT, status_source TEXT, status_updated_at TEXT NOT NULL, approved INTEGER NOT NULL DEFAULT 1, constraint_note TEXT NOT NULL DEFAULT '', terrain_note TEXT NOT NULL DEFAULT '', path TEXT NOT NULL DEFAULT '[]');`);
    old.close();
    const store = new Store(path);
    const cols = (t: string) => (store.all(`PRAGMA table_info(${t})`) as { name: string }[]).map((c) => c.name);
    expect(cols('zones')).toContain('comms_fallback');
    expect(cols('route_segments')).toContain('weather_exposed');
    expect(store.get("SELECT value FROM meta WHERE key = 'schema_version'")).toEqual({ value: '2' });
  });
});
