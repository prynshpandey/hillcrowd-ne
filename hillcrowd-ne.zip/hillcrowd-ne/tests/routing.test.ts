import { describe, expect, it } from 'vitest';
import { findRoute, validateNamedRoutes, accessAllows } from '../shared/routing';
import type { NamedRoute, RouteNode, RouteSegment } from '../shared/types';

const node = (id: string): RouteNode => ({ id, eventId: 'e', name: id.toUpperCase(), lat: 0, lng: 0, facilityId: null });
const seg = (id: string, from: string, to: string, d: number, p: Partial<RouteSegment> = {}): RouteSegment => ({
  id, eventId: 'e', name: id, fromNode: from, toNode: to, distanceM: d, modes: ['foot', 'vehicle'], access: 'public', status: 'open',
  statusReason: null, statusSource: null, statusUpdatedAt: '2026-10-15T10:00:00Z', approved: true, constraintNote: '', terrainNote: '', weatherExposed: false, path: [], ...p,
});

// a —100— b —100— d   (short)
// a —150— c —150— d   (long)
const nodes = ['a', 'b', 'c', 'd'].map(node);
const base = () => [seg('ab', 'a', 'b', 100), seg('bd', 'b', 'd', 100), seg('ac', 'a', 'c', 150), seg('cd', 'c', 'd', 150)];

describe('route feasibility engine', () => {
  it('finds the shortest valid route in the configured network', () => {
    const r = findRoute(nodes, base(), { from: 'a', to: 'd', mode: 'foot', access: 'public' });
    expect(r.found).toBe(true);
    expect(r.segmentIds).toEqual(['ab', 'bd']);
    expect(r.distanceM).toBe(200);
    expect(r.approvalStatus).toBe('approved_network');
  });

  it('excludes closed segments and reports why', () => {
    const segs = base();
    segs[1] = { ...segs[1], status: 'closed', statusReason: 'Landslide debris' };
    const r = findRoute(nodes, segs, { from: 'a', to: 'd', mode: 'foot', access: 'public' });
    expect(r.segmentIds).toEqual(['ac', 'cd']);
    expect(r.excludedSegments).toContainEqual({ id: 'bd', name: 'bd', reason: 'Closed: Landslide debris' });
  });

  it('returns found=false (never invents a route) when no path exists', () => {
    const segs = base().map((s) => (s.id === 'bd' || s.id === 'cd' ? { ...s, status: 'closed' as const } : s));
    const r = findRoute(nodes, segs, { from: 'a', to: 'd', mode: 'foot', access: 'public' });
    expect(r.found).toBe(false);
    expect(r.segmentIds).toEqual([]);
    expect(r.distanceM).toBeNull();
    expect(r.reason).toMatch(/No valid foot route/);
  });

  it('respects travel mode', () => {
    const segs = base().map((s) => (s.id === 'ab' ? { ...s, modes: ['foot' as const] } : s));
    expect(findRoute(nodes, segs, { from: 'a', to: 'd', mode: 'vehicle', access: 'public' }).segmentIds).toEqual(['ac', 'cd']);
  });

  it('respects access restrictions', () => {
    const segs = base().map((s) => (s.id === 'ab' ? { ...s, access: 'emergency' as const } : s));
    expect(findRoute(nodes, segs, { from: 'a', to: 'd', mode: 'foot', access: 'public' }).segmentIds).toEqual(['ac', 'cd']);
    expect(findRoute(nodes, segs, { from: 'a', to: 'd', mode: 'foot', access: 'emergency' }).segmentIds).toEqual(['ab', 'bd']);
    expect(accessAllows('staff', 'public')).toBe(true);
    expect(accessAllows('staff', 'emergency')).toBe(false);
  });

  it('never uses unapproved segments', () => {
    const segs = base().map((s) => (s.id === 'ab' ? { ...s, approved: false } : s));
    expect(findRoute(nodes, segs, { from: 'a', to: 'd', mode: 'foot', access: 'public' }).segmentIds).toEqual(['ac', 'cd']);
  });

  it('flags segments under review, or avoids them on request', () => {
    const segs = base().map((s) => (s.id === 'ab' ? { ...s, status: 'under_review' as const, statusReason: 'Rain advisory' } : s));
    const r = findRoute(nodes, segs, { from: 'a', to: 'd', mode: 'foot', access: 'public' });
    expect(r.segmentIds).toEqual(['ab', 'bd']);
    expect(r.warnings[0]).toMatch(/under review/);
    expect(findRoute(nodes, segs, { from: 'a', to: 'd', mode: 'foot', access: 'public', avoidUnderReview: true }).segmentIds).toEqual(['ac', 'cd']);
  });

  it('invalidates approved routes that depend on a closed segment and proposes an alternative', () => {
    const route: NamedRoute = { id: 'r1', eventId: 'e', name: 'R1', purpose: '', mode: 'vehicle', access: 'public', fromNode: 'a', toNode: 'd', segmentIds: ['ab', 'bd'], approvedBy: null, approvedAt: null };
    const segs = base().map((s) => (s.id === 'bd' ? { ...s, status: 'closed' as const } : s));
    const [v] = validateNamedRoutes(nodes, segs, [route]);
    expect(v.valid).toBe(false);
    expect(v.blockedSegments.map((b) => b.id)).toEqual(['bd']);
    expect(v.alternative?.found).toBe(true);
    expect(v.alternative?.segmentIds).toEqual(['ac', 'cd']);
    const [ok] = validateNamedRoutes(nodes, base(), [route]);
    expect(ok.valid).toBe(true);
    expect(ok.alternative).toBeNull();
  });

  it('handles unknown origin safely', () => {
    expect(findRoute(nodes, base(), { from: 'zz', to: 'd', mode: 'foot', access: 'public' }).found).toBe(false);
  });
});
