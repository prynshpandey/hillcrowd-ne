#!/usr/bin/env bash
# HillCrowd NE — one-step local setup for macOS / Linux.
# Installs npm packages, creates the database with demo data, and builds the app.
set -e
cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is not installed. Install Node.js 22 LTS (22.13 or newer) from https://nodejs.org and run this script again."
  exit 1
fi
NODE_VER=$(node -p "process.versions.node")
if ! node -e "const [a,b]=process.versions.node.split('.').map(Number); process.exit(a>22||(a===22&&b>=13)?0:1)"; then
  echo "Node.js $NODE_VER found, but HillCrowd NE needs 22.13 or newer. Install the current LTS from https://nodejs.org and run this script again."
  exit 1
fi
echo "Node.js $NODE_VER OK"

echo "Installing packages (npm install)…"
npm install
echo "Creating database, seeding demo data and building the app…"
npm run setup

echo ""
echo "Setup complete. Start the app with:  npm start"
echo "Then open http://localhost:4000 (demo password: hillcrowd-demo)"
