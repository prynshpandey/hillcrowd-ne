# HillCrowd NE — Demo script (≈5 minutes)

**Story in one line:** *Find access gaps before the event, then coordinate an accountable response when things go wrong during it.*

## Before you start (off-stage, 2 min)
- Run `npm start` and open `http://localhost:4000`. Sign in as **coord.demo** from the DEMO ACCESS panel.
- On the Overview, press **Reset demo scenario** for fresh timestamps. Crowd estimates go stale after 15 minutes, and the app will honestly say so.
- Optional: open a phone-sized window signed in as **team.alpha** (`/respond`) to show acknowledgement live.
- Look at the chip at the bottom-left of the map. It says whether real tiles loaded or the **fallback grid** is in use. If it says fallback, see the note at the end.

## Script

| Time | Say | Click | Audience sees | Shows |
|---|---|---|---|---|
| 0:00–0:30 | "HillCrowd NE helps an event control room in Shillong in two ways: test the venue's access *before* the event, and coordinate an accountable response *during* it. This is a fictional venue placed in the Shillong area, labelled as demo data." | Overview | Situation hero ("All zones within configured limits…"), live mini-map, zone cards with **trend arrows and sparklines** (Zone B rising, Zone C falling) | First impression; honest labelling |
| 0:30–1:30 | "Hill venues often depend on a few constrained roads. Before attendees arrive, we stress-test the approved route network." | **Resilience Lab** | 11 critical access links, **3 single points of failure**. The *Medical access lane* alone cuts both ambulance routes | Route resilience (signature) |
| | "Say rain closes the steep lower service road." | Preset **Lower service road closed** | Purple **detour** via the upper ring road: extra distance, "narrow bends; one ambulance at a time" | Explained alternatives |
| | "Now the detour fails too." | Preset **…and the ring-road detour fails** | **"No approved route available"** — a critical gap. "The venue plan has no valid alternative. Do not improvise." | Never invents a route |
| | "We record that test so the gap goes into the readiness review." | Type a name → **Record** | Stress-test log entry; Overview readiness card shows "Last stress test: 1 gap" | Readiness evidence |
| 1:30–2:10 | "Now the event is live. A steward reports congestion at Gate B." | Overview → Run step 1, then step 2 | Zone B **Watch → Elevated**, "Why this level" shows sources, timestamps and the rising trend; the playbook is proposed | Detect → verify; explainable risk |
| 2:10–2:50 | *(to the judge)* "You can now throw problems at it." | **Exercise** → *Lower service road closed*, then *Upper ring road (north–east) closed* | Red **ACCESS GAP** banner on the Overview, critical notification, blocked route on the mini-map | Live access-gap detection |
| | | *(optional)* **Exercise** → *Exit D blocked* | Zone D → **Critical**: "required exit unavailable" | Designated critical condition |
| 2:50–3:40 | "We assign Steward Team Alpha. Every stage has a target by severity and incident type, and the screen says who must act next." | Overview → Run step 3 (sample rain advisory), then step 5 — step 4 already counts as done because the Exercise closed the lower road → Incidents → HC-0001 | **Stage clock** in the queue; stage timeline "Waiting on Steward Team Alpha: acknowledge…"; route checked against closures | Accountability |
| | "If they don't accept in time, it escalates — and it names the stage, not just 'late'." | *(wait ~3 min, or skip)* | "Acceptance has taken 4 min (target 3 min)… Next: Steward Team Alpha" | Stage escalation |
| 3:40–4:10 | "The team acknowledges, arrives and resolves; the control room confirms closure." | Run steps 6–9 *(or Acknowledge on the phone)* | Each stage turns green or amber against its target | Respond; verification of resolution |
| 4:10–4:50 | "Afterwards we replay the whole exercise from the audit log." | **Analytics** → **Exercise replay** → Play | Lanes fill: reported, verified, decisions (closures), acknowledged, risk changes. Simulated events labelled | Review |
| | "Stage times show *where* time went, not who performed badly — a long travel stage may be the terrain or a closed road." | Scroll to *Incident timings* | Stages over target, with route context | Honest metrics |
| 4:50–5:00 | "Field reports also work with poor signal: saved on the device, then *Server confirmed* only when the control room actually has them." | *(optional)* phone in airplane mode → submit → reconnect | *Saved on device → Waiting to sync → Server confirmed*, last-sync time | Trustworthy offline |

## If map tiles are unavailable
The map shows "Fallback grid — map tiles unavailable", and every operational layer still works. Say: *"With no internet, the configured venue layout still works — deliberate for hill venues with patchy connectivity."*

## If something goes wrong
On the Overview, **Reset demo scenario** restores the initial state in a second. You can undo individual exercise closures in **Route Planning** (Reopen).

## Don't claim
- That it predicts landslides or forecasts crowds.
- That it replaces IMD, SDMA or 112, or dispatches ambulances.
- That it uses live GPS or measures crowd density.
- That it has reduced response times or saved lives — there is no real-world baseline yet.
- That the audit log is tamper-proof. Say instead: "the application cannot edit or delete it; production would add write-once storage".
