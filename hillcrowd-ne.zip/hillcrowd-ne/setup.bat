@echo off
REM HillCrowd NE - one-step local setup for Windows.
REM Installs npm packages, creates the database with demo data, and builds the app.
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Install Node.js 22 LTS ^(22.13 or newer^) from https://nodejs.org and run this script again.
  pause
  exit /b 1
)
node -e "const [a,b]=process.versions.node.split('.').map(Number); process.exit(a>22||(a===22&&b>=13)?0:1)"
if errorlevel 1 (
  echo HillCrowd NE needs Node.js 22.13 or newer. Install the current LTS from https://nodejs.org and run this script again.
  pause
  exit /b 1
)

echo Installing packages ^(npm install^)...
call npm install
if errorlevel 1 ( pause & exit /b 1 )
echo Creating database, seeding demo data and building the app...
call npm run setup
if errorlevel 1 ( pause & exit /b 1 )

echo.
echo Setup complete. Start the app with:  npm start
echo Then open http://localhost:4000  (demo password: hillcrowd-demo)
pause
