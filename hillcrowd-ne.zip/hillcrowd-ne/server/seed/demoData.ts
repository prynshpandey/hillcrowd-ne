/**
 * DEMONSTRATION DATA — FICTIONAL.
 *
 * The venue layout below ("Ridge Grounds") is invented for demonstration. It is positioned
 * illustratively in the Shillong area (East Khasi Hills district, Meghalaya) so that the real
 * OpenStreetMap basemap gives regional context, but it does NOT describe any real venue,
 * road, facility, capacity or emergency resource. All "external" roads and the ambulance
 * handover point are fictional demo constructs.
 */
import { offsetM, pathLengthM } from '../../shared/geo';
import type { AccessLevel, FacilityKind, Playbook, TravelMode } from '../../shared/types';

export const DEMO_EVENT_ID = 'evt-demo-shillong';
/** Illustrative origin in the Shillong area. Not a surveyed venue location. */
export const DEMO_ORIGIN: [number, number] = [25.5745, 91.879];
export const DEMO_PASSWORD = 'hillcrowd-demo';

export const DEMO_USERS = [
  { id: 'usr-admin', username: 'admin.demo', displayName: 'Demo Administrator', role: 'admin' },
  { id: 'usr-coord', username: 'coord.demo', displayName: 'Demo Coordinator (Control Room)', role: 'coordinator' },
  { id: 'usr-stw-b', username: 'steward.gateb', displayName: 'Demo Steward – Gate B', role: 'steward' },
  { id: 'usr-stw-m', username: 'steward.market', displayName: 'Demo Steward – Market', role: 'steward' },
  { id: 'usr-alpha', username: 'team.alpha', displayName: 'Steward Team Alpha (demo)', role: 'responder' },
  { id: 'usr-medic', username: 'medic.one', displayName: 'Medical Team 1 (demo)', role: 'responder' },
] as const;

const P = (e: number, n: number) => offsetM(DEMO_ORIGIN, e, n);
const poly = (pts: [number, number][]) => pts.map(([e, n]) => P(e, n));

export interface LayoutNode { key: string; name: string; e: number; n: number }
export interface LayoutFacility { key: string; kind: FacilityKind; name: string; node: string; zone: string | null; capacityPerMin?: number; notes?: string }
export interface LayoutSegment { key: string; name: string; from: string; to: string; modes: TravelMode[]; access: AccessLevel; via?: [number, number][]; constraint?: string; terrain?: string; weather?: boolean }

export const LAYOUT = {
  boundary: poly([[-220, -160], [220, -160], [220, 160], [-220, 160]]),
  zones: [
    { key: 'a', name: 'Zone A – Main Stage Arena', pts: [[-200, -20], [40, -20], [40, 150], [-200, 150]] as [number, number][], capacity: 6000, exits: ['gate-a', 'exit-d'], required: ['gate-a'], notes: 'Standing arena in front of the main stage (fictional).', comms: 'Radio channel 1 + stage PA system (demo)' },
    { key: 'b', name: 'Zone B – Gate B Entry Plaza', pts: [[60, 40], [210, 40], [210, 150], [60, 150]] as [number, number][], capacity: 1500, exits: ['gate-b', 'gate-c'], required: ['gate-b'], notes: 'Main public entry plaza; queue barriers at Gate B (fictional).', comms: 'Radio channel 1 (gate team) (demo)' },
    { key: 'c', name: 'Zone C – Food & Craft Market', pts: [[60, -140], [210, -140], [210, 30], [60, 30]] as [number, number][], capacity: 2500, exits: ['gate-c', 'exit-e'], required: ['exit-e'], notes: 'Stalls on lower ground on the eastern side (fictional).', comms: '' },
    { key: 'd', name: 'Zone D – South Lawn & Family Area', pts: [[-200, -140], [40, -140], [40, -30], [-200, -30]] as [number, number][], capacity: 2000, exits: ['exit-d', 'exit-e'], required: ['exit-d'], notes: 'Seated lawn and family area (fictional).', comms: 'Radio channel 2 — coverage check pending (demo)' },
  ],
  nodes: [
    { key: 'n-ga', name: 'Gate A (west)', e: -220, n: 60 },
    { key: 'n-gb', name: 'Gate B (main entry)', e: 150, n: 160 },
    { key: 'n-gc', name: 'Gate C (service gate)', e: 220, n: -60 },
    { key: 'n-ed', name: 'Exit D (south)', e: -80, n: -160 },
    { key: 'n-ee', name: 'Exit E (south-east)', e: 120, n: -160 },
    { key: 'n-med', name: 'Medical Post M1', e: 0, n: -60 },
    { key: 'n-ctrl', name: 'Event Control Room', e: -40, n: 20 },
    { key: 'n-j1', name: 'Central junction J1', e: 0, n: 30 },
    { key: 'n-j2', name: 'East junction J2', e: 130, n: 0 },
    { key: 'n-j3', name: 'North-east junction J3', e: 130, n: 100 },
    { key: 'n-j4', name: 'South junction J4', e: -20, n: -120 },
    { key: 'n-j5', name: 'West junction J5', e: -150, n: 40 },
    { key: 'n-ap1', name: 'Assembly Point 1 (north)', e: 150, n: 240 },
    { key: 'n-ap2', name: 'Assembly Point 2 (west)', e: -300, n: 60 },
    { key: 'n-ap3', name: 'Assembly Point 3 (south)', e: -60, n: -240 },
    { key: 'n-ap4', name: 'Assembly Point 4 (east)', e: 300, n: -140 },
    { key: 'n-xn', name: 'North road junction (demo)', e: 150, n: 330 },
    { key: 'n-xe', name: 'Ambulance Handover Point H (demo)', e: 340, n: -60 },
    { key: 'n-xse', name: 'South-east lane junction (demo)', e: 230, n: -230 },
    { key: 'n-xw', name: 'West approach junction (demo)', e: -330, n: 160 },
  ] satisfies LayoutNode[],
  facilities: [
    { key: 'gate-a', kind: 'gate', name: 'Gate A (west)', node: 'n-ga', zone: 'a', capacityPerMin: 60, notes: 'Entry and exit.' },
    { key: 'gate-b', kind: 'gate', name: 'Gate B (main entry)', node: 'n-gb', zone: 'b', capacityPerMin: 90, notes: 'Primary public entry with queue barriers.' },
    { key: 'gate-c', kind: 'gate', name: 'Gate C (service gate)', node: 'n-gc', zone: 'c', capacityPerMin: 40, notes: 'Service and emergency vehicle gate.' },
    { key: 'exit-d', kind: 'exit', name: 'Exit D (south)', node: 'n-ed', zone: 'd', capacityPerMin: 70 },
    { key: 'exit-e', kind: 'exit', name: 'Exit E (south-east)', node: 'n-ee', zone: 'c', capacityPerMin: 50 },
    { key: 'med-1', kind: 'medical', name: 'Medical Post M1 (first aid)', node: 'n-med', zone: 'd' },
    { key: 'ctrl', kind: 'control', name: 'Event Control Room', node: 'n-ctrl', zone: 'a' },
    { key: 'ap-1', kind: 'assembly', name: 'Assembly Point 1 (north)', node: 'n-ap1', zone: null },
    { key: 'ap-2', kind: 'assembly', name: 'Assembly Point 2 (west)', node: 'n-ap2', zone: null },
    { key: 'ap-3', kind: 'assembly', name: 'Assembly Point 3 (south)', node: 'n-ap3', zone: null },
    { key: 'ap-4', kind: 'assembly', name: 'Assembly Point 4 (east)', node: 'n-ap4', zone: null },
    { key: 'handover-h', kind: 'handover', name: 'Ambulance Handover Point H (demo)', node: 'n-xe', zone: null, notes: 'Fictional handover point. The system does not dispatch real ambulances.' },
  ] satisfies LayoutFacility[],
  segments: [
    { key: 's01', name: 'Gate B inner walkway', from: 'n-gb', to: 'n-j3', modes: ['foot'], access: 'public' },
    { key: 's02', name: 'East service lane (north)', from: 'n-j3', to: 'n-j2', modes: ['foot', 'vehicle'], access: 'staff' },
    { key: 's03', name: 'East service lane (south)', from: 'n-j2', to: 'n-gc', modes: ['foot', 'vehicle'], access: 'staff' },
    { key: 's04', name: 'Central cross path', from: 'n-j2', to: 'n-j1', modes: ['foot', 'vehicle'], access: 'staff', constraint: 'Vehicles at walking pace only (configured)' },
    { key: 's05', name: 'Control room path', from: 'n-j1', to: 'n-ctrl', modes: ['foot'], access: 'staff' },
    { key: 's06', name: 'Medical access lane', from: 'n-j1', to: 'n-med', modes: ['foot', 'vehicle'], access: 'staff' },
    { key: 's07', name: 'Medical post south path', from: 'n-med', to: 'n-j4', modes: ['foot'], access: 'public' },
    { key: 's08', name: 'Exit D path', from: 'n-j4', to: 'n-ed', modes: ['foot'], access: 'public' },
    { key: 's09', name: 'Exit E path', from: 'n-j4', to: 'n-ee', modes: ['foot'], access: 'public', via: [[60, -150]] },
    { key: 's10', name: 'Arena west path', from: 'n-j1', to: 'n-j5', modes: ['foot', 'vehicle'], access: 'staff' },
    { key: 's11', name: 'Gate A approach', from: 'n-j5', to: 'n-ga', modes: ['foot', 'vehicle'], access: 'public' },
    { key: 's12', name: 'Arena crowd walkway', from: 'n-j3', to: 'n-j1', modes: ['foot'], access: 'public', constraint: 'Crowded during performances (configured)' },
    { key: 's13', name: 'Gate B to Assembly Point 1', from: 'n-gb', to: 'n-ap1', modes: ['foot'], access: 'public' },
    { key: 's14', name: 'Gate A to Assembly Point 2', from: 'n-ga', to: 'n-ap2', modes: ['foot'], access: 'public' },
    { key: 's15', name: 'Exit D to Assembly Point 3', from: 'n-ed', to: 'n-ap3', modes: ['foot'], access: 'public' },
    { key: 's16', name: 'North approach road (demo)', from: 'n-ap1', to: 'n-xn', modes: ['foot', 'vehicle'], access: 'public' },
    { key: 's17', name: 'Lower service road (Gate C – Handover H)', from: 'n-gc', to: 'n-xe', modes: ['foot', 'vehicle'], access: 'emergency', via: [[280, -90]], constraint: 'Single lane, no passing (configured)', terrain: 'Steep descent recorded by venue staff during site visit (demo)', weather: true },
    { key: 's18', name: 'West approach lane (demo)', from: 'n-ga', to: 'n-xw', modes: ['foot', 'vehicle'], access: 'public' },
    { key: 's19', name: 'Upper ring road, west–north (demo)', from: 'n-xw', to: 'n-xn', modes: ['foot', 'vehicle'], access: 'public', via: [[-200, 330]], constraint: 'Shared with public traffic; expect slower movement during event hours (configured)' },
    { key: 's20', name: 'Upper ring road, north–east (demo)', from: 'n-xn', to: 'n-xe', modes: ['foot', 'vehicle'], access: 'public', via: [[330, 200]], constraint: 'Narrow bends; one ambulance at a time (configured)' },
    { key: 's21', name: 'Exit E to south-east lane', from: 'n-ee', to: 'n-xse', modes: ['foot'], access: 'public' },
    { key: 's22', name: 'South-east lane to Handover H (demo)', from: 'n-xse', to: 'n-xe', modes: ['foot', 'vehicle'], access: 'public', terrain: 'Low-lying section; water-logging recorded in past heavy rain, confirmed by venue staff (demo)', weather: true },
    { key: 's23', name: 'Gate C to Assembly Point 4', from: 'n-gc', to: 'n-ap4', modes: ['foot'], access: 'public' },
    { key: 's24', name: 'South-east lane to Assembly Point 4', from: 'n-xse', to: 'n-ap4', modes: ['foot'], access: 'public' },
  ] satisfies LayoutSegment[],
  namedRoutes: [
    { key: 'nr-med-out', name: 'Medical vehicle route: Medical Post M1 → Handover H', purpose: 'Patient transfer to the ambulance handover point', mode: 'vehicle' as TravelMode, access: 'emergency' as AccessLevel, from: 'n-med', to: 'n-xe', segs: ['s06', 's04', 's03', 's17'] },
    { key: 'nr-amb-in', name: 'Ambulance entry: West approach → Medical Post M1', purpose: 'Emergency vehicle access into the venue', mode: 'vehicle' as TravelMode, access: 'emergency' as AccessLevel, from: 'n-xw', to: 'n-med', segs: ['s18', 's11', 's10', 's06'] },
    { key: 'nr-stw-gb', name: 'Steward route: Control Room → Gate B', purpose: 'Steward reinforcement of the main entry', mode: 'foot' as TravelMode, access: 'staff' as AccessLevel, from: 'n-ctrl', to: 'n-gb', segs: ['s05', 's12', 's01'] },
    { key: 'nr-evac-d', name: 'Zone D walk-out: Exit D → Assembly Point 3', purpose: 'Approved egress for the South Lawn', mode: 'foot' as TravelMode, access: 'public' as AccessLevel, from: 'n-ed', to: 'n-ap3', segs: ['s15'] },
  ],
  responders: [
    { key: 'r-alpha', name: 'Steward Team Alpha', team: 'Steward teams', kind: 'steward_team', modes: ['foot'] as TravelMode[], access: 'staff' as AccessLevel, base: 'n-ctrl', user: 'usr-alpha' },
    { key: 'r-bravo', name: 'Steward Team Bravo', team: 'Steward teams', kind: 'steward_team', modes: ['foot'] as TravelMode[], access: 'staff' as AccessLevel, base: 'n-j5', user: 'usr-stw-m' },
    { key: 'r-med1', name: 'Medical Team 1 (first aid)', team: 'Medical', kind: 'medical', modes: ['foot'] as TravelMode[], access: 'staff' as AccessLevel, base: 'n-med', user: 'usr-medic' },
    { key: 'r-amb', name: 'Ambulance Unit (simulated)', team: 'Medical', kind: 'ambulance', modes: ['vehicle'] as TravelMode[], access: 'emergency' as AccessLevel, base: 'n-med', user: null },
  ],
};

export function segmentPath(seg: LayoutSegment, nodeByKey: Map<string, LayoutNode>): [number, number][] {
  const a = nodeByKey.get(seg.from)!;
  const b = nodeByKey.get(seg.to)!;
  return [P(a.e, a.n), ...(seg.via ?? []).map(([e, n]) => P(e, n)), P(b.e, b.n)];
}

export const nodeLatLng = (n: LayoutNode) => P(n.e, n.n);
export const zonePolygon = (pts: [number, number][]) => poly(pts);
export const configuredLength = (path: [number, number][]) => Math.round(pathLengthM(path));

export const CHECKLIST_TEMPLATE: { key: string; label: string }[] = [
  { key: 'exit_availability', label: 'Exit availability and signage' },
  { key: 'gate_capacity', label: 'Gate throughput capacity vs. expected arrivals' },
  { key: 'bottlenecks', label: 'Known bottlenecks and queue areas' },
  { key: 'narrow_passages', label: 'Narrow passages and steep approaches' },
  { key: 'route_redundancy', label: 'Route redundancy (at least two approved routes per critical destination)' },
  { key: 'emergency_vehicle_access', label: 'Emergency vehicle access and handover point' },
  { key: 'medical_coverage', label: 'Medical coverage and first-aid posts' },
  { key: 'weather_access', label: 'Weather-related access constraints (rain, flooding, landslide-prone sections, where verified)' },
  { key: 'communication_coverage', label: 'Communication coverage (mobile signal, radio channels)' },
  { key: 'evacuation_assembly', label: 'Evacuation and assembly arrangements' },
];

export const DEMO_CHECKLIST_STATE: Record<string, { status: string; note: string }> = {
  exit_availability: { status: 'mitigation_verified', note: 'Exits A–E walked and signed during site visit (demo).' },
  gate_capacity: { status: 'mitigation_planned', note: 'Gate B expected to peak before headline act; extra lane planned, not yet verified (demo).' },
  bottlenecks: { status: 'no_issue', note: 'Queue barriers at Gate B plaza (demo).' },
  narrow_passages: { status: 'mitigation_verified', note: 'Lower service road is single-lane with a steep descent; restricted to emergency vehicles (demo).' },
  route_redundancy: { status: 'mitigation_verified', note: 'Upper ring road designated as the alternative vehicle route to Handover H (demo).' },
  emergency_vehicle_access: { status: 'no_issue', note: 'Ambulance entry via west approach (demo).' },
  medical_coverage: { status: 'no_issue', note: 'Medical Post M1 staffed; Medical Team 1 mobile on foot (demo).' },
  weather_access: { status: 'issue_identified', note: 'South-east lane has a low-lying section with past water-logging (confirmed by venue staff, demo). Monitor during rain.' },
  communication_coverage: { status: 'mitigation_planned', note: 'Weak mobile signal near South Lawn during site visit (demo); radio channel 2 assigned, coverage check pending.' },
  evacuation_assembly: { status: 'mitigation_verified', note: 'Four assembly points outside the boundary (demo).' },
};

export const PLAYBOOKS: Omit<Playbook, 'id'>[] = [
  {
    key: 'congestion',
    title: 'Crowd congestion',
    categories: ['crowd_congestion'],
    trigger: 'Verified congestion report, or occupancy at/above the configured elevated threshold.',
    escalation: 'Coordinator → event safety officer → designated safety authority.',
    steps: [
      { title: 'Confirm the crowd condition on the ground', detail: 'Steward observation or other available confirmation. Record what was seen.', approval: 'coordinator', dueMinutes: 2 },
      { title: 'Assign stewards to assess the affected zone', detail: 'Choose an available steward team with an approved walking route.', approval: 'coordinator', action: 'assign', dueMinutes: 3 },
      { title: 'Check availability of alternative exits and routes', detail: 'Review exits for the zone and any closed or under-review segments.', approval: 'coordinator', action: 'review_routes', dueMinutes: 5 },
      { title: 'Pause or regulate incoming entry (only if authorised)', detail: 'Operational change at the gate. Requires the designated safety authority; record who authorised it.', approval: 'safety_authority', dueMinutes: 5 },
      { title: 'Escalate if conditions continue to deteriorate', detail: 'Escalate to the safety officer per the event safety plan.', approval: 'coordinator' },
      { title: 'Record the outcome', detail: 'What was done and the zone condition afterwards.', approval: 'coordinator', action: 'record_outcome' },
    ],
  },
  {
    key: 'medical',
    title: 'Medical emergency',
    categories: ['medical'],
    trigger: 'Verified medical incident.',
    escalation: 'Coordinator → medical lead. External emergency services are contacted through official channels, not by this system.',
    steps: [
      { title: 'Confirm incident location and access point', detail: 'Check the marked location on the map and nearest network node.', approval: 'coordinator', dueMinutes: 1 },
      { title: 'Notify the designated medical team', detail: 'Assign the nearest available medical responder.', approval: 'coordinator', action: 'assign', dueMinutes: 2 },
      { title: 'Identify an approved, available access route', detail: 'Use the route planner; never improvise a route that is not in the approved network.', approval: 'coordinator', action: 'compute_route', dueMinutes: 3 },
      { title: 'Track acknowledgement and arrival', detail: 'Confirm the responder acknowledged and is on scene.', approval: 'coordinator' },
      { title: 'Record whether assistance was delivered', detail: 'Outcome only; avoid recording unnecessary personal medical details.', approval: 'coordinator', action: 'record_outcome' },
    ],
  },
  {
    key: 'blocked_exit',
    title: 'Blocked exit or gate',
    categories: ['exit_blockage'],
    trigger: 'Verified exit or gate blockage.',
    escalation: 'Coordinator → designated safety authority (immediately if the safety plan requires the exit).',
    steps: [
      { title: 'Mark the affected exit unavailable', detail: 'Updates zone risk and egress checks.', approval: 'coordinator', action: 'close_exit', dueMinutes: 1 },
      { title: 'Recalculate route feasibility', detail: 'Check which approved routes depend on the affected exit.', approval: 'coordinator', action: 'review_routes', dueMinutes: 2 },
      { title: 'Identify approved alternatives, if any', detail: 'If none exist the system says so; escalate.', approval: 'coordinator', dueMinutes: 3 },
      { title: 'Assign a team to clear or manage the blockage', detail: 'Steward or operations team.', approval: 'coordinator', action: 'assign', dueMinutes: 3 },
      { title: 'Assess whether the safety plan requires an immediate operational change', detail: 'Decision belongs to the designated safety authority; record who decided.', approval: 'safety_authority', dueMinutes: 5 },
    ],
  },
  {
    key: 'weather_route',
    title: 'Severe weather or route disruption',
    categories: ['weather', 'route_obstruction'],
    trigger: 'Verified weather concern, route obstruction, or a verified advisory affecting the venue.',
    escalation: 'Coordinator → event safety officer → district authorities via official channels.',
    steps: [
      { title: 'Record the source and timestamp of the advisory or observation', detail: 'Use the Advisories panel for official or sample advisories.', approval: 'coordinator', dueMinutes: 2 },
      { title: 'Mark affected routes or zones for review', detail: 'Segments under review stay visible with a warning; closures exclude them.', approval: 'coordinator', action: 'review_routes', dueMinutes: 3 },
      { title: 'Reassess emergency access', detail: 'Check approved medical and ambulance routes.', approval: 'coordinator', action: 'compute_route', dueMinutes: 5 },
      { title: 'Assign inspection or mitigation tasks', detail: 'Send a team to inspect the affected section.', approval: 'coordinator', action: 'assign', dueMinutes: 5 },
      { title: 'Record the authorised decision', detail: 'Any closure of public roads or public instruction is made by the authorised body, not by this system.', approval: 'safety_authority' },
    ],
  },
  {
    key: 'missing_person',
    title: 'Missing person',
    categories: ['missing_person'],
    trigger: 'Verified missing person report.',
    escalation: 'Coordinator → security lead → police through official channels.',
    steps: [
      { title: 'Record a minimal description at the control room', detail: 'Collect only what is needed to find the person; do not place personal details on the map.', approval: 'coordinator', dueMinutes: 2 },
      { title: 'Alert stewards at gates and exits', detail: 'Use the radio channel; this system does not broadcast to the public.', approval: 'coordinator', dueMinutes: 3 },
      { title: 'Assign a search team', detail: 'Steward team for the last known zone.', approval: 'coordinator', action: 'assign', dueMinutes: 5 },
      { title: 'Record the outcome', detail: 'Found / handed over / escalated.', approval: 'coordinator', action: 'record_outcome' },
    ],
  },
  {
    key: 'general',
    title: 'General operational issue',
    categories: ['infrastructure', 'communication', 'other'],
    trigger: 'Any other verified operational issue.',
    escalation: 'Coordinator → operations lead.',
    steps: [
      { title: 'Assess impact on crowd safety and access', detail: 'Does it affect exits, routes, medical access or communication?', approval: 'coordinator', dueMinutes: 5 },
      { title: 'Assign an appropriate team', detail: 'Operations or steward team.', approval: 'coordinator', action: 'assign', dueMinutes: 5 },
      { title: 'Record the outcome', detail: 'What was done.', approval: 'coordinator', action: 'record_outcome' },
    ],
  },
];
