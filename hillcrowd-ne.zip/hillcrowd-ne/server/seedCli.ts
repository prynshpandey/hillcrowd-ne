/** `npm run seed` — create the database, playbooks, demo users and the demo event (idempotent). */
import { Store } from './db';
import { Bus, type Ctx } from './context';
import { resetDemo, seedBase, seedDemoEvent } from './services/demo';

const ctx: Ctx = {
  store: new Store(process.env.DB_PATH ?? 'data/hillcrowd.db'),
  now: () => new Date(),
  bus: new Bus(),
  demoMode: (process.env.DEMO_MODE ?? 'true') !== 'false',
};

seedBase(ctx);
if (ctx.demoMode) {
  if (process.argv.includes('--reset')) resetDemo(ctx, null);
  else seedDemoEvent(ctx);
  console.log('Seeded playbooks, demo accounts and the demo event (fictional venue, Shillong context).');
} else {
  console.log('Seeded playbooks. DEMO_MODE=false, so no demo accounts or demo event were created.');
}
