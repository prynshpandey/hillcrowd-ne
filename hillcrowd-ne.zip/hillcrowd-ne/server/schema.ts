export const SCHEMA_VERSION = 2;

export const SCHEMA_SQL = `
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);

-- Guard flag used only by the demo reset to purge demo-scoped append-only rows.
CREATE TABLE IF NOT EXISTS sys_flags (key TEXT PRIMARY KEY, value INTEGER NOT NULL);
INSERT OR IGNORE INTO sys_flags (key, value) VALUES ('allow_demo_purge', 0);

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin','coordinator','steward','responder')),
  password_hash TEXT NOT NULL,
  is_demo INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS events (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  event_type TEXT NOT NULL,
  state TEXT NOT NULL,
  district TEXT NOT NULL,
  location_label TEXT NOT NULL,
  venue_name TEXT NOT NULL,
  venue_is_fictional INTEGER NOT NULL DEFAULT 1,
  starts_at TEXT NOT NULL,
  ends_at TEXT NOT NULL,
  expected_attendance INTEGER,
  venue_capacity INTEGER,
  control_contact TEXT NOT NULL DEFAULT '',
  center_lat REAL NOT NULL,
  center_lng REAL NOT NULL,
  zoom INTEGER NOT NULL DEFAULT 16,
  boundary TEXT NOT NULL DEFAULT '[]',
  is_demo INTEGER NOT NULL DEFAULT 0,
  settings TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS event_access (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  PRIMARY KEY (user_id, event_id)
);

CREATE TABLE IF NOT EXISTS zones (
  id TEXT PRIMARY KEY,
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  polygon TEXT NOT NULL,
  capacity INTEGER,
  watch_pct REAL NOT NULL DEFAULT 80,
  elevated_pct REAL NOT NULL DEFAULT 95,
  critical_pct REAL,
  required_exit_ids TEXT NOT NULL DEFAULT '[]',
  exit_ids TEXT NOT NULL DEFAULT '[]',
  notes TEXT NOT NULL DEFAULT '',
  comms_fallback TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_zones_event ON zones(event_id);

CREATE TABLE IF NOT EXISTS occupancy_observations (
  id TEXT PRIMARY KEY,
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  zone_id TEXT NOT NULL REFERENCES zones(id) ON DELETE CASCADE,
  value INTEGER NOT NULL CHECK (value >= 0),
  observed_at TEXT NOT NULL,
  source TEXT NOT NULL,
  reported_by TEXT REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_occ_zone ON occupancy_observations(zone_id, observed_at);

CREATE TABLE IF NOT EXISTS route_nodes (
  id TEXT PRIMARY KEY,
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  lat REAL NOT NULL,
  lng REAL NOT NULL,
  facility_id TEXT
);
CREATE INDEX IF NOT EXISTS idx_nodes_event ON route_nodes(event_id);

CREATE TABLE IF NOT EXISTS facilities (
  id TEXT PRIMARY KEY,
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('gate','exit','medical','assembly','control','handover')),
  name TEXT NOT NULL,
  lat REAL NOT NULL,
  lng REAL NOT NULL,
  zone_id TEXT REFERENCES zones(id) ON DELETE SET NULL,
  node_id TEXT REFERENCES route_nodes(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','closed')),
  status_reason TEXT,
  status_updated_at TEXT NOT NULL,
  capacity_per_min INTEGER,
  notes TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_fac_event ON facilities(event_id);

CREATE TABLE IF NOT EXISTS route_segments (
  id TEXT PRIMARY KEY,
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  from_node TEXT NOT NULL REFERENCES route_nodes(id) ON DELETE CASCADE,
  to_node TEXT NOT NULL REFERENCES route_nodes(id) ON DELETE CASCADE,
  distance_m REAL NOT NULL CHECK (distance_m >= 0),
  modes TEXT NOT NULL,
  access TEXT NOT NULL CHECK (access IN ('public','staff','emergency')),
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','under_review','closed')),
  status_reason TEXT,
  status_source TEXT,
  status_updated_at TEXT NOT NULL,
  approved INTEGER NOT NULL DEFAULT 1,
  constraint_note TEXT NOT NULL DEFAULT '',
  terrain_note TEXT NOT NULL DEFAULT '',
  weather_exposed INTEGER NOT NULL DEFAULT 0,
  path TEXT NOT NULL DEFAULT '[]'
);
CREATE INDEX IF NOT EXISTS idx_seg_event ON route_segments(event_id);

CREATE TABLE IF NOT EXISTS route_closures (
  id TEXT PRIMARY KEY,
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  segment_id TEXT NOT NULL REFERENCES route_segments(id) ON DELETE CASCADE,
  status TEXT NOT NULL,
  reason TEXT NOT NULL,
  source TEXT NOT NULL,
  advisory_id TEXT,
  created_by TEXT REFERENCES users(id),
  created_at TEXT NOT NULL,
  lifted_at TEXT,
  lifted_by TEXT REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_closure_event ON route_closures(event_id, created_at);

CREATE TABLE IF NOT EXISTS named_routes (
  id TEXT PRIMARY KEY,
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  purpose TEXT NOT NULL,
  mode TEXT NOT NULL,
  access TEXT NOT NULL,
  from_node TEXT NOT NULL REFERENCES route_nodes(id),
  to_node TEXT NOT NULL REFERENCES route_nodes(id),
  segment_ids TEXT NOT NULL,
  approved_by TEXT,
  approved_at TEXT
);

CREATE TABLE IF NOT EXISTS responders (
  id TEXT PRIMARY KEY,
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  team TEXT NOT NULL,
  kind TEXT NOT NULL,
  modes TEXT NOT NULL,
  access TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'available',
  base_node_id TEXT REFERENCES route_nodes(id),
  lat REAL,
  lng REAL,
  location_source TEXT,
  location_updated_at TEXT,
  user_id TEXT REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_resp_event ON responders(event_id);

CREATE TABLE IF NOT EXISTS incidents (
  id TEXT PRIMARY KEY,
  ref TEXT NOT NULL,
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  client_id TEXT UNIQUE,
  category TEXT NOT NULL,
  zone_id TEXT REFERENCES zones(id),
  lat REAL,
  lng REAL,
  description TEXT NOT NULL,
  severity_estimate TEXT NOT NULL,
  confirmed_severity TEXT,
  urgent INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL,
  reporter_id TEXT NOT NULL REFERENCES users(id),
  owner_id TEXT,
  created_local_at TEXT NOT NULL,
  received_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  verified_at TEXT,
  assigned_at TEXT,
  acknowledged_at TEXT,
  resolved_at TEXT,
  closed_at TEXT,
  merged_into TEXT REFERENCES incidents(id),
  possible_duplicate_of TEXT NOT NULL DEFAULT '[]',
  reopen_count INTEGER NOT NULL DEFAULT 0,
  is_demo INTEGER NOT NULL DEFAULT 0,
  attachment_note TEXT
);
CREATE INDEX IF NOT EXISTS idx_inc_event ON incidents(event_id, status);
CREATE INDEX IF NOT EXISTS idx_inc_reporter ON incidents(reporter_id);

CREATE TABLE IF NOT EXISTS incident_updates (
  id TEXT PRIMARY KEY,
  event_id TEXT NOT NULL,
  incident_id TEXT NOT NULL REFERENCES incidents(id),
  actor_id TEXT,
  kind TEXT NOT NULL,
  from_status TEXT,
  to_status TEXT,
  note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL,
  is_demo INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_upd_incident ON incident_updates(incident_id, created_at);

CREATE TABLE IF NOT EXISTS assignments (
  id TEXT PRIMARY KEY,
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  incident_id TEXT NOT NULL REFERENCES incidents(id),
  responder_id TEXT NOT NULL REFERENCES responders(id),
  status TEXT NOT NULL,
  assigned_by TEXT NOT NULL REFERENCES users(id),
  note TEXT NOT NULL DEFAULT '',
  assigned_at TEXT NOT NULL,
  acknowledged_at TEXT,
  en_route_at TEXT,
  on_scene_at TEXT,
  resolved_at TEXT,
  closed_reason TEXT,
  escalated_at TEXT,
  escalation_reason TEXT,
  route TEXT
);
CREATE INDEX IF NOT EXISTS idx_asg_incident ON assignments(incident_id);
CREATE INDEX IF NOT EXISTS idx_asg_responder ON assignments(responder_id, status);

CREATE TABLE IF NOT EXISTS advisories (
  id TEXT PRIMARY KEY,
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  issuer TEXT NOT NULL,
  source_url TEXT,
  coverage TEXT NOT NULL,
  body TEXT NOT NULL DEFAULT '',
  issued_at TEXT NOT NULL,
  expires_at TEXT,
  verification TEXT NOT NULL DEFAULT 'unverified',
  verified_by TEXT,
  verified_at TEXT,
  is_sample INTEGER NOT NULL DEFAULT 0,
  affected_zone_ids TEXT NOT NULL DEFAULT '[]',
  affected_segment_ids TEXT NOT NULL DEFAULT '[]',
  actions_note TEXT NOT NULL DEFAULT '',
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS checklist_items (
  id TEXT PRIMARY KEY,
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  key TEXT NOT NULL,
  label TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'not_assessed',
  note TEXT NOT NULL DEFAULT '',
  zone_id TEXT REFERENCES zones(id) ON DELETE SET NULL,
  updated_by TEXT,
  updated_at TEXT
);

CREATE TABLE IF NOT EXISTS playbooks (
  id TEXT PRIMARY KEY,
  key TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  categories TEXT NOT NULL,
  trigger_text TEXT NOT NULL,
  escalation TEXT NOT NULL,
  steps TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS incident_actions (
  id TEXT PRIMARY KEY,
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  incident_id TEXT NOT NULL REFERENCES incidents(id),
  playbook_id TEXT NOT NULL REFERENCES playbooks(id),
  step_index INTEGER NOT NULL,
  title TEXT NOT NULL,
  detail TEXT NOT NULL,
  approval TEXT NOT NULL,
  action TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  due_at TEXT,
  completed_by TEXT,
  completed_at TEXT,
  note TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_actions_incident ON incident_actions(incident_id);

CREATE TABLE IF NOT EXISTS stress_tests (
  id TEXT PRIMARY KEY,
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  scenario TEXT NOT NULL,
  summary TEXT NOT NULL,
  gaps TEXT NOT NULL,
  run_by TEXT REFERENCES users(id),
  run_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_stress_event ON stress_tests(event_id, run_at);

CREATE TABLE IF NOT EXISTS risk_history (
  id TEXT PRIMARY KEY,
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  zone_id TEXT NOT NULL,
  from_level TEXT,
  to_level TEXT NOT NULL,
  reasons TEXT NOT NULL,
  computed_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_risk_event ON risk_history(event_id, computed_at);

CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  at TEXT NOT NULL,
  actor_id TEXT,
  actor_name TEXT,
  actor_role TEXT,
  event_id TEXT,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT,
  details TEXT NOT NULL DEFAULT '{}',
  is_demo INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_audit_event ON audit_log(event_id, at);

-- Append-only protections. Updates are never allowed; deletes only for demo-scoped rows
-- while the demo reset holds the purge flag inside a transaction.
CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit_log
BEGIN SELECT RAISE(ABORT, 'audit_log is append-only'); END;
CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit_log
WHEN OLD.is_demo = 0 OR (SELECT value FROM sys_flags WHERE key = 'allow_demo_purge') = 0
BEGIN SELECT RAISE(ABORT, 'audit_log is append-only'); END;
CREATE TRIGGER IF NOT EXISTS updates_no_update BEFORE UPDATE ON incident_updates
BEGIN SELECT RAISE(ABORT, 'incident history is append-only'); END;
CREATE TRIGGER IF NOT EXISTS updates_no_delete BEFORE DELETE ON incident_updates
WHEN OLD.is_demo = 0 OR (SELECT value FROM sys_flags WHERE key = 'allow_demo_purge') = 0
BEGIN SELECT RAISE(ABORT, 'incident history is append-only'); END;
CREATE TRIGGER IF NOT EXISTS incidents_no_delete BEFORE DELETE ON incidents
WHEN OLD.is_demo = 0 OR (SELECT value FROM sys_flags WHERE key = 'allow_demo_purge') = 0
BEGIN SELECT RAISE(ABORT, 'incident records cannot be deleted'); END;
`;

/** Additive migrations for databases created by earlier versions. */
export const COLUMN_MIGRATIONS: [table: string, column: string, ddl: string][] = [
  ['zones', 'comms_fallback', "ALTER TABLE zones ADD COLUMN comms_fallback TEXT NOT NULL DEFAULT ''"],
  ['route_segments', 'weather_exposed', 'ALTER TABLE route_segments ADD COLUMN weather_exposed INTEGER NOT NULL DEFAULT 0'],
];
