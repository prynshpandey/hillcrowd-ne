import type { Store } from './db';
import type { User } from '../shared/types';

export class HttpError extends Error {
  constructor(public status: number, message: string, public details?: unknown) {
    super(message);
  }
}

type Listener = (eventId: string, kind: string) => void;

/** In-process change bus; SSE clients subscribe to refresh their snapshot. */
export class Bus {
  private listeners = new Set<Listener>();
  on(fn: Listener) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }
  emit(eventId: string, kind: string) {
    for (const fn of this.listeners) {
      try {
        fn(eventId, kind);
      } catch {
        /* a broken listener must not break a mutation */
      }
    }
  }
}

export interface Ctx {
  store: Store;
  now: () => Date;
  bus: Bus;
  demoMode: boolean;
}

export const iso = (ctx: Ctx) => ctx.now().toISOString();

export function audit(
  ctx: Ctx,
  actor: Pick<User, 'id' | 'displayName' | 'role'> | null,
  eventId: string | null,
  action: string,
  entityType: string,
  entityId: string | null,
  details: Record<string, unknown> = {},
) {
  const isDemo = eventId ? ctx.store.event(eventId)?.isDemo ?? false : false;
  ctx.store.insert('audit_log', {
    at: iso(ctx),
    actor_id: actor?.id ?? null,
    actor_name: actor?.displayName ?? 'System',
    actor_role: actor?.role ?? 'system',
    event_id: eventId,
    action,
    entity_type: entityType,
    entity_id: entityId,
    details,
    is_demo: isDemo,
  });
}
