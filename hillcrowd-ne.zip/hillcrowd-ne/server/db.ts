import type { DatabaseSync as DatabaseSyncT } from 'node:sqlite';
import { createRequire } from 'node:module';

// Loaded via require so test bundlers do not rewrite the `node:` built-in specifier.
const { DatabaseSync } = createRequire(import.meta.url)('node:sqlite') as typeof import('node:sqlite');

type SQLInputValue = null | number | bigint | string | Uint8Array;
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import { randomUUID } from 'node:crypto';
import { COLUMN_MIGRATIONS, SCHEMA_SQL, SCHEMA_VERSION } from './schema';
import { DEFAULT_SETTINGS } from '../shared/constants';
import type {
  Advisory,
  Assignment,
  AuditEntry,
  ChecklistItem,
  EventRecord,
  Facility,
  Incident,
  IncidentAction,
  IncidentUpdate,
  NamedRoute,
  OccupancyObservation,
  Playbook,
  Responder,
  RouteNode,
  RouteSegment,
  User,
  Zone,
} from '../shared/types';

type Row = Record<string, any>;
const j = <T>(v: unknown, fallback: T): T => {
  if (v == null || v === '') return fallback;
  try {
    return JSON.parse(String(v)) as T;
  } catch {
    return fallback;
  }
};
const b = (v: unknown) => Number(v) === 1;

export const newId = (prefix: string) => `${prefix}-${randomUUID().slice(0, 8)}`;

export class Store {
  readonly db: DatabaseSyncT;

  constructor(path = ':memory:') {
    if (path !== ':memory:') mkdirSync(dirname(path), { recursive: true });
    this.db = new DatabaseSync(path);
    this.db.exec('PRAGMA journal_mode = WAL;');
    // Older databases: add new columns before the schema script references them.
    for (const [table, column, ddl] of COLUMN_MIGRATIONS) {
      const exists = (this.db.prepare(`SELECT name FROM sqlite_master WHERE type='table' AND name=?`).get(table) as unknown) != null;
      if (!exists) continue;
      const cols = this.db.prepare(`PRAGMA table_info(${table})`).all() as { name: string }[];
      if (!cols.some((c) => c.name === column)) this.db.exec(ddl);
    }
    this.db.exec(SCHEMA_SQL);
    this.db.prepare('INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)').run('schema_version', String(SCHEMA_VERSION));
  }

  all<T = Row>(sql: string, ...params: SQLInputValue[]): T[] {
    return this.db.prepare(sql).all(...params) as T[];
  }
  get<T = Row>(sql: string, ...params: SQLInputValue[]): T | undefined {
    return this.db.prepare(sql).get(...params) as T | undefined;
  }
  run(sql: string, ...params: SQLInputValue[]) {
    return this.db.prepare(sql).run(...params);
  }

  private depth = 0;
  /** Run fn in a transaction (nested calls join the outer transaction). */
  tx<T>(fn: () => T): T {
    if (this.depth > 0) return fn();
    this.depth++;
    this.db.exec('BEGIN IMMEDIATE');
    try {
      const out = fn();
      this.db.exec('COMMIT');
      return out;
    } catch (e) {
      this.db.exec('ROLLBACK');
      throw e;
    } finally {
      this.depth--;
    }
  }

  /** Generic insert from a column→value object. */
  insert(table: string, row: Record<string, SQLInputValue | boolean | object | undefined>) {
    const cols = Object.keys(row).filter((k) => row[k] !== undefined);
    const vals = cols.map((k) => toSql(row[k]));
    this.run(`INSERT INTO ${table} (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`, ...vals);
  }

  update(table: string, id: string, patch: Record<string, SQLInputValue | boolean | object | undefined>, idCol = 'id') {
    const cols = Object.keys(patch).filter((k) => patch[k] !== undefined);
    if (!cols.length) return;
    this.run(`UPDATE ${table} SET ${cols.map((c) => `${c} = ?`).join(', ')} WHERE ${idCol} = ?`, ...cols.map((k) => toSql(patch[k])), id);
  }

  // ---------- mappers ----------
  static user(r: Row): User {
    return { id: r.id, username: r.username, displayName: r.display_name, role: r.role, responderId: r.responder_id ?? null, isDemo: b(r.is_demo) };
  }
  static event(r: Row): EventRecord {
    return {
      id: r.id,
      name: r.name,
      eventType: r.event_type,
      state: r.state,
      district: r.district,
      locationLabel: r.location_label,
      venueName: r.venue_name,
      venueIsFictional: b(r.venue_is_fictional),
      startsAt: r.starts_at,
      endsAt: r.ends_at,
      expectedAttendance: r.expected_attendance,
      venueCapacity: r.venue_capacity,
      controlContact: r.control_contact,
      centerLat: r.center_lat,
      centerLng: r.center_lng,
      zoom: r.zoom,
      boundary: j(r.boundary, []),
      isDemo: b(r.is_demo),
      settings: { ...DEFAULT_SETTINGS, ...j(r.settings, {}) },
    };
  }
  static zone(r: Row): Zone {
    return {
      id: r.id,
      eventId: r.event_id,
      name: r.name,
      polygon: j(r.polygon, []),
      capacity: r.capacity,
      watchPct: r.watch_pct,
      elevatedPct: r.elevated_pct,
      criticalPct: r.critical_pct,
      requiredExitIds: j(r.required_exit_ids, []),
      exitIds: j(r.exit_ids, []),
      notes: r.notes,
      commsFallback: r.comms_fallback ?? '',
    };
  }
  static obs(r: Row): OccupancyObservation {
    return { id: r.id, zoneId: r.zone_id, value: r.value, observedAt: r.observed_at, source: r.source, reportedBy: r.reported_by };
  }
  static facility(r: Row): Facility {
    return {
      id: r.id, eventId: r.event_id, kind: r.kind, name: r.name, lat: r.lat, lng: r.lng, zoneId: r.zone_id, nodeId: r.node_id,
      status: r.status, statusReason: r.status_reason, statusUpdatedAt: r.status_updated_at, capacityPerMin: r.capacity_per_min, notes: r.notes,
    };
  }
  static node(r: Row): RouteNode {
    return { id: r.id, eventId: r.event_id, name: r.name, lat: r.lat, lng: r.lng, facilityId: r.facility_id };
  }
  static segment(r: Row): RouteSegment {
    return {
      id: r.id, eventId: r.event_id, name: r.name, fromNode: r.from_node, toNode: r.to_node, distanceM: r.distance_m,
      modes: j(r.modes, []), access: r.access, status: r.status, statusReason: r.status_reason, statusSource: r.status_source,
      statusUpdatedAt: r.status_updated_at, approved: b(r.approved), constraintNote: r.constraint_note, terrainNote: r.terrain_note, weatherExposed: b(r.weather_exposed), path: j(r.path, []),
    };
  }
  static namedRoute(r: Row): NamedRoute {
    return {
      id: r.id, eventId: r.event_id, name: r.name, purpose: r.purpose, mode: r.mode, access: r.access, fromNode: r.from_node,
      toNode: r.to_node, segmentIds: j(r.segment_ids, []), approvedBy: r.approved_by, approvedAt: r.approved_at,
    };
  }
  static responder(r: Row): Responder {
    return {
      id: r.id, eventId: r.event_id, name: r.name, team: r.team, kind: r.kind, modes: j(r.modes, []), access: r.access, status: r.status,
      baseNodeId: r.base_node_id, lat: r.lat, lng: r.lng, locationSource: r.location_source, locationUpdatedAt: r.location_updated_at, userId: r.user_id,
    };
  }
  static incident(r: Row): Incident {
    return {
      id: r.id, ref: r.ref, eventId: r.event_id, clientId: r.client_id, category: r.category, zoneId: r.zone_id, lat: r.lat, lng: r.lng,
      description: r.description, severityEstimate: r.severity_estimate, confirmedSeverity: r.confirmed_severity, urgent: b(r.urgent),
      status: r.status, reporterId: r.reporter_id, reporterName: r.reporter_name ?? undefined, ownerId: r.owner_id,
      createdLocalAt: r.created_local_at, receivedAt: r.received_at, updatedAt: r.updated_at, verifiedAt: r.verified_at,
      assignedAt: r.assigned_at, acknowledgedAt: r.acknowledged_at, resolvedAt: r.resolved_at, closedAt: r.closed_at,
      mergedInto: r.merged_into, possibleDuplicateOf: j(r.possible_duplicate_of, []), reopenCount: r.reopen_count, isDemo: b(r.is_demo),
      attachmentNote: r.attachment_note,
    };
  }
  static update(r: Row): IncidentUpdate {
    return { id: r.id, incidentId: r.incident_id, actorId: r.actor_id, actorName: r.actor_name ?? undefined, kind: r.kind, fromStatus: r.from_status, toStatus: r.to_status, note: r.note, createdAt: r.created_at };
  }
  static assignment(r: Row): Assignment {
    return {
      id: r.id, incidentId: r.incident_id, responderId: r.responder_id, status: r.status, assignedBy: r.assigned_by, note: r.note,
      assignedAt: r.assigned_at, acknowledgedAt: r.acknowledged_at, enRouteAt: r.en_route_at, onSceneAt: r.on_scene_at,
      resolvedAt: r.resolved_at, closedReason: r.closed_reason, escalatedAt: r.escalated_at, escalationReason: r.escalation_reason, route: j(r.route, null),
    };
  }
  static advisory(r: Row): Advisory {
    return {
      id: r.id, eventId: r.event_id, title: r.title, issuer: r.issuer, sourceUrl: r.source_url, coverage: r.coverage, body: r.body,
      issuedAt: r.issued_at, expiresAt: r.expires_at, verification: r.verification, verifiedBy: r.verified_by, verifiedAt: r.verified_at,
      isSample: b(r.is_sample), affectedZoneIds: j(r.affected_zone_ids, []), affectedSegmentIds: j(r.affected_segment_ids, []),
      actionsNote: r.actions_note, createdBy: r.created_by, createdAt: r.created_at,
    };
  }
  static checklist(r: Row): ChecklistItem {
    return { id: r.id, eventId: r.event_id, key: r.key, label: r.label, status: r.status, note: r.note, zoneId: r.zone_id, updatedBy: r.updated_by, updatedAt: r.updated_at };
  }
  static playbook(r: Row): Playbook {
    return { id: r.id, key: r.key, title: r.title, categories: j(r.categories, []), trigger: r.trigger_text, escalation: r.escalation, steps: j(r.steps, []) };
  }
  static action(r: Row): IncidentAction {
    return {
      id: r.id, incidentId: r.incident_id, playbookId: r.playbook_id, stepIndex: r.step_index, title: r.title, detail: r.detail,
      approval: r.approval, action: r.action, status: r.status, dueAt: r.due_at, completedBy: r.completed_by, completedAt: r.completed_at, note: r.note,
    };
  }
  static audit(r: Row): AuditEntry {
    return {
      id: r.id, at: r.at, actorId: r.actor_id, actorName: r.actor_name, actorRole: r.actor_role, eventId: r.event_id,
      action: r.action, entityType: r.entity_type, entityId: r.entity_id, details: j(r.details, {}),
    };
  }

  // ---------- common reads ----------
  event(id: string) {
    const r = this.get('SELECT * FROM events WHERE id = ?', id);
    return r ? Store.event(r) : null;
  }
  zones(eventId: string) {
    return this.all('SELECT * FROM zones WHERE event_id = ? ORDER BY name', eventId).map(Store.zone);
  }
  facilities(eventId: string) {
    return this.all('SELECT * FROM facilities WHERE event_id = ? ORDER BY kind, name', eventId).map(Store.facility);
  }
  nodes(eventId: string) {
    return this.all('SELECT * FROM route_nodes WHERE event_id = ? ORDER BY name', eventId).map(Store.node);
  }
  segments(eventId: string) {
    return this.all('SELECT * FROM route_segments WHERE event_id = ? ORDER BY name', eventId).map(Store.segment);
  }
  namedRoutes(eventId: string) {
    return this.all('SELECT * FROM named_routes WHERE event_id = ? ORDER BY name', eventId).map(Store.namedRoute);
  }
  responders(eventId: string) {
    return this.all('SELECT * FROM responders WHERE event_id = ? ORDER BY name', eventId).map(Store.responder);
  }
  incidents(eventId: string) {
    return this.all(
      'SELECT i.*, u.display_name AS reporter_name FROM incidents i JOIN users u ON u.id = i.reporter_id WHERE i.event_id = ? ORDER BY i.received_at DESC',
      eventId,
    ).map(Store.incident);
  }
  incident(id: string) {
    const r = this.get('SELECT i.*, u.display_name AS reporter_name FROM incidents i JOIN users u ON u.id = i.reporter_id WHERE i.id = ?', id);
    return r ? Store.incident(r) : null;
  }
  incidentUpdates(incidentId: string) {
    return this.all(
      'SELECT h.*, u.display_name AS actor_name FROM incident_updates h LEFT JOIN users u ON u.id = h.actor_id WHERE h.incident_id = ? ORDER BY h.created_at, h.rowid',
      incidentId,
    ).map(Store.update);
  }
  assignments(eventId: string) {
    return this.all('SELECT * FROM assignments WHERE event_id = ? ORDER BY assigned_at DESC', eventId).map(Store.assignment);
  }
  assignment(id: string) {
    const r = this.get('SELECT * FROM assignments WHERE id = ?', id);
    return r ? Store.assignment(r) : null;
  }
  advisories(eventId: string) {
    return this.all('SELECT * FROM advisories WHERE event_id = ? ORDER BY issued_at DESC', eventId).map(Store.advisory);
  }
  observations(eventId: string) {
    return this.all('SELECT * FROM occupancy_observations WHERE event_id = ? ORDER BY observed_at', eventId).map(Store.obs);
  }
  checklist(eventId: string) {
    return this.all('SELECT * FROM checklist_items WHERE event_id = ? ORDER BY rowid', eventId).map(Store.checklist);
  }
  playbooks() {
    return this.all('SELECT * FROM playbooks ORDER BY title').map(Store.playbook);
  }
  actions(incidentId: string) {
    return this.all('SELECT * FROM incident_actions WHERE incident_id = ? ORDER BY step_index', incidentId).map(Store.action);
  }
  actionsForEvent(eventId: string) {
    return this.all('SELECT * FROM incident_actions WHERE event_id = ? ORDER BY incident_id, step_index', eventId).map(Store.action);
  }
  userById(id: string) {
    const r = this.get('SELECT u.*, r.id AS responder_id FROM users u LEFT JOIN responders r ON r.user_id = u.id WHERE u.id = ? AND u.active = 1', id);
    return r ? Store.user(r) : null;
  }
}

function toSql(v: unknown): SQLInputValue {
  if (v === null || v === undefined) return null;
  if (typeof v === 'boolean') return v ? 1 : 0;
  if (typeof v === 'object') return JSON.stringify(v);
  return v as SQLInputValue;
}
