import type { Ctx } from '../context';
import { computeEventRisk } from './risk';
import { namedRouteValidity } from './network';
import { can } from '../../shared/permissions';
import { CATEGORY_LABEL, RISK_ORDER } from '../../shared/constants';
import type { ChecklistItem, Notification, User, ZoneRisk } from '../../shared/types';
import { liveResilience, stressTests } from './resilience';
import { incidentStages, type StageStatus } from '../../shared/accountability';
import { STAGE_LABEL } from '../../shared/constants';
import type { ResilienceReport } from '../../shared/resilience';

export function readinessSummary(items: ChecklistItem[]) {
  const by = (st: ChecklistItem['status']) => items.filter((i) => i.status === st);
  const outstanding = items.filter((i) => ['not_assessed', 'issue_identified', 'mitigation_planned'].includes(i.status));
  return {
    total: items.length,
    notAssessed: by('not_assessed').length,
    noIssue: by('no_issue').length,
    issuesIdentified: by('issue_identified').length,
    mitigationPlanned: by('mitigation_planned').length,
    mitigationVerified: by('mitigation_verified').length,
    outstanding: outstanding.map((i) => ({ id: i.id, label: i.label, status: i.status, note: i.note })),
    statement:
      outstanding.length === 0
        ? 'All checklist items are assessed with no open findings. This records the assessment only; it does not certify that the venue is safe.'
        : `${outstanding.length} checklist item(s) are not assessed or have findings without a verified mitigation. A completed checklist does not by itself make a venue safe.`,
  };
}

export function buildNotifications(ctx: Ctx, eventId: string, risks: ZoneRisk[], access?: ResilienceReport, stages?: Record<string, StageStatus>): Notification[] {
  const s = ctx.store;
  const out: Notification[] = [];
  const zones = new Map(s.zones(eventId).map((z) => [z.id, z.name]));
  const now = ctx.now().toISOString();
  for (const r of risks.filter((x) => x.level === 'critical' || x.level === 'elevated')) {
    out.push({ id: `risk-${r.zoneId}`, level: r.level, title: `${zones.get(r.zoneId)}: ${r.level.toUpperCase()}`, detail: r.conditions[0]?.message ?? '', link: `/map?zone=${r.zoneId}`, at: r.computedAt });
  }
  const incidents = s.incidents(eventId);
  for (const i of incidents.filter((x) => !x.mergedInto && ['submitted', 'under_review'].includes(x.status))) {
    out.push({ id: `rev-${i.id}`, level: i.urgent ? 'elevated' : 'watch', title: `${i.urgent ? 'URGENT ' : ''}report awaiting review: ${i.ref}`, detail: `${CATEGORY_LABEL[i.category]} — ${zones.get(i.zoneId ?? '') ?? 'location on map'}`, link: `/incidents/${i.id}`, at: i.receivedAt });
  }
  for (const i of incidents.filter((x) => !x.mergedInto && x.status === 'verified')) {
    out.push({ id: `una-${i.id}`, level: 'elevated', title: `Verified, not yet assigned: ${i.ref}`, detail: CATEGORY_LABEL[i.category], link: `/incidents/${i.id}`, at: i.verifiedAt ?? i.updatedAt });
  }
  for (const i of incidents.filter((x) => !x.mergedInto && x.status === 'resolved')) {
    out.push({ id: `res-${i.id}`, level: 'watch', title: `Resolution awaiting confirmation: ${i.ref}`, detail: CATEGORY_LABEL[i.category], link: `/incidents/${i.id}`, at: i.resolvedAt ?? i.updatedAt });
  }
  const responders = new Map(s.responders(eventId).map((r) => [r.id, r.name]));
  for (const a of s.assignments(eventId).filter((x) => x.status === 'assigned')) {
    const inc = incidents.find((i) => i.id === a.incidentId);
    out.push({ id: `ack-${a.id}`, level: a.escalatedAt ? 'elevated' : 'watch', title: `${a.escalatedAt ? 'ESCALATED: ' : ''}Awaiting acknowledgement — ${responders.get(a.responderId)}`, detail: a.escalationReason ?? `Assignment for ${inc?.ref ?? 'incident'}`, link: `/incidents/${a.incidentId}`, at: a.escalatedAt ?? a.assignedAt });
  }
  for (const v of namedRouteValidity(ctx, eventId).filter((x) => !x.valid)) {
    const r = s.namedRoutes(eventId).find((x) => x.id === v.routeId)!;
    out.push({ id: `route-${v.routeId}`, level: v.alternative?.found ? 'watch' : 'critical', title: `Approved route unavailable: ${r.name}`, detail: v.alternative?.found ? `Alternative found (${v.alternative.distanceM} m). Coordinator review required.` : 'NO valid alternative in the approved network. Escalate.', link: '/routes', at: now });
  }
  for (const l of (access?.links ?? []).filter((x) => x.status === 'lost' && x.link.kind !== 'approved_route')) {
    out.push({ id: `access-${l.link.id}`, level: l.link.kind === 'medical_access' ? 'elevated' : 'critical', title: `ACCESS GAP: ${l.link.label}`, detail: 'No approved route available with current closures. Review the venue plan.', link: '/resilience', at: now });
  }
  for (const [incId, st] of Object.entries(stages ?? {})) {
    if (!st.overdue || !st.current || st.current === 'accept' || st.current === 'verify') continue;
    const inc = incidents.find((i) => i.id === incId);
    out.push({ id: `stage-${incId}`, level: 'watch', title: `${STAGE_LABEL[st.current]} overdue: ${inc?.ref}`, detail: `Next: ${st.nextActor} — ${st.nextAction}`, link: `/incidents/${incId}`, at: now });
  }
  for (const a of s.advisories(eventId).filter((x) => x.verification === 'unverified')) {
    out.push({ id: `adv-${a.id}`, level: 'watch', title: `Advisory awaiting verification${a.isSample ? ' [SAMPLE]' : ''}`, detail: a.title, link: '/advisories', at: a.createdAt });
  }
  return out.sort((a, b) => RISK_ORDER[b.level] - RISK_ORDER[a.level] || b.at.localeCompare(a.at));
}

export function buildSnapshot(ctx: Ctx, eventId: string, user: User) {
  const s = ctx.store;
  const event = s.event(eventId)!;
  const base = {
    serverTime: ctx.now().toISOString(),
    demoMode: ctx.demoMode,
    event,
    zones: s.zones(eventId),
    facilities: s.facilities(eventId),
    nodes: s.nodes(eventId),
    segments: s.segments(eventId),
    advisories: s.advisories(eventId).filter((a) => a.verification === 'verified' || can(user.role, 'advisory.verify')),
  };
  if (can(user.role, 'event.viewOps')) {
    const risks = computeEventRisk(ctx, eventId);
    const checklist = s.checklist(eventId);
    const access = liveResilience(ctx, eventId);
    const incidents = s.incidents(eventId);
    const assignments = s.assignments(eventId);
    const names = new Map(s.responders(eventId).map((r) => [r.id, r.name]));
    const stages: Record<string, StageStatus> = {};
    for (const i of incidents) if (!i.mergedInto) stages[i.id] = incidentStages(i, assignments, event.settings, (id) => names.get(id) ?? id, ctx.now());
    return {
      ...base,
      view: 'ops' as const,
      risks,
      incidents,
      assignments,
      stages,
      access,
      stressTests: stressTests(ctx, eventId),
      responders: s.responders(eventId),
      namedRoutes: s.namedRoutes(eventId),
      routeValidity: namedRouteValidity(ctx, eventId),
      actions: s.actionsForEvent(eventId),
      playbooks: s.playbooks(),
      checklist,
      readiness: readinessSummary(checklist),
      notifications: buildNotifications(ctx, eventId, risks, access, stages),
      closures: s.all('SELECT c.*, s.name AS segment_name FROM route_closures c JOIN route_segments s ON s.id = c.segment_id WHERE c.event_id = ? ORDER BY c.created_at DESC', eventId),
    };
  }
  // Responders, and stewards linked to a steward-team responder record, see their own assignments.
  const myResponders = s.responders(eventId).filter((r) => r.userId === user.id);
  const ids = new Set(myResponders.map((r) => r.id));
  const assignments = s.assignments(eventId).filter((a) => ids.has(a.responderId));
  const incIds = new Set(assignments.map((a) => a.incidentId));
  if (user.role === 'responder') {
    return {
      ...base,
      view: 'responder' as const,
      responders: myResponders,
      assignments,
      // Responders see only incidents assigned to them.
      incidents: s.incidents(eventId).filter((i) => incIds.has(i.id)),
    };
  }
  // Steward: own reports, plus tasks assigned to a linked steward team.
  return {
    ...base,
    view: 'steward' as const,
    responders: myResponders,
    assignments,
    incidents: s.incidents(eventId).filter((i) => i.reporterId === user.id || incIds.has(i.id)),
  };
}
