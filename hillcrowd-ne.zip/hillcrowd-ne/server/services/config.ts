import { audit, HttpError, iso, type Ctx } from '../context';
import { newId, Store } from '../db';
import { hashPassword } from '../auth';
import { buildLayoutEvent } from './demo';
import { CHECKLIST_TEMPLATE } from '../seed/demoData';
import { DEFAULT_SETTINGS } from '../../shared/constants';
import { findRoute } from '../../shared/routing';
import { pathLengthM } from '../../shared/geo';
import type { AccessLevel, EventSettings, FacilityKind, PlaybookStep, Role, TravelMode, User } from '../../shared/types';

export interface EventInput {
  name: string;
  eventType: string;
  state: string;
  district: string;
  locationLabel: string;
  venueName: string;
  venueIsFictional: boolean;
  startsAt: string;
  endsAt: string;
  expectedAttendance: number | null;
  venueCapacity: number | null;
  controlContact: string;
  centerLat: number;
  centerLng: number;
  zoom: number;
}

export function createEvent(ctx: Ctx, actor: User, input: EventInput & { template: 'blank' | 'demo_layout' }) {
  if (input.endsAt <= input.startsAt) throw new HttpError(400, 'Event end must be after the start.');
  const s = ctx.store;
  const id = newId('evt');
  const meta = {
    name: input.name,
    event_type: input.eventType,
    state: input.state,
    district: input.district,
    location_label: input.locationLabel,
    venue_name: input.venueName,
    venue_is_fictional: input.venueIsFictional,
    starts_at: input.startsAt,
    ends_at: input.endsAt,
    expected_attendance: input.expectedAttendance,
    venue_capacity: input.venueCapacity,
    control_contact: input.controlContact,
    zoom: input.zoom,
  };
  s.tx(() => {
    if (input.template === 'demo_layout') {
      buildLayoutEvent(ctx, { id, isDemo: false, origin: [input.centerLat, input.centerLng], meta, actor });
    } else {
      s.insert('events', { id, ...meta, center_lat: input.centerLat, center_lng: input.centerLng, boundary: [], is_demo: false, settings: DEFAULT_SETTINGS, created_at: iso(ctx) });
      for (const c of CHECKLIST_TEMPLATE) {
        s.insert('checklist_items', { id: `${id.slice(-6)}-chk-${c.key}`, event_id: id, key: c.key, label: c.label, status: 'not_assessed', note: '' });
      }
    }
    s.run('INSERT OR IGNORE INTO event_access (user_id, event_id) VALUES (?, ?)', actor.id, id);
    audit(ctx, actor, id, 'event.created', 'event', id, { name: input.name, template: input.template, state: input.state, district: input.district });
  });
  return s.event(id)!;
}

export function updateEvent(ctx: Ctx, actor: User, eventId: string, patch: Partial<EventInput> & { settings?: Partial<EventSettings>; boundary?: [number, number][] }) {
  const s = ctx.store;
  const ev = s.event(eventId);
  if (!ev) throw new HttpError(404, 'Event not found.');
  const settings = patch.settings ? { ...ev.settings, ...patch.settings } : undefined;
  const startsAt = patch.startsAt ?? ev.startsAt;
  const endsAt = patch.endsAt ?? ev.endsAt;
  if (endsAt <= startsAt) throw new HttpError(400, 'Event end must be after the start.');
  s.tx(() => {
    s.update('events', eventId, {
      name: patch.name,
      event_type: patch.eventType,
      state: patch.state,
      district: patch.district,
      location_label: patch.locationLabel,
      venue_name: patch.venueName,
      venue_is_fictional: patch.venueIsFictional,
      starts_at: patch.startsAt,
      ends_at: patch.endsAt,
      expected_attendance: patch.expectedAttendance,
      venue_capacity: patch.venueCapacity,
      control_contact: patch.controlContact,
      center_lat: patch.centerLat,
      center_lng: patch.centerLng,
      zoom: patch.zoom,
      boundary: patch.boundary,
      settings,
    });
    audit(ctx, actor, eventId, 'event.updated', 'event', eventId, { changed: Object.keys(patch), settingsBefore: patch.settings ? ev.settings : undefined, settingsAfter: settings });
  });
  ctx.bus.emit(eventId, 'config');
  return s.event(eventId)!;
}

function checkThresholds(w: number, e: number, c: number | null) {
  if (!(w > 0 && w < e && (c == null || e < c))) throw new HttpError(400, 'Thresholds must increase: watch < elevated < critical (percent of capacity).');
}

export interface ZoneInput {
  name: string;
  polygon: [number, number][];
  capacity: number | null;
  watchPct: number;
  elevatedPct: number;
  criticalPct: number | null;
  requiredExitIds: string[];
  exitIds: string[];
  notes: string;
  commsFallback: string;
}

function checkExits(ctx: Ctx, eventId: string, exitIds: string[], required: string[]) {
  const facs = new Map(ctx.store.facilities(eventId).map((f) => [f.id, f]));
  for (const id of exitIds) {
    const f = facs.get(id);
    if (!f || !['gate', 'exit'].includes(f.kind)) throw new HttpError(400, `Exit ${id} is not a gate or exit of this event.`);
  }
  for (const id of required) if (!exitIds.includes(id)) throw new HttpError(400, 'Required exits must also be listed as zone exits.');
}

export function createZone(ctx: Ctx, actor: User, eventId: string, z: ZoneInput) {
  checkThresholds(z.watchPct, z.elevatedPct, z.criticalPct);
  checkExits(ctx, eventId, z.exitIds, z.requiredExitIds);
  if (z.polygon.length < 3) throw new HttpError(400, 'A zone needs at least three boundary points.');
  const id = newId('zone');
  ctx.store.tx(() => {
    ctx.store.insert('zones', {
      id, event_id: eventId, name: z.name, polygon: z.polygon, capacity: z.capacity, watch_pct: z.watchPct, elevated_pct: z.elevatedPct,
      critical_pct: z.criticalPct, required_exit_ids: z.requiredExitIds, exit_ids: z.exitIds, notes: z.notes, comms_fallback: z.commsFallback ?? '',
    });
    audit(ctx, actor, eventId, 'zone.created', 'zone', id, { ...z, polygon: undefined });
  });
  ctx.bus.emit(eventId, 'config');
  return id;
}

export function updateZone(ctx: Ctx, actor: User, zoneId: string, patch: Partial<ZoneInput>) {
  const row = ctx.store.get('SELECT * FROM zones WHERE id = ?', zoneId);
  if (!row) throw new HttpError(404, 'Zone not found.');
  const before = Store.zone(row);
  const after = { ...before, ...patch };
  checkThresholds(after.watchPct, after.elevatedPct, after.criticalPct);
  checkExits(ctx, before.eventId, after.exitIds, after.requiredExitIds);
  ctx.store.tx(() => {
    ctx.store.update('zones', zoneId, {
      name: patch.name, polygon: patch.polygon, capacity: patch.capacity, watch_pct: patch.watchPct, elevated_pct: patch.elevatedPct,
      critical_pct: patch.criticalPct, required_exit_ids: patch.requiredExitIds, exit_ids: patch.exitIds, notes: patch.notes, comms_fallback: patch.commsFallback,
    });
    const diff: Record<string, unknown> = {};
    for (const k of Object.keys(patch) as (keyof ZoneInput)[]) if (k !== 'polygon') diff[k] = { from: before[k], to: after[k] };
    audit(ctx, actor, before.eventId, 'zone.updated', 'zone', zoneId, diff);
  });
  ctx.bus.emit(before.eventId, 'config');
}

export function createFacility(ctx: Ctx, actor: User, eventId: string, f: { kind: FacilityKind; name: string; lat: number; lng: number; zoneId: string | null; capacityPerMin: number | null; notes: string }) {
  const id = newId('fac');
  const nodeId = newId('node');
  ctx.store.tx(() => {
    ctx.store.insert('route_nodes', { id: nodeId, event_id: eventId, name: f.name, lat: f.lat, lng: f.lng, facility_id: null });
    ctx.store.insert('facilities', {
      id, event_id: eventId, kind: f.kind, name: f.name, lat: f.lat, lng: f.lng, zone_id: f.zoneId, node_id: nodeId, status: 'open',
      status_updated_at: iso(ctx), capacity_per_min: f.capacityPerMin, notes: f.notes,
    });
    ctx.store.update('route_nodes', nodeId, { facility_id: id });
    audit(ctx, actor, eventId, 'facility.created', 'facility', id, f);
  });
  ctx.bus.emit(eventId, 'config');
  return id;
}

export function updateFacility(ctx: Ctx, actor: User, facilityId: string, patch: { name?: string; zoneId?: string | null; capacityPerMin?: number | null; notes?: string }) {
  const row = ctx.store.get('SELECT * FROM facilities WHERE id = ?', facilityId);
  if (!row) throw new HttpError(404, 'Facility not found.');
  ctx.store.tx(() => {
    ctx.store.update('facilities', facilityId, { name: patch.name, zone_id: patch.zoneId, capacity_per_min: patch.capacityPerMin, notes: patch.notes });
    audit(ctx, actor, row.event_id, 'facility.updated', 'facility', facilityId, { before: { name: row.name, zoneId: row.zone_id, capacityPerMin: row.capacity_per_min, notes: row.notes }, after: patch });
  });
  ctx.bus.emit(row.event_id, 'config');
}

export function createNode(ctx: Ctx, actor: User, eventId: string, n: { name: string; lat: number; lng: number }) {
  const id = newId('node');
  ctx.store.tx(() => {
    ctx.store.insert('route_nodes', { id, event_id: eventId, name: n.name, lat: n.lat, lng: n.lng, facility_id: null });
    audit(ctx, actor, eventId, 'node.created', 'route_node', id, n);
  });
  ctx.bus.emit(eventId, 'config');
  return id;
}

export interface SegmentInput {
  name: string;
  fromNode: string;
  toNode: string;
  modes: TravelMode[];
  access: AccessLevel;
  approved: boolean;
  constraintNote: string;
  terrainNote: string;
  weatherExposed?: boolean;
  distanceM?: number | null;
}

export function createSegment(ctx: Ctx, actor: User, eventId: string, seg: SegmentInput) {
  const nodes = new Map(ctx.store.nodes(eventId).map((n) => [n.id, n]));
  const a = nodes.get(seg.fromNode);
  const b = nodes.get(seg.toNode);
  if (!a || !b) throw new HttpError(400, 'Both segment ends must be nodes of this event.');
  if (a.id === b.id) throw new HttpError(400, 'A segment must connect two different nodes.');
  const path: [number, number][] = [[a.lat, a.lng], [b.lat, b.lng]];
  const distance = seg.distanceM ?? Math.round(pathLengthM(path));
  const id = newId('seg');
  ctx.store.tx(() => {
    ctx.store.insert('route_segments', {
      id, event_id: eventId, name: seg.name, from_node: a.id, to_node: b.id, distance_m: distance, modes: seg.modes, access: seg.access,
      status: 'open', status_source: 'Configured by administrator', status_updated_at: iso(ctx), approved: seg.approved,
      constraint_note: seg.constraintNote, terrain_note: seg.terrainNote, weather_exposed: !!seg.weatherExposed, path,
    });
    audit(ctx, actor, eventId, 'segment.created', 'route_segment', id, { ...seg, distanceM: distance });
  });
  ctx.bus.emit(eventId, 'network');
  return id;
}

export function updateSegment(ctx: Ctx, actor: User, segmentId: string, patch: Partial<Omit<SegmentInput, 'fromNode' | 'toNode'>>) {
  const row = ctx.store.get('SELECT * FROM route_segments WHERE id = ?', segmentId);
  if (!row) throw new HttpError(404, 'Segment not found.');
  const before = Store.segment(row);
  ctx.store.tx(() => {
    ctx.store.update('route_segments', segmentId, {
      name: patch.name, modes: patch.modes, access: patch.access, approved: patch.approved, constraint_note: patch.constraintNote,
      terrain_note: patch.terrainNote, weather_exposed: patch.weatherExposed, distance_m: patch.distanceM ?? undefined,
    });
    const diff: Record<string, unknown> = {};
    for (const k of Object.keys(patch)) diff[k] = { from: (before as any)[k], to: (patch as any)[k] };
    audit(ctx, actor, before.eventId, 'segment.configured', 'route_segment', segmentId, diff);
  });
  ctx.bus.emit(before.eventId, 'network');
}

export function createNamedRoute(ctx: Ctx, actor: User, eventId: string, r: { name: string; purpose: string; mode: TravelMode; access: AccessLevel; fromNode: string; toNode: string }) {
  const result = findRoute(ctx.store.nodes(eventId), ctx.store.segments(eventId), { from: r.fromNode, to: r.toNode, mode: r.mode, access: r.access, avoidUnderReview: true }, ctx.now());
  if (!result.found) throw new HttpError(409, `Cannot approve: ${result.reason}`);
  const id = newId('nr');
  ctx.store.tx(() => {
    ctx.store.insert('named_routes', {
      id, event_id: eventId, name: r.name, purpose: r.purpose, mode: r.mode, access: r.access, from_node: r.fromNode, to_node: r.toNode,
      segment_ids: result.segmentIds, approved_by: actor.displayName, approved_at: iso(ctx),
    });
    audit(ctx, actor, eventId, 'named_route.approved', 'named_route', id, { ...r, segments: result.segmentIds, distanceM: result.distanceM });
  });
  ctx.bus.emit(eventId, 'network');
  return id;
}

export function setResponderLocation(ctx: Ctx, actor: User, responderId: string, lat: number, lng: number) {
  const row = ctx.store.get('SELECT * FROM responders WHERE id = ?', responderId);
  if (!row) throw new HttpError(404, 'Responder not found.');
  ctx.store.tx(() => {
    ctx.store.update('responders', responderId, { lat, lng, location_source: `Manually entered by ${actor.displayName} (not live GPS)`, location_updated_at: iso(ctx), base_node_id: null });
    audit(ctx, actor, row.event_id, 'responder.location', 'responder', responderId, { lat, lng });
  });
  ctx.bus.emit(row.event_id, 'responder');
}

// ---------------- Users ----------------

export function listUsers(ctx: Ctx) {
  return ctx.store
    .all('SELECT u.id, u.username, u.display_name, u.role, u.is_demo, u.active, u.created_at FROM users u ORDER BY u.role, u.username')
    .map((u) => ({
      id: u.id, username: u.username, displayName: u.display_name, role: u.role, isDemo: u.is_demo === 1, active: u.active === 1, createdAt: u.created_at,
      events: ctx.store.all<{ event_id: string }>('SELECT event_id FROM event_access WHERE user_id = ?', u.id).map((r) => r.event_id),
    }));
}

export function createUser(ctx: Ctx, actor: User, u: { username: string; displayName: string; role: Role; password: string; eventIds: string[] }) {
  const username = u.username.trim().toLowerCase();
  if (ctx.store.get('SELECT 1 FROM users WHERE username = ?', username)) throw new HttpError(409, 'Username already exists.');
  const id = newId('usr');
  ctx.store.tx(() => {
    ctx.store.insert('users', { id, username, display_name: u.displayName, role: u.role, password_hash: hashPassword(u.password), is_demo: false, created_at: iso(ctx) });
    for (const e of u.eventIds) {
      if (!ctx.store.event(e)) throw new HttpError(400, `Unknown event ${e}.`);
      ctx.store.run('INSERT OR IGNORE INTO event_access (user_id, event_id) VALUES (?, ?)', id, e);
    }
    audit(ctx, actor, null, 'user.created', 'user', id, { username, role: u.role, events: u.eventIds });
  });
  return id;
}

export function updateUser(ctx: Ctx, actor: User, userId: string, patch: { role?: Role; active?: boolean; displayName?: string; eventIds?: string[] }) {
  const row = ctx.store.get('SELECT * FROM users WHERE id = ?', userId);
  if (!row) throw new HttpError(404, 'User not found.');
  if (userId === actor.id && (patch.role !== undefined || patch.active === false)) throw new HttpError(403, 'You cannot change your own role or deactivate your own account.');
  ctx.store.tx(() => {
    ctx.store.update('users', userId, { role: patch.role, active: patch.active, display_name: patch.displayName });
    if (patch.eventIds) {
      ctx.store.run('DELETE FROM event_access WHERE user_id = ?', userId);
      for (const e of patch.eventIds) ctx.store.run('INSERT OR IGNORE INTO event_access (user_id, event_id) VALUES (?, ?)', userId, e);
    }
    if (patch.role !== undefined || patch.active === false) ctx.store.run('DELETE FROM sessions WHERE user_id = ?', userId);
    audit(ctx, actor, null, 'user.updated', 'user', userId, { username: row.username, before: { role: row.role, active: row.active === 1 }, after: patch });
  });
}

export function updatePlaybook(ctx: Ctx, actor: User, playbookId: string, patch: { title?: string; trigger?: string; escalation?: string; steps?: PlaybookStep[] }) {
  const row = ctx.store.get('SELECT * FROM playbooks WHERE id = ?', playbookId);
  if (!row) throw new HttpError(404, 'Playbook not found.');
  ctx.store.tx(() => {
    ctx.store.update('playbooks', playbookId, { title: patch.title, trigger_text: patch.trigger, escalation: patch.escalation, steps: patch.steps });
    audit(ctx, actor, null, 'playbook.updated', 'playbook', playbookId, { before: Store.playbook(row), after: patch });
  });
}
