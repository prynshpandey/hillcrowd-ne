import { audit, HttpError, iso, type Ctx } from '../context';
import { newId } from '../db';
import { analyseNetwork, type ResilienceReport, type Scenario } from '../../shared/resilience';
import type { User } from '../../shared/types';

function networkInput(ctx: Ctx, eventId: string) {
  const s = ctx.store;
  return { zones: s.zones(eventId), facilities: s.facilities(eventId), nodes: s.nodes(eventId), segments: s.segments(eventId), namedRoutes: s.namedRoutes(eventId), responders: s.responders(eventId) };
}

/** Current network (live closures) compared with the approved plan. */
export function liveResilience(ctx: Ctx, eventId: string): ResilienceReport {
  return analyseNetwork(networkInput(ctx, eventId));
}

/** What-if analysis. Never changes live data. */
export function simulate(ctx: Ctx, eventId: string, sc: Scenario): ResilienceReport {
  const inp = networkInput(ctx, eventId);
  const segIds = new Set(inp.segments.map((x) => x.id));
  const facIds = new Set(inp.facilities.map((x) => x.id));
  const zoneIds = new Set(inp.zones.map((x) => x.id));
  const respIds = new Set(inp.responders.map((x) => x.id));
  for (const id of sc.closedSegments) if (!segIds.has(id)) throw new HttpError(400, `Unknown route segment ${id}.`);
  for (const id of sc.closedFacilities) if (!facIds.has(id)) throw new HttpError(400, `Unknown facility ${id}.`);
  for (const id of sc.commsLostZones ?? []) if (!zoneIds.has(id)) throw new HttpError(400, `Unknown zone ${id}.`);
  for (const id of sc.unavailableResponders ?? []) if (!respIds.has(id)) throw new HttpError(400, `Unknown responder ${id}.`);
  return analyseNetwork(inp, sc);
}

/** Run and record a pre-event stress test so readiness reviews can see what was tested and found. */
export function recordStressTest(ctx: Ctx, actor: User, eventId: string, name: string, sc: Scenario) {
  const report = simulate(ctx, eventId, sc);
  const id = newId('st');
  ctx.store.tx(() => {
    ctx.store.insert('stress_tests', { id, event_id: eventId, name, scenario: sc, summary: report.summary, gaps: report.gaps, run_by: actor.id, run_at: iso(ctx) });
    audit(ctx, actor, eventId, 'stress_test.run', 'stress_test', id, { name, summary: report.summary, gaps: report.gaps.length });
  });
  ctx.bus.emit(eventId, 'config');
  return { id, report };
}

export function stressTests(ctx: Ctx, eventId: string) {
  return ctx.store
    .all('SELECT t.*, u.display_name AS run_by_name FROM stress_tests t LEFT JOIN users u ON u.id = t.run_by WHERE t.event_id = ? ORDER BY t.run_at DESC LIMIT 20', eventId)
    .map((r) => ({ id: r.id, name: r.name, scenario: JSON.parse(r.scenario), summary: JSON.parse(r.summary), gaps: JSON.parse(r.gaps), runBy: r.run_by_name, runAt: r.run_at }));
}
