import type { Ctx } from '../context';
import { CATEGORY_LABEL, STATUS_LABEL, ACTIVE_INCIDENT_STATUSES } from '../../shared/constants';
import type { Incident, IncidentCategory, IncidentStatus } from '../../shared/types';
import { incidentStages } from '../../shared/accountability';

export interface AnalyticsFilter {
  from?: string;
  to?: string;
  category?: IncidentCategory;
  status?: IncidentStatus;
}

const secs = (a: string | null, b: string | null) => (a && b ? Math.max(0, (new Date(b).getTime() - new Date(a).getTime()) / 1000) : null);

export function median(values: (number | null)[]): number | null {
  const v = values.filter((x): x is number => x != null).sort((a, b) => a - b);
  if (!v.length) return null;
  const m = Math.floor(v.length / 2);
  return v.length % 2 ? v[m] : (v[m - 1] + v[m]) / 2;
}

function filterIncidents(list: Incident[], f: AnalyticsFilter) {
  return list.filter(
    (i) =>
      !i.mergedInto &&
      (!f.from || i.receivedAt >= f.from) &&
      (!f.to || i.receivedAt <= f.to) &&
      (!f.category || i.category === f.category) &&
      (!f.status || i.status === f.status),
  );
}

export function computeAnalytics(ctx: Ctx, eventId: string, f: AnalyticsFilter = {}) {
  const s = ctx.store;
  const ev = s.event(eventId)!;
  const all = s.incidents(eventId);
  const incidents = filterIncidents(all, f);
  const zones = new Map(s.zones(eventId).map((z) => [z.id, z.name]));
  const count = <K extends string>(keyFn: (i: Incident) => K) => {
    const m: Record<string, number> = {};
    for (const i of incidents) m[keyFn(i)] = (m[keyFn(i)] ?? 0) + 1;
    return Object.entries(m).map(([key, n]) => ({ key, n })).sort((a, b) => b.n - a.n);
  };
  const assignments = s.assignments(eventId).filter((a) => incidents.some((i) => i.id === a.incidentId));
  const responders = s.responders(eventId);
  const nowMs = ctx.now().getTime();

  const names = new Map(responders.map((r) => [r.id, r.name]));
  const allAsg = s.assignments(eventId);
  const perIncident = incidents.map((i) => ({
    stages: incidentStages(i, allAsg, ev.settings, (id) => names.get(id) ?? id, ctx.now()).stages.map((st) => ({ key: st.key, label: st.label, durationSec: st.durationSec, targetSec: st.targetSec, overdue: st.overdue, state: st.state })),
    routeM: allAsg.filter((a) => a.incidentId === i.id).at(-1)?.route?.distanceM ?? null,
    routeFound: allAsg.filter((a) => a.incidentId === i.id).at(-1)?.route?.found ?? null,
    id: i.id,
    ref: i.ref,
    category: i.category,
    zone: zones.get(i.zoneId ?? '') ?? '—',
    status: i.status,
    severity: i.confirmedSeverity ?? i.severityEstimate,
    severityConfirmed: !!i.confirmedSeverity,
    urgent: i.urgent,
    createdLocalAt: i.createdLocalAt,
    receivedAt: i.receivedAt,
    syncDelaySec: secs(i.createdLocalAt, i.receivedAt),
    toVerifySec: secs(i.receivedAt, i.verifiedAt),
    toAssignSec: secs(i.receivedAt, i.assignedAt),
    toAckSec: secs(i.receivedAt, i.acknowledgedAt),
    toResolveSec: secs(i.receivedAt, i.resolvedAt),
    reopenCount: i.reopenCount,
    isDemo: i.isDemo,
  }));

  const closures = s.all<{ segment_id: string; segment_name: string; status: string; reason: string; source: string; created_at: string; lifted_at: string | null }>(
    'SELECT c.*, s.name AS segment_name FROM route_closures c JOIN route_segments s ON s.id = c.segment_id WHERE c.event_id = ? ORDER BY c.created_at',
    eventId,
  );
  const closureFreq: Record<string, { name: string; closed: number; review: number }> = {};
  for (const c of closures) {
    const e = (closureFreq[c.segment_id] ??= { name: c.segment_name, closed: 0, review: 0 });
    if (c.status === 'closed') e.closed++;
    else e.review++;
  }

  const riskHistory = s.all<{ zone_id: string; from_level: string | null; to_level: string; computed_at: string; reasons: string }>(
    'SELECT * FROM risk_history WHERE event_id = ? ORDER BY computed_at',
    eventId,
  ).map((r) => ({ zone: zones.get(r.zone_id) ?? r.zone_id, from: r.from_level, to: r.to_level, at: r.computed_at, reasons: (JSON.parse(r.reasons) as { message: string }[]).map((x) => x.message).slice(0, 3) }));

  const responderStats = responders.map((r) => {
    const mine = assignments.filter((a) => a.responderId === r.id);
    const decided = mine.filter((a) => a.status !== 'cancelled' || a.acknowledgedAt);
    return {
      responder: r.name,
      assignments: mine.length,
      acknowledged: mine.filter((a) => a.acknowledgedAt).length,
      declinedOrUnable: mine.filter((a) => a.status === 'declined' || a.status === 'unable').length,
      escalated: mine.filter((a) => a.escalatedAt).length,
      ackRate: decided.length ? mine.filter((a) => a.acknowledgedAt).length / decided.length : null,
      medianAssignToAckSec: median(mine.map((a) => secs(a.assignedAt, a.acknowledgedAt))),
    };
  });

  const staleMs = ev.settings.staleMinutes * 60_000;
  const activeIncidents = incidents.filter((i) => ACTIVE_INCIDENT_STATUSES.includes(i.status));
  const dataQuality = {
    staleActiveIncidents: activeIncidents.filter((i) => nowMs - new Date(i.updatedAt).getTime() > staleMs).map((i) => i.ref),
    queuedOfflineReports: perIncident.filter((p) => (p.syncDelaySec ?? 0) > 60).map((p) => ({ ref: p.ref, delaySec: p.syncDelaySec })),
    unverifiedActive: activeIncidents.filter((i) => ['submitted', 'under_review'].includes(i.status)).length,
    severityUnconfirmed: perIncident.filter((p) => !p.severityConfirmed).length,
    possibleDuplicatesFlagged: incidents.filter((i) => i.possibleDuplicateOf.length).length,
    mergedReports: all.filter((i) => i.mergedInto).length,
  };

  const timeline = s.all<{ at: string; actor_name: string | null; actor_role: string | null; action: string; entity_type: string; entity_id: string | null; details: string }>(
    "SELECT * FROM audit_log WHERE event_id = ? AND action NOT IN ('occupancy.reported') ORDER BY id",
    eventId,
  ).map((r) => ({ at: r.at, actor: r.actor_name ?? 'System', role: r.actor_role, action: r.action, entityType: r.entity_type, entityId: r.entity_id, details: JSON.parse(r.details) }));

  return {
    dataLabel: ev.isDemo ? 'DEMO DATA — simulated scenario records. Not real-world incidents or performance evidence.' : 'Operational data recorded by this deployment.',
    isDemo: ev.isDemo,
    generatedAt: ctx.now().toISOString(),
    filter: f,
    totals: {
      incidents: incidents.length,
      active: activeIncidents.length,
      resolvedOrClosed: incidents.filter((i) => i.status === 'resolved' || i.status === 'closed').length,
      rejected: incidents.filter((i) => i.status === 'rejected').length,
      reopened: incidents.filter((i) => i.reopenCount > 0).length,
      urgent: incidents.filter((i) => i.urgent).length,
    },
    byCategory: count((i) => i.category).map((x) => ({ ...x, label: CATEGORY_LABEL[x.key as IncidentCategory] })),
    byZone: count((i) => zones.get(i.zoneId ?? '') ?? 'Unzoned'),
    bySeverity: count((i) => i.confirmedSeverity ?? `${i.severityEstimate} (unconfirmed)`),
    byStatus: count((i) => i.status).map((x) => ({ ...x, label: STATUS_LABEL[x.key as IncidentStatus] })),
    contextNote: 'Stage times show where time was spent, not how well anyone performed. Longer times can reflect terrain, closed or restricted routes, distance, or a more difficult incident.',
    medians: {
      reportToVerifySec: median(perIncident.map((p) => p.toVerifySec)),
      reportToAssignSec: median(perIncident.map((p) => p.toAssignSec)),
      reportToAckSec: median(perIncident.map((p) => p.toAckSec)),
      reportToResolveSec: median(perIncident.map((p) => p.toResolveSec)),
      sampleSize: {
        verify: perIncident.filter((p) => p.toVerifySec != null).length,
        assign: perIncident.filter((p) => p.toAssignSec != null).length,
        ack: perIncident.filter((p) => p.toAckSec != null).length,
        resolve: perIncident.filter((p) => p.toResolveSec != null).length,
      },
    },
    perIncident,
    closures: closures.map((c) => ({ segment: c.segment_name, status: c.status, reason: c.reason, source: c.source, at: c.created_at, liftedAt: c.lifted_at })),
    closureFrequency: Object.values(closureFreq),
    riskHistory,
    responderStats,
    dataQuality,
    timeline,
  };
}

const csvCell = (v: unknown) => {
  const s = v == null ? '' : String(v);
  // Neutralise spreadsheet formula injection and quote.
  const safe = /^[=+\-@\t\r]/.test(s) ? `'${s}` : s;
  return `"${safe.replace(/"/g, '""')}"`;
};

export function analyticsCsv(ctx: Ctx, eventId: string, f: AnalyticsFilter = {}): string {
  const a = computeAnalytics(ctx, eventId, f);
  const ev = ctx.store.event(eventId)!;
  const lines: string[] = [];
  lines.push(csvCell(`HillCrowd NE post-event report — ${ev.name}`));
  lines.push(csvCell(a.dataLabel));
  lines.push(csvCell(`Generated ${a.generatedAt}`));
  lines.push('');
  const header = ['ref', 'category', 'zone', 'status', 'severity', 'severity_confirmed', 'urgent', 'created_on_device', 'received_by_server', 'sync_delay_s', 'report_to_verify_s', 'report_to_assign_s', 'report_to_ack_s', 'report_to_resolve_s', 'reopen_count', 'demo_record'];
  lines.push(header.map(csvCell).join(','));
  for (const p of a.perIncident) {
    lines.push(
      [p.ref, CATEGORY_LABEL[p.category], p.zone, p.status, p.severity, p.severityConfirmed, p.urgent, p.createdLocalAt, p.receivedAt, p.syncDelaySec, p.toVerifySec, p.toAssignSec, p.toAckSec, p.toResolveSec, p.reopenCount, p.isDemo]
        .map(csvCell)
        .join(','),
    );
  }
  lines.push('');
  lines.push(['metric', 'value_seconds', 'sample_size'].map(csvCell).join(','));
  lines.push(['median_report_to_assignment', a.medians.reportToAssignSec, a.medians.sampleSize.assign].map(csvCell).join(','));
  lines.push(['median_report_to_acknowledgement', a.medians.reportToAckSec, a.medians.sampleSize.ack].map(csvCell).join(','));
  lines.push(['median_report_to_resolution', a.medians.reportToResolveSec, a.medians.sampleSize.resolve].map(csvCell).join(','));
  lines.push('');
  lines.push(['route_segment', 'status', 'reason', 'source', 'at', 'lifted_at'].map(csvCell).join(','));
  for (const c of a.closures) lines.push([c.segment, c.status, c.reason, c.source, c.at, c.liftedAt].map(csvCell).join(','));
  return lines.join('\r\n') + '\r\n';
}
