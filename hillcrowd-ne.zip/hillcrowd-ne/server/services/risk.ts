import { assessZone } from '../../shared/risk';
import { audit, type Ctx } from '../context';
import { newId } from '../db';
import type { RiskCondition, ZoneRisk } from '../../shared/types';
import { liveResilience } from './resilience';

/** Compute current risk for every zone of an event (pure computation over current records). */
export function computeEventRisk(ctx: Ctx, eventId: string): ZoneRisk[] {
  const s = ctx.store;
  const ev = s.event(eventId);
  if (!ev) return [];
  const inputs = {
    observations: s.observations(eventId),
    incidents: s.incidents(eventId),
    facilities: s.facilities(eventId),
    nodes: s.nodes(eventId),
    segments: s.segments(eventId),
    advisories: s.advisories(eventId),
    checklist: s.checklist(eventId),
    settings: ev.settings,
    now: ctx.now(),
  };
  // Medical access lost on the live network is a zone-level concern (egress is checked inside assessZone).
  const extra = new Map<string, RiskCondition[]>();
  for (const l of liveResilience(ctx, eventId).links) {
    if (l.link.kind !== 'medical_access' || l.status !== 'lost' || !l.link.zoneId) continue;
    (extra.get(l.link.zoneId) ?? extra.set(l.link.zoneId, []).get(l.link.zoneId)!).push({
      code: 'MEDICAL_ACCESS_LOST',
      level: 'elevated',
      critical: false,
      message: `No approved walking route from ${l.link.label.split(' → ')[0]} into this zone with current closures. Agree an access plan by radio.`,
      source: 'Route Resilience Engine (live network)',
      observedAt: null,
      stale: false,
      verified: true,
    });
  }
  return s.zones(eventId).map((zone) => assessZone({ zone, ...inputs, extraConditions: extra.get(zone.id) }));
}

/** Compute risk and record every change of level to the risk history and audit log. */
export function refreshRisk(ctx: Ctx, eventId: string): { risks: ZoneRisk[]; changed: number } {
  const risks = computeEventRisk(ctx, eventId);
  const zoneNames = new Map(ctx.store.zones(eventId).map((z) => [z.id, z.name]));
  let changed = 0;
  ctx.store.tx(() => {
    for (const r of risks) {
      const last = ctx.store.get<{ to_level: string }>('SELECT to_level FROM risk_history WHERE zone_id = ? ORDER BY computed_at DESC, rowid DESC LIMIT 1', r.zoneId);
      if (last?.to_level === r.level) continue;
      changed++;
      const reasons = r.conditions.map((c) => ({ code: c.code, level: c.level, message: c.message, source: c.source, verified: c.verified }));
      ctx.store.insert('risk_history', { id: newId('rh'), event_id: eventId, zone_id: r.zoneId, from_level: last?.to_level ?? null, to_level: r.level, reasons, computed_at: r.computedAt });
      audit(ctx, null, eventId, 'risk.level_changed', 'zone', r.zoneId, { name: zoneNames.get(r.zoneId) ?? r.zoneId, from: last?.to_level ?? null, to: r.level, reasons: reasons.slice(0, 5) });
    }
  });
  if (changed) ctx.bus.emit(eventId, 'risk');
  return { risks, changed };
}
