import { audit, HttpError, iso, type Ctx } from '../context';
import { newId, Store } from '../db';
import { assertAssignmentTransition, WorkflowError } from '../../shared/workflow';
import { findRoute } from '../../shared/routing';
import { ACTIVE_ASSIGNMENT_STATUSES, STAGE_LABEL } from '../../shared/constants';
import { incidentStages } from '../../shared/accountability';
import { getIncidentOr404, recordUpdate, transitionIncident } from './incidents';
import { nearestNode } from './network';
import { can } from '../../shared/permissions';
import type { AssignmentStatus, Incident, Responder, RouteResult, User } from '../../shared/types';

/** Used when event settings, not a person, cause a transition. */
export const SYSTEM_ACTOR: User = { id: 'system', username: 'system', displayName: 'System (event settings)', role: 'coordinator', responderId: null, isDemo: false };

const RESPONDER_STATUS: Partial<Record<AssignmentStatus, Responder['status']>> = {
  assigned: 'assigned',
  acknowledged: 'acknowledged',
  en_route: 'en_route',
  on_scene: 'on_scene',
  resolved: 'available',
  declined: 'available',
  unable: 'available',
  cancelled: 'available',
};

/** Route from the responder's base/location to the network node nearest the incident, respecting mode and access. */
export function routeForResponder(ctx: Ctx, responder: Responder, inc: Incident): RouteResult | null {
  const nodes = ctx.store.nodes(inc.eventId);
  const segments = ctx.store.segments(inc.eventId);
  const origin = responder.baseNodeId ?? (responder.lat != null ? nearestNode(nodes, responder.lat, responder.lng!)?.id : null);
  const dest = inc.lat != null ? nearestNode(nodes, inc.lat, inc.lng!)?.id : null;
  if (!origin || !dest) return null;
  // Try each configured mode in order of preference; report the first feasible one, else the last failure.
  let last: RouteResult | null = null;
  for (const mode of responder.modes) {
    const r = findRoute(nodes, segments, { from: origin, to: dest, mode, access: responder.access }, ctx.now());
    if (r.found) return r;
    last = r;
  }
  return last;
}

const activeFor = (ctx: Ctx, incidentId: string, exceptId?: string) =>
  ctx.store
    .all(`SELECT * FROM assignments WHERE incident_id = ? AND status IN (${ACTIVE_ASSIGNMENT_STATUSES.map(() => '?').join(',')})`, incidentId, ...ACTIVE_ASSIGNMENT_STATUSES)
    .filter((a) => a.id !== exceptId);

export function createAssignment(ctx: Ctx, actor: User, incidentId: string, responderId: string, note = '') {
  const s = ctx.store;
  const inc = getIncidentOr404(ctx, incidentId);
  if (inc.mergedInto) throw new HttpError(409, 'Assign the primary incident, not a merged report.');
  if (!['verified', 'assigned', 'acknowledged', 'in_progress'].includes(inc.status)) {
    throw new HttpError(409, inc.status === 'submitted' || inc.status === 'under_review' ? 'Verify the report before assigning a responder.' : `Cannot assign an incident that is ${inc.status}.`);
  }
  const r = s.get('SELECT * FROM responders WHERE id = ?', responderId);
  if (!r || r.event_id !== inc.eventId) throw new HttpError(404, 'Responder not found for this event.');
  const responder = Store.responder(r);
  if (responder.status !== 'available') throw new HttpError(409, `${responder.name} is not available (currently ${responder.status.replace('_', ' ')}).`);
  if (activeFor(ctx, incidentId).some((a) => a.responder_id === responderId)) throw new HttpError(409, 'This responder already has an active assignment for this incident.');

  const route = routeForResponder(ctx, responder, inc);
  const id = newId('asg');
  const at = iso(ctx);
  s.tx(() => {
    s.insert('assignments', {
      id,
      event_id: inc.eventId,
      incident_id: incidentId,
      responder_id: responderId,
      status: 'assigned',
      assigned_by: actor.id,
      note,
      assigned_at: at,
      route: route ?? null,
    });
    s.update('responders', responderId, { status: 'assigned' });
    if (inc.status === 'verified') {
      transitionIncident(ctx, actor, incidentId, 'assigned', `Assigned to ${responder.name}`, { internal: true });
    }
    s.update('incidents', incidentId, { owner_id: responderId, assigned_at: inc.assignedAt ?? at, updated_at: at });
    recordUpdate(ctx, inc, actor, 'assignment', null, null, `Assigned to ${responder.name}${note ? ` — ${note}` : ''}. ${route ? (route.found ? `Route: ${route.distanceM} m (${route.mode}).` : 'NO VALID ROUTE FOUND — coordinator review required.') : 'Route not computed (location unknown).'}`);
    audit(ctx, actor, inc.eventId, 'assignment.created', 'assignment', id, { incident: inc.ref, responder: responder.name, routeFound: route?.found ?? null });
  });
  ctx.bus.emit(inc.eventId, 'assignment');
  return s.assignment(id)!;
}

export function updateAssignment(ctx: Ctx, actor: User, assignmentId: string, to: AssignmentStatus, note = '') {
  const s = ctx.store;
  const a = s.assignment(assignmentId);
  if (!a) throw new HttpError(404, 'Assignment not found.');
  const rRow = s.get('SELECT * FROM responders WHERE id = ?', a.responderId)!;
  const responder = Store.responder(rRow);
  const isOwn = responder.userId === actor.id;
  let onBehalf = false;
  if (!isOwn) {
    if (!can(actor.role, 'assignment.recordOnBehalf')) throw new HttpError(403, 'Only the assigned responder can update this assignment.');
    onBehalf = true;
    if (to !== 'cancelled' && !note.trim()) throw new HttpError(400, 'Record how the update was received (e.g. radio confirmation) when updating on behalf of a responder.');
  }
  if (to === 'cancelled' && !can(actor.role, 'assignment.create')) throw new HttpError(403, 'Only the control room can cancel an assignment.');
  try {
    assertAssignmentTransition(a.status, to);
  } catch (e) {
    if (e instanceof WorkflowError) throw new HttpError(409, e.message);
    throw e;
  }
  if (['declined', 'unable', 'resolved', 'cancelled'].includes(to) && !note.trim()) throw new HttpError(400, 'A short note is required for this update.');

  const at = iso(ctx);
  const patch: Record<string, any> = { status: to };
  if (to === 'acknowledged') patch.acknowledged_at = at;
  if (to === 'en_route') patch.en_route_at = at;
  if (to === 'on_scene') patch.on_scene_at = at;
  if (to === 'resolved') patch.resolved_at = at;
  if (['declined', 'unable', 'cancelled'].includes(to)) patch.closed_reason = note;

  const inc = getIncidentOr404(ctx, a.incidentId);
  const ev = s.event(inc.eventId)!;
  s.tx(() => {
    s.update('assignments', assignmentId, patch);
    s.update('responders', responder.id, { status: RESPONDER_STATUS[to] ?? 'available' });
    const label = `${responder.name}: ${to.replace('_', ' ')}${onBehalf ? ` (recorded by ${actor.displayName})` : ''}`;
    recordUpdate(ctx, inc, actor, 'assignment_update', null, null, `${label}${note ? ` — ${note}` : ''}`);
    audit(ctx, actor, inc.eventId, `assignment.${to}`, 'assignment', assignmentId, { incident: inc.ref, responder: responder.name, from: a.status, to, note, onBehalf });

    // Propagate to the incident workflow.
    const cur = s.incident(inc.id)!;
    const others = activeFor(ctx, inc.id, assignmentId);
    if (to === 'acknowledged' && cur.status === 'assigned') {
      transitionIncident(ctx, actor, inc.id, 'acknowledged', `${responder.name} acknowledged`, { internal: true });
    }
    if ((to === 'en_route' || to === 'on_scene') && ['assigned', 'acknowledged'].includes(cur.status)) {
      if (cur.status === 'assigned') transitionIncident(ctx, actor, inc.id, 'acknowledged', `${responder.name} acknowledged`, { internal: true });
      transitionIncident(ctx, actor, inc.id, 'in_progress', `${responder.name} ${to.replace('_', ' ')}`, { internal: true });
    }
    if (to === 'resolved' && others.length === 0 && ['assigned', 'acknowledged', 'in_progress'].includes(cur.status)) {
      transitionIncident(ctx, actor, inc.id, 'resolved', `${responder.name}: ${note}`, { internal: true });
      if (!ev.settings.requireResolutionVerification) {
        transitionIncident(ctx, SYSTEM_ACTOR, inc.id, 'closed', 'Auto-closed: resolution verification not required by event settings', { internal: true });
      }
    }
    if (['declined', 'unable', 'cancelled'].includes(to) && others.length === 0 && ['assigned', 'acknowledged', 'in_progress'].includes(cur.status)) {
      transitionIncident(ctx, actor, inc.id, 'verified', `Returned for reassignment: ${responder.name} ${to}${note ? ` — ${note}` : ''}`, { internal: true });
      recordUpdate(ctx, inc, null, 'feasibility', null, null, feasibilitySummary(ctx, inc));
    }
  });
  ctx.bus.emit(inc.eventId, 'assignment');
  return s.assignment(assignmentId)!;
}

/** Escalate unacknowledged assignments and urgent reports awaiting review. Idempotent; run on a timer. */
/**
 * Escalate any incident whose current response stage has overrun its configured target
 * (targets by severity, with per-category overrides). Each stage escalates at most once.
 * Overrunning a target is a prompt to act, not a judgement of performance.
 */
export function runEscalations(ctx: Ctx, eventId: string): number {
  const s = ctx.store;
  const ev = s.event(eventId);
  if (!ev) return 0;
  const now = ctx.now();
  const assignments = s.assignments(eventId);
  const names = new Map(s.responders(eventId).map((r) => [r.id, r.name]));
  let n = 0;
  for (const inc of s.incidents(eventId)) {
    if (inc.mergedInto || ['closed', 'rejected'].includes(inc.status)) continue;
    const st = incidentStages(inc, assignments, ev.settings, (id) => names.get(id) ?? id, now);
    if (!st.current || !st.overdue) continue;
    const tag = `[stage:${st.current}]`;
    const cur = assignments.filter((a) => a.incidentId === inc.id && ['assigned', 'acknowledged', 'en_route', 'on_scene'].includes(a.status)).at(-1);
    // Acceptance restarts per assignment, so key that stage on the assignment id.
    const key = st.current === 'accept' && cur ? `${tag}[asg:${cur.id}]` : tag;
    if (s.get("SELECT 1 FROM incident_updates WHERE incident_id = ? AND kind = 'escalation' AND note LIKE ?", inc.id, `${key}%`)) continue;
    const mins = Math.round((st.elapsedSec ?? 0) / 60);
    const reason = `${key} ${STAGE_LABEL[st.current]} has taken ${mins} min (target ${Math.round(st.targetSec! / 60)} min for ${inc.confirmedSeverity ?? inc.severityEstimate} ${inc.category.replace('_', ' ')}). Next: ${st.nextActor ?? 'Control room'} — ${st.nextAction}.`;
    s.tx(() => {
      if (st.current === 'accept' && cur) s.update('assignments', cur.id, { escalated_at: now.toISOString(), escalation_reason: reason.replace(/^\[[^\]]+\](\[[^\]]+\])? /, '') });
      recordUpdate(ctx, inc, null, 'escalation', null, null, reason);
      audit(ctx, null, eventId, 'incident.escalated', 'incident', inc.id, { ref: inc.ref, stage: st.current, reason });
    });
    n++;
  }
  if (n) ctx.bus.emit(eventId, 'escalation');
  return n;
}

/** After a decline or inability to respond, recheck which available teams still have an approved route. */
export function feasibilitySummary(ctx: Ctx, inc: Incident): string {
  const available = ctx.store.responders(inc.eventId).filter((r) => r.status === 'available');
  if (!available.length) return 'Route feasibility rechecked: no responders are currently available.';
  const parts = available.map((r) => {
    const route = routeForResponder(ctx, r, inc);
    return { name: r.name, ok: !!route?.found, dist: route?.distanceM };
  });
  const ok = parts.filter((p) => p.ok);
  return `Route feasibility rechecked: ${ok.length} of ${parts.length} available team(s) have an approved route (${parts.map((p) => `${p.name}: ${p.ok ? `${p.dist} m` : 'no route'}`).join('; ')}).`;
}
