import { audit, HttpError, iso, type Ctx } from '../context';
import { newId, Store } from '../db';
import { hashPassword } from '../auth';
import { DEFAULT_SETTINGS } from '../../shared/constants';
import {
  CHECKLIST_TEMPLATE,
  DEMO_CHECKLIST_STATE,
  DEMO_EVENT_ID,
  DEMO_ORIGIN,
  DEMO_PASSWORD,
  DEMO_USERS,
  LAYOUT,
  PLAYBOOKS,
  configuredLength,
  nodeLatLng,
  segmentPath,
  zonePolygon,
} from '../seed/demoData';
import { offsetM } from '../../shared/geo';
import { createIncident, transitionIncident } from './incidents';
import { createAdvisory, reportOccupancy, setAdvisoryVerification } from './operations';
import { setFacilityStatus, setSegmentStatus } from './network';
import { createAssignment, updateAssignment } from './assignments';
import { refreshRisk } from './risk';
import type { User } from '../../shared/types';

/** Users and playbooks. Idempotent. Demo users are created only when demo mode is enabled. */
export function seedBase(ctx: Ctx) {
  const s = ctx.store;
  s.tx(() => {
    for (const pb of PLAYBOOKS) {
      const row = { key: pb.key, title: pb.title, categories: pb.categories, trigger_text: pb.trigger, escalation: pb.escalation, steps: pb.steps };
      const existing = s.get<{ id: string }>('SELECT id FROM playbooks WHERE key = ?', pb.key);
      if (!existing) s.insert('playbooks', { id: `pb-${pb.key}`, ...row });
    }
    if (ctx.demoMode) {
      const hash = hashPassword(DEMO_PASSWORD);
      for (const u of DEMO_USERS) {
        if (!s.get('SELECT 1 FROM users WHERE id = ?', u.id)) {
          s.insert('users', { id: u.id, username: u.username, display_name: u.displayName, role: u.role, password_hash: hash, is_demo: true, created_at: iso(ctx) });
        }
      }
    }
  });
}

/**
 * Build a full event from the demo layout. With `opts.id` / `opts.origin` the same layout can be
 * used as a template for a new event (fresh IDs, re-centred) — still a fictional layout.
 */
export function buildLayoutEvent(ctx: Ctx, opts: { id: string; isDemo: boolean; origin?: [number, number]; meta?: Partial<Record<string, unknown>>; actor?: User | null }) {
  const s = ctx.store;
  const origin = opts.origin ?? DEMO_ORIGIN;
  const shift = (ll: [number, number]): [number, number] => [Number((ll[0] - DEMO_ORIGIN[0] + origin[0]).toFixed(6)), Number((ll[1] - DEMO_ORIGIN[1] + origin[1]).toFixed(6))];
  const pre = opts.isDemo ? '' : `${opts.id.slice(-6)}-`;
  const id = (k: string) => `${pre}${k}`;
  const now = ctx.now();
  const at = now.toISOString();

  s.insert('events', {
    id: opts.id,
    name: 'Monsoon Music & Culture Evening (DEMO SCENARIO)',
    event_type: 'Festival',
    state: 'Meghalaya',
    district: 'East Khasi Hills',
    location_label: 'Shillong area — illustrative placement',
    venue_name: 'Ridge Grounds (fictional demonstration venue)',
    venue_is_fictional: true,
    starts_at: new Date(now.getTime() - 2 * 3600_000).toISOString(),
    ends_at: new Date(now.getTime() + 6 * 3600_000).toISOString(),
    expected_attendance: 9000,
    venue_capacity: 12000,
    control_contact: 'Event Control Room — radio channel 1 (demo)',
    center_lat: origin[0],
    center_lng: origin[1],
    zoom: 17,
    boundary: LAYOUT.boundary.map(shift),
    is_demo: opts.isDemo,
    settings: DEFAULT_SETTINGS,
    created_at: at,
    ...(opts.meta ?? {}),
  });

  const nodeByKey = new Map(LAYOUT.nodes.map((n) => [n.key, n]));
  for (const n of LAYOUT.nodes) {
    const [lat, lng] = shift(nodeLatLng(n));
    s.insert('route_nodes', { id: id(n.key), event_id: opts.id, name: n.name, lat, lng, facility_id: null });
  }
  for (const z of LAYOUT.zones) {
    s.insert('zones', {
      id: id(`zone-${z.key}`),
      event_id: opts.id,
      name: z.name,
      polygon: zonePolygon(z.pts).map(shift),
      capacity: z.capacity,
      watch_pct: 80,
      elevated_pct: 95,
      critical_pct: 110,
      required_exit_ids: z.required.map(id),
      exit_ids: z.exits.map(id),
      notes: z.notes,
      comms_fallback: opts.isDemo ? z.comms : '',
    });
  }
  for (const f of LAYOUT.facilities) {
    const node = nodeByKey.get(f.node)!;
    const [lat, lng] = shift(nodeLatLng(node));
    s.insert('facilities', {
      id: id(f.key), event_id: opts.id, kind: f.kind, name: f.name, lat, lng, zone_id: f.zone ? id(`zone-${f.zone}`) : null,
      node_id: id(f.node), status: 'open', status_updated_at: at, capacity_per_min: f.capacityPerMin ?? null, notes: f.notes ?? '',
    });
    s.update('route_nodes', id(f.node), { facility_id: id(f.key) });
  }
  for (const seg of LAYOUT.segments) {
    const path = segmentPath(seg, nodeByKey).map(shift);
    s.insert('route_segments', {
      id: id(seg.key), event_id: opts.id, name: seg.name, from_node: id(seg.from), to_node: id(seg.to), distance_m: configuredLength(path),
      modes: seg.modes, access: seg.access, status: 'open', status_source: 'Venue route plan (demo)', status_updated_at: at, approved: true,
      constraint_note: seg.constraint ?? '', terrain_note: seg.terrain ?? '', weather_exposed: !!seg.weather, path,
    });
  }
  for (const r of LAYOUT.namedRoutes) {
    s.insert('named_routes', {
      id: id(r.key), event_id: opts.id, name: r.name, purpose: r.purpose, mode: r.mode, access: r.access, from_node: id(r.from), to_node: id(r.to),
      segment_ids: r.segs.map(id), approved_by: 'Venue safety plan (demo)', approved_at: at,
    });
  }
  for (const r of LAYOUT.responders) {
    const node = nodeByKey.get(r.base)!;
    const [lat, lng] = shift(nodeLatLng(node));
    s.insert('responders', {
      id: id(r.key), event_id: opts.id, name: r.name, team: r.team, kind: r.kind, modes: r.modes, access: r.access, status: 'available',
      base_node_id: id(r.base), lat, lng, location_source: 'Base post (configured, not live GPS)', location_updated_at: at,
      user_id: opts.isDemo ? r.user : null,
    });
  }
  for (const c of CHECKLIST_TEMPLATE) {
    const st = opts.isDemo ? DEMO_CHECKLIST_STATE[c.key] : { status: 'not_assessed', note: '' };
    s.insert('checklist_items', { id: id(`chk-${c.key}`), event_id: opts.id, key: c.key, label: c.label, status: st.status, note: st.note, zone_id: null, updated_by: null, updated_at: opts.isDemo ? at : null });
  }
}

export function seedDemoEvent(ctx: Ctx) {
  const s = ctx.store;
  if (s.event(DEMO_EVENT_ID)) return;
  s.tx(() => {
    buildLayoutEvent(ctx, { id: DEMO_EVENT_ID, isDemo: true });
    const now = ctx.now().getTime();
    // Initial occupancy estimates within configured limits (sample values, labelled as demo).
    // Four readings per zone so the trend view has data: B rising, C falling, A/D stable.
    const series: Record<string, number[]> = { a: [3950, 3900, 3920, 3900], b: [700, 760, 820, 900], c: [1500, 1460, 1420, 1400], d: [880, 890, 895, 900] };
    const ages = [20, 14, 8, 3];
    for (const [k, values] of Object.entries(series)) {
      values.forEach((v, i) => {
        s.insert('occupancy_observations', {
          id: newId('occ'), event_id: DEMO_EVENT_ID, zone_id: `zone-${k}`, value: v, observed_at: new Date(now - ages[i] * 60_000).toISOString(),
          source: 'Steward visual estimate (demo)', reported_by: k === 'b' ? 'usr-stw-b' : 'usr-stw-m',
        });
      });
    }
    for (const u of DEMO_USERS) s.run('INSERT OR IGNORE INTO event_access (user_id, event_id) VALUES (?, ?)', u.id, DEMO_EVENT_ID);
    audit(ctx, null, DEMO_EVENT_ID, 'demo.seeded', 'event', DEMO_EVENT_ID, { note: 'Demonstration event created from fictional layout.' });
  });
  refreshRisk(ctx, DEMO_EVENT_ID);
}

/** Remove only the demo event's data and re-seed it. Non-demo events and their records are untouched. */
export function resetDemo(ctx: Ctx, actor: User | null) {
  if (!ctx.demoMode) throw new HttpError(403, 'Demo mode is disabled.');
  const s = ctx.store;
  s.tx(() => {
    s.run("UPDATE sys_flags SET value = 1 WHERE key = 'allow_demo_purge'");
    try {
      const E = DEMO_EVENT_ID;
      s.run('DELETE FROM incident_updates WHERE event_id = ? AND is_demo = 1', E);
      s.run('DELETE FROM incident_actions WHERE event_id = ?', E);
      s.run('DELETE FROM assignments WHERE event_id = ?', E);
      s.run('UPDATE incidents SET merged_into = NULL WHERE event_id = ? AND is_demo = 1', E);
      s.run('DELETE FROM incidents WHERE event_id = ? AND is_demo = 1', E);
      s.run('DELETE FROM audit_log WHERE event_id = ? AND is_demo = 1', E);
      s.run('DELETE FROM route_closures WHERE event_id = ?', E);
      s.run('DELETE FROM risk_history WHERE event_id = ?', E);
      s.run('DELETE FROM advisories WHERE event_id = ?', E);
      s.run('DELETE FROM occupancy_observations WHERE event_id = ?', E);
      s.run('DELETE FROM checklist_items WHERE event_id = ?', E);
      s.run('DELETE FROM named_routes WHERE event_id = ?', E);
      s.run('UPDATE route_nodes SET facility_id = NULL WHERE event_id = ?', E);
      s.run('DELETE FROM responders WHERE event_id = ?', E);
      s.run('DELETE FROM facilities WHERE event_id = ?', E);
      s.run('DELETE FROM route_segments WHERE event_id = ?', E);
      s.run('DELETE FROM route_nodes WHERE event_id = ?', E);
      s.run('DELETE FROM zones WHERE event_id = ?', E);
      s.run('DELETE FROM event_access WHERE event_id = ?', E);
      s.run('DELETE FROM events WHERE id = ? AND is_demo = 1', E);
    } finally {
      s.run("UPDATE sys_flags SET value = 0 WHERE key = 'allow_demo_purge'");
    }
    // Permanent (non-demo) record that a reset happened.
    audit(ctx, actor, null, 'demo.reset', 'event', DEMO_EVENT_ID, { note: 'Demo scenario data reset. Non-demo data untouched.' });
  });
  seedBase(ctx);
  seedDemoEvent(ctx);
  ctx.bus.emit(DEMO_EVENT_ID, 'reset');
}

// ---------------- Scenario runner ----------------

const SCN_CLIENT_ID = 'demo-scenario-congestion-gate-b';
const ADVISORY_PREFIX = 'SAMPLE:';

function demoUser(s: Store, id: string): User {
  const u = s.userById(id);
  if (!u) throw new HttpError(500, `Demo user ${id} missing; reset the demo.`);
  return u;
}

function scenarioIncident(s: Store) {
  const byClient = s.get<{ id: string }>('SELECT id FROM incidents WHERE client_id = ?', SCN_CLIENT_ID);
  if (byClient) return s.incident(byClient.id);
  // If the presenter submitted the report manually through the steward app, follow that one.
  const manual = s.get<{ id: string }>(
    "SELECT id FROM incidents WHERE event_id = ? AND zone_id = 'zone-b' AND category = 'crowd_congestion' AND merged_into IS NULL ORDER BY received_at DESC LIMIT 1",
    DEMO_EVENT_ID,
  );
  return manual ? s.incident(manual.id) : null;
}

export interface ScenarioStep {
  key: string;
  n: number;
  title: string;
  actor: string;
  description: string;
  shows: string;
  done: boolean;
}

export function scenarioState(ctx: Ctx): { steps: ScenarioStep[]; incidentId: string | null; next: string | null } {
  const s = ctx.store;
  const inc = scenarioIncident(s);
  const asg = inc ? s.get('SELECT * FROM assignments WHERE incident_id = ? ORDER BY assigned_at DESC LIMIT 1', inc.id) : undefined;
  const adv = s.get("SELECT * FROM advisories WHERE event_id = ? AND is_sample = 1 AND title LIKE 'SAMPLE:%' ORDER BY created_at DESC LIMIT 1", DEMO_EVENT_ID);
  const s17 = s.get('SELECT status FROM route_segments WHERE id = ?', 's17');
  const done = {
    report: !!inc,
    verify: !!inc && !['submitted', 'under_review'].includes(inc.status),
    advisory: adv?.verification === 'verified',
    closure: s17?.status === 'closed',
    assign: !!asg,
    acknowledge: !!asg?.acknowledged_at,
    respond: !!asg?.on_scene_at,
    resolve: !!asg?.resolved_at || (!!inc && ['resolved', 'closed'].includes(inc.status)),
    close: !!inc && inc.status === 'closed',
  };
  const meta: Omit<ScenarioStep, 'done' | 'n'>[] = [
    { key: 'report', title: 'Steward reports congestion at Gate B', actor: 'Demo Steward – Gate B', description: 'Records an occupancy estimate for Zone B and submits an urgent congestion report from the field app.', shows: 'Field reporting, unverified state, live dashboard update' },
    { key: 'verify', title: 'Control room reviews and verifies', actor: 'Demo Coordinator', description: 'Starts review, confirms by radio, verifies with confirmed severity "high". The congestion playbook is proposed.', shows: 'Verification workflow, explainable Elevated flag, playbook' },
    { key: 'advisory', title: 'Sample heavy-rain advisory entered and verified', actor: 'Demo Coordinator', description: 'A clearly labelled SAMPLE advisory is entered manually and verified for the demo. Affected segments are marked for review — nothing is closed automatically.', shows: 'Advisory provenance, validity, routes under review' },
    { key: 'closure', title: 'Lower service road closed after inspection', actor: 'Demo Coordinator', description: 'Closes the Gate C – Handover H road. The approved medical vehicle route becomes invalid and an alternative via the upper ring road is identified.', shows: 'Route invalidation and alternative within the approved network' },
    { key: 'assign', title: 'Coordinator assigns Steward Team Alpha', actor: 'Demo Coordinator', description: 'Assigns the verified congestion incident; the system attaches a validated walking route.', shows: 'Human-approved assignment with route validation' },
    { key: 'acknowledge', title: 'Steward Team Alpha acknowledges', actor: 'Steward Team Alpha', description: 'Responder explicitly acknowledges in the responder app.', shows: 'Acknowledgement and accountability' },
    { key: 'respond', title: 'Team en route, then on scene', actor: 'Steward Team Alpha', description: 'Status updates are timestamped; a fresh occupancy estimate is recorded.', shows: 'Response tracking' },
    { key: 'resolve', title: 'Team marks the task resolved', actor: 'Steward Team Alpha', description: 'Resolution note recorded; the incident awaits coordinator confirmation.', shows: 'Resolution subject to verification' },
    { key: 'close', title: 'Coordinator confirms and closes', actor: 'Demo Coordinator', description: 'Closes the incident. Open Analytics to review recorded times and the timeline.', shows: 'Post-event review from recorded timestamps' },
  ];
  const steps = meta.map((m, i) => ({ ...m, n: i + 1, done: done[m.key as keyof typeof done] }));
  return { steps, incidentId: inc?.id ?? null, next: steps.find((x) => !x.done)?.key ?? null };
}

export function runScenarioStep(ctx: Ctx, key: string) {
  if (!ctx.demoMode) throw new HttpError(403, 'Demo mode is disabled.');
  const s = ctx.store;
  const state = scenarioState(ctx);
  const idx = state.steps.findIndex((x) => x.key === key);
  if (idx < 0) throw new HttpError(404, 'Unknown scenario step.');
  if (state.steps[idx].done) throw new HttpError(409, 'This step has already been completed. Reset the demo to replay.');
  const pending = state.steps.slice(0, idx).find((x) => !x.done);
  if (pending) throw new HttpError(409, `Complete step ${pending.n} ("${pending.title}") first.`);

  const coord = demoUser(s, 'usr-coord');
  const stew = demoUser(s, 'usr-stw-b');
  const alpha = demoUser(s, 'usr-alpha');
  const inc = scenarioIncident(s);
  const asg = inc ? s.get<{ id: string }>('SELECT id FROM assignments WHERE incident_id = ? ORDER BY assigned_at DESC LIMIT 1', inc.id) : undefined;

  switch (key) {
    case 'report': {
      reportOccupancy(ctx, stew, 'zone-b', 1380, 'Steward visual estimate (demo)');
      const [lat, lng] = offsetM(DEMO_ORIGIN, 150, 135);
      createIncident(ctx, stew, DEMO_EVENT_ID, {
        clientId: SCN_CLIENT_ID,
        category: 'crowd_congestion',
        zoneId: 'zone-b',
        lat,
        lng,
        description: 'Queue backing up inside the Gate B plaza; crowd pressure building at the barrier line. (Demo report)',
        severityEstimate: 'high',
        urgent: true,
        createdLocalAt: iso(ctx),
      });
      break;
    }
    case 'verify':
      transitionIncident(ctx, coord, inc!.id, 'under_review', 'Reviewing report from Gate B steward.');
      transitionIncident(ctx, coord, inc!.id, 'verified', 'Confirmed with Gate B steward by radio (demo).', { confirmedSeverity: 'high' });
      break;
    case 'advisory': {
      const now = ctx.now();
      const adv = createAdvisory(ctx, coord, DEMO_EVENT_ID, {
        title: `${ADVISORY_PREFIX} Heavy rainfall advisory for East Khasi Hills (demo scenario)`,
        issuer: 'Demo scenario — simulated. NOT issued by IMD, SDMA or any authority',
        sourceUrl: null,
        coverage: 'East Khasi Hills district (sample coverage)',
        body: 'Sample advisory text for demonstration only. In a live event, enter the official advisory and verify it against the issuing agency’s official channel.',
        issuedAt: now.toISOString(),
        expiresAt: new Date(now.getTime() + 6 * 3600_000).toISOString(),
        affectedZoneIds: ['zone-b', 'zone-c'],
        affectedSegmentIds: ['s17', 's22'],
        actionsNote: 'Inspect the lower service road and south-east lane; reassess emergency vehicle access.',
        isSample: true,
      });
      setAdvisoryVerification(ctx, coord, adv.id, 'verified', 'Verified for demonstration purposes only (sample advisory).');
      break;
    }
    case 'closure':
      setSegmentStatus(ctx, coord, 's17', {
        status: 'closed',
        reason: 'Water-logging and debris on the steep descent (demo inspection finding)',
        source: 'Field inspection by Steward Team Bravo, relayed by radio (demo)',
      });
      break;
    case 'assign':
      createAssignment(ctx, coord, inc!.id, 'r-alpha', 'Assess Gate B plaza and support the gate team with entry regulation if authorised.');
      break;
    case 'acknowledge':
      updateAssignment(ctx, alpha, asg!.id, 'acknowledged');
      break;
    case 'respond':
      updateAssignment(ctx, alpha, asg!.id, 'en_route');
      updateAssignment(ctx, alpha, asg!.id, 'on_scene');
      reportOccupancy(ctx, stew, 'zone-b', 1240, 'Steward visual estimate (demo)');
      break;
    case 'resolve':
      updateAssignment(ctx, alpha, asg!.id, 'resolved', 'Inflow regulated with the gate team (authorised by control room); pressure at barrier eased. (Demo)');
      reportOccupancy(ctx, stew, 'zone-b', 1050, 'Steward visual estimate (demo)');
      break;
    case 'close':
      transitionIncident(ctx, coord, inc!.id, 'closed', 'Resolution confirmed with Gate B steward (demo).');
      break;
  }
  refreshRisk(ctx, DEMO_EVENT_ID);
  return scenarioState(ctx);
}

// ---------------- Interactive exercise: inject simulated events ----------------

export interface Injection {
  key: string;
  title: string;
  detail: string;
  group: 'Reports' | 'Access & weather' | 'Resources';
}

export const INJECTIONS: Injection[] = [
  { key: 'congestion_gate_b', title: 'Congestion report at Gate B', detail: 'Steward reports crowd pressure; occupancy estimate jumps.', group: 'Reports' },
  { key: 'medical_zone_d', title: 'Medical incident in Zone D', detail: 'Person collapsed near the South Lawn.', group: 'Reports' },
  { key: 'conflicting_estimate', title: 'Conflicting crowd estimate (Zone A)', detail: 'A gate count disagrees with the steward estimate.', group: 'Reports' },
  { key: 'comms_loss_zone_c', title: 'Mobile data lost in Zone C', detail: 'Stewards relay by radio; Zone C has no recorded fallback.', group: 'Reports' },
  { key: 'rain_advisory', title: 'Heavy-rain advisory (sample)', detail: 'Verified sample advisory; rain-exposed sections go under review.', group: 'Access & weather' },
  { key: 'close_lower_road', title: 'Lower service road closed', detail: 'Debris on the steep descent; medical vehicle route must detour.', group: 'Access & weather' },
  { key: 'close_ring_road', title: 'Upper ring road (north–east) closed', detail: 'The detour also fails — exposes the access gap.', group: 'Access & weather' },
  { key: 'block_exit_d', title: 'Exit D blocked', detail: 'Required exit for Zone D becomes unavailable.', group: 'Access & weather' },
  { key: 'medical_team_unavailable', title: 'Medical Team 1 unavailable', detail: 'Team stood down; check medical coverage.', group: 'Resources' },
];

export function injectEvent(ctx: Ctx, actor: User, key: string) {
  if (!ctx.demoMode) throw new HttpError(403, 'Demo mode is disabled.');
  const s = ctx.store;
  const inj = INJECTIONS.find((i) => i.key === key);
  if (!inj) throw new HttpError(404, 'Unknown exercise event.');
  const stewB = demoUser(s, 'usr-stw-b');
  const stewM = demoUser(s, 'usr-stw-m');
  const coord = demoUser(s, 'usr-coord');
  const SIM = '[SIMULATED] ';
  switch (key) {
    case 'congestion_gate_b': {
      const z = s.get<{ value: number }>("SELECT value FROM occupancy_observations WHERE zone_id = 'zone-b' ORDER BY observed_at DESC LIMIT 1");
      reportOccupancy(ctx, stewB, 'zone-b', Math.min(1500, Math.max(1300, (z?.value ?? 900) + 250)), 'Steward visual estimate (demo)');
      const [lat, lng] = offsetM(DEMO_ORIGIN, 130, 120);
      createIncident(ctx, stewB, DEMO_EVENT_ID, { category: 'crowd_congestion', zoneId: 'zone-b', lat, lng, description: `${SIM}Crowd pressure building at the Gate B barrier line.`, severityEstimate: 'high', urgent: true });
      break;
    }
    case 'medical_zone_d': {
      const [lat, lng] = offsetM(DEMO_ORIGIN, -120, -90);
      createIncident(ctx, stewM, DEMO_EVENT_ID, { category: 'medical', zoneId: 'zone-d', lat, lng, description: `${SIM}Person collapsed near the family area; conscious, needs first aid.`, severityEstimate: 'high', urgent: true });
      break;
    }
    case 'conflicting_estimate':
      reportOccupancy(ctx, coord, 'zone-a', 5400, 'Gate A hand-counter tally (demo)');
      break;
    case 'comms_loss_zone_c': {
      const [lat, lng] = offsetM(DEMO_ORIGIN, 140, -60);
      createIncident(ctx, coord, DEMO_EVENT_ID, { category: 'communication', zoneId: 'zone-c', lat, lng, description: `${SIM}Stewards in the Market report no mobile data; relayed by radio to the control room.`, severityEstimate: 'moderate', urgent: false });
      break;
    }
    case 'rain_advisory': {
      if (s.get("SELECT 1 FROM advisories WHERE event_id = ? AND is_sample = 1 AND verification = 'verified'", DEMO_EVENT_ID)) throw new HttpError(409, 'A sample rain advisory is already active.');
      const now = ctx.now();
      const adv = createAdvisory(ctx, coord, DEMO_EVENT_ID, {
        title: `${ADVISORY_PREFIX} Heavy rainfall advisory for East Khasi Hills (exercise)`,
        issuer: 'Exercise — simulated. NOT issued by IMD, SDMA or any authority',
        sourceUrl: null,
        coverage: 'East Khasi Hills district (sample coverage)',
        body: 'Sample advisory for an exercise. In a live event, verify against the issuing agency’s official channel.',
        issuedAt: now.toISOString(),
        expiresAt: new Date(now.getTime() + 6 * 3600_000).toISOString(),
        affectedZoneIds: ['zone-b', 'zone-c'],
        affectedSegmentIds: s.segments(DEMO_EVENT_ID).filter((x) => x.weatherExposed).map((x) => x.id),
        actionsNote: 'Inspect rain-exposed sections; reassess emergency vehicle access.',
        isSample: true,
      });
      setAdvisoryVerification(ctx, coord, adv.id, 'verified', 'Verified for the exercise only (sample advisory).');
      break;
    }
    case 'close_lower_road':
    case 'close_ring_road': {
      const id = key === 'close_lower_road' ? 's17' : 's20';
      const seg = s.get<{ status: string }>('SELECT status FROM route_segments WHERE id = ?', id)!;
      if (seg.status === 'closed') throw new HttpError(409, 'That road is already closed.');
      setSegmentStatus(ctx, coord, id, {
        status: 'closed',
        reason: key === 'close_lower_road' ? `${SIM}Water-logging and debris on the steep descent` : `${SIM}Landslide debris across the narrow bend`,
        source: 'Exercise inject (simulated field inspection)',
      });
      break;
    }
    case 'block_exit_d': {
      const f = s.get<{ status: string }>("SELECT status FROM facilities WHERE id = 'exit-d'")!;
      if (f.status === 'closed') throw new HttpError(409, 'Exit D is already unavailable.');
      setFacilityStatus(ctx, coord, 'exit-d', { status: 'closed', reason: `${SIM}Exit D gate jammed; staff working to open it` });
      break;
    }
    case 'medical_team_unavailable':
      setResponderAvailability(ctx, coord, 'r-med1', false, `${SIM}Medical Team 1 stood down (exercise)`);
      break;
  }
  audit(ctx, actor, DEMO_EVENT_ID, 'exercise.inject', 'event', DEMO_EVENT_ID, { key, title: inj.title, simulated: true });
  refreshRisk(ctx, DEMO_EVENT_ID);
  ctx.bus.emit(DEMO_EVENT_ID, 'exercise');
  return { injected: inj.title };
}

/** Coordinator marks a responder available / unavailable (off duty). Cannot stand down a team mid-assignment. */
export function setResponderAvailability(ctx: Ctx, actor: User, responderId: string, available: boolean, reason: string) {
  const r = ctx.store.get<{ status: string; event_id: string; name: string }>('SELECT status, event_id, name FROM responders WHERE id = ?', responderId);
  if (!r) throw new HttpError(404, 'Responder not found.');
  if (available && r.status !== 'off_duty') throw new HttpError(409, `${r.name} is already on duty.`);
  if (!available && r.status !== 'available') throw new HttpError(409, r.status === 'off_duty' ? `${r.name} is already unavailable.` : `${r.name} has an active assignment; reassign it first.`);
  if (!reason.trim()) throw new HttpError(400, 'A reason is required.');
  ctx.store.tx(() => {
    ctx.store.update('responders', responderId, { status: available ? 'available' : 'off_duty' });
    audit(ctx, actor, r.event_id, available ? 'responder.available' : 'responder.unavailable', 'responder', responderId, { name: r.name, reason });
  });
  ctx.bus.emit(r.event_id, 'responder');
}
