import { audit, HttpError, iso, type Ctx } from '../context';
import { newId } from '../db';
import { findTransition, WorkflowError } from '../../shared/workflow';
import { haversineM, pointInPolygon, polygonCentroid } from '../../shared/geo';
import { ACTIVE_ASSIGNMENT_STATUSES, ACTIVE_INCIDENT_STATUSES } from '../../shared/constants';
import type { Incident, IncidentCategory, IncidentStatus, Severity, User } from '../../shared/types';

export interface NewIncidentInput {
  clientId?: string | null;
  category: IncidentCategory;
  zoneId?: string | null;
  lat?: number | null;
  lng?: number | null;
  description: string;
  severityEstimate: Severity;
  urgent?: boolean;
  createdLocalAt?: string | null;
  attachmentNote?: string | null;
}

export function recordUpdate(ctx: Ctx, inc: { id: string; eventId: string; isDemo: boolean }, actor: User | null, kind: string, from: IncidentStatus | null, to: IncidentStatus | null, note = '') {
  ctx.store.insert('incident_updates', {
    id: newId('upd'),
    event_id: inc.eventId,
    incident_id: inc.id,
    actor_id: actor?.id ?? null,
    kind,
    from_status: from,
    to_status: to,
    note,
    created_at: iso(ctx),
    is_demo: inc.isDemo,
  });
}

export function createIncident(ctx: Ctx, actor: User, eventId: string, input: NewIncidentInput): { incident: Incident; duplicateSubmission: boolean } {
  const s = ctx.store;
  const ev = s.event(eventId);
  if (!ev) throw new HttpError(404, 'Event not found.');

  // Idempotent submission: an offline queue may retry the same report.
  if (input.clientId) {
    const existing = s.get<{ id: string; reporter_id: string }>('SELECT id, reporter_id FROM incidents WHERE client_id = ?', input.clientId);
    if (existing) {
      if (existing.reporter_id !== actor.id) throw new HttpError(409, 'This submission ID is already in use.');
      return { incident: s.incident(existing.id)!, duplicateSubmission: true };
    }
  }

  const zones = s.zones(eventId);
  let zoneId = input.zoneId ?? null;
  if (zoneId && !zones.some((z) => z.id === zoneId)) throw new HttpError(400, 'Selected zone does not belong to this event.');
  const hasCoords = input.lat != null && input.lng != null;
  if (!zoneId && hasCoords) zoneId = zones.find((z) => pointInPolygon([input.lat!, input.lng!], z.polygon))?.id ?? null;
  if (!zoneId && !hasCoords) throw new HttpError(400, 'Select a venue zone or a map location.');

  let lat = input.lat ?? null;
  let lng = input.lng ?? null;
  if (!hasCoords && zoneId) {
    const z = zones.find((zz) => zz.id === zoneId)!;
    [lat, lng] = polygonCentroid(z.polygon);
  }

  const now = ctx.now();
  const at = now.toISOString();
  let createdLocalAt = at;
  if (input.createdLocalAt) {
    const d = new Date(input.createdLocalAt);
    if (Number.isNaN(d.getTime())) throw new HttpError(400, 'Invalid local creation time.');
    // Allow modest device clock skew; never accept a creation time far in the future.
    if (d.getTime() > now.getTime() + 5 * 60_000) throw new HttpError(400, 'Local creation time is in the future; check the device clock.');
    createdLocalAt = d.toISOString();
  }

  // Possible duplicates: same category, recent, same zone or nearby. Flagged, never deleted or auto-merged.
  const windowStart = new Date(now.getTime() - ev.settings.duplicateWindowMinutes * 60_000).toISOString();
  const candidates = s.incidents(eventId).filter(
    (i) => !i.mergedInto && i.category === input.category && ACTIVE_INCIDENT_STATUSES.includes(i.status) && i.receivedAt >= windowStart,
  );
  const dupes = candidates
    .filter((i) => (zoneId && i.zoneId === zoneId) || (lat != null && i.lat != null && haversineM([lat, lng!], [i.lat, i.lng!]) <= ev.settings.duplicateRadiusM))
    .map((i) => i.id);

  const count = s.get<{ n: number }>('SELECT COUNT(*) AS n FROM incidents WHERE event_id = ?', eventId)!.n;
  const id = newId('inc');
  const ref = `HC-${String(count + 1).padStart(4, '0')}`;

  s.tx(() => {
    s.insert('incidents', {
      id,
      ref,
      event_id: eventId,
      client_id: input.clientId ?? null,
      category: input.category,
      zone_id: zoneId,
      lat,
      lng,
      description: input.description.trim(),
      severity_estimate: input.severityEstimate,
      urgent: !!input.urgent,
      status: 'submitted',
      reporter_id: actor.id,
      created_local_at: createdLocalAt,
      received_at: at,
      updated_at: at,
      possible_duplicate_of: dupes,
      is_demo: ev.isDemo,
      attachment_note: input.attachmentNote ?? null,
    });
    const meta = { id, eventId, isDemo: ev.isDemo };
    recordUpdate(ctx, meta, actor, 'created', null, 'submitted', input.description.trim());
    if (dupes.length) recordUpdate(ctx, meta, null, 'duplicate_flag', null, null, `Possible duplicate of ${dupes.length} recent report(s) in the same area. Review before merging.`);
    audit(ctx, actor, eventId, 'incident.created', 'incident', id, { ref, category: input.category, zoneId, urgent: !!input.urgent, possibleDuplicates: dupes, clientId: input.clientId ?? null });
  });
  ctx.bus.emit(eventId, 'incident');
  return { incident: s.incident(id)!, duplicateSubmission: false };
}

export function getIncidentOr404(ctx: Ctx, id: string): Incident {
  const inc = ctx.store.incident(id);
  if (!inc) throw new HttpError(404, 'Incident not found.');
  return inc;
}

export function transitionIncident(ctx: Ctx, actor: User, id: string, to: IncidentStatus, note = '', opts: { confirmedSeverity?: Severity | null; internal?: boolean } = {}) {
  const s = ctx.store;
  const inc = getIncidentOr404(ctx, id);
  if (inc.mergedInto) throw new HttpError(409, `This report was merged into another incident; act on the primary record.`);
  let t;
  try {
    t = findTransition(inc.status, to, actor.role, { internal: opts.internal });
  } catch (e) {
    if (e instanceof WorkflowError) throw new HttpError(e.status, e.message);
    throw e;
  }
  if (t.requiresNote && !note.trim()) throw new HttpError(400, `A reason is required to ${t.label.toLowerCase()}.`);

  const at = iso(ctx);
  const patch: Record<string, any> = { status: to, updated_at: at };
  if (to === 'verified' && !inc.verifiedAt) {
    patch.verified_at = at;
    patch.confirmed_severity = opts.confirmedSeverity ?? inc.confirmedSeverity ?? inc.severityEstimate;
  }
  if (to === 'verified' && opts.confirmedSeverity) patch.confirmed_severity = opts.confirmedSeverity;
  if (to === 'resolved') patch.resolved_at = at;
  if (to === 'closed') patch.closed_at = at;
  if (to === 'acknowledged' && !inc.acknowledgedAt) patch.acknowledged_at = at;
  if (to === 'under_review' && ['resolved', 'closed', 'rejected'].includes(inc.status)) {
    patch.reopen_count = inc.reopenCount + 1;
    patch.resolved_at = null;
    patch.closed_at = null;
    patch.owner_id = null;
  }
  if (to === 'verified' && ['assigned', 'acknowledged', 'in_progress'].includes(inc.status)) patch.owner_id = null;

  s.tx(() => {
    s.update('incidents', id, patch);
    // Coordinator closing/resolving directly cancels any still-active assignments.
    if ((to === 'resolved' || to === 'closed') && actor.role !== 'responder') {
      for (const a of s.all('SELECT * FROM assignments WHERE incident_id = ? AND status IN (' + ACTIVE_ASSIGNMENT_STATUSES.map(() => '?').join(',') + ')', id, ...ACTIVE_ASSIGNMENT_STATUSES)) {
        s.update('assignments', a.id, { status: 'cancelled', closed_reason: `Incident ${to} by control room` });
        s.update('responders', a.responder_id, { status: 'available' });
      }
    }
    if (to === 'verified' && !inc.verifiedAt) instantiatePlaybook(ctx, inc);
    const kind = to === 'under_review' && patch.reopen_count ? 'reopened' : 'status';
    recordUpdate(ctx, inc, actor, kind, inc.status, to, note);
    audit(ctx, actor, inc.eventId, `incident.${kind === 'reopened' ? 'reopened' : to}`, 'incident', id, { ref: inc.ref, from: inc.status, to, note });
  });
  ctx.bus.emit(inc.eventId, 'incident');
  return s.incident(id)!;
}

export function setConfirmedSeverity(ctx: Ctx, actor: User, id: string, severity: Severity, note: string) {
  const inc = getIncidentOr404(ctx, id);
  if (['submitted', 'under_review', 'rejected'].includes(inc.status)) throw new HttpError(409, 'Severity can be confirmed only on a verified incident.');
  ctx.store.tx(() => {
    ctx.store.update('incidents', id, { confirmed_severity: severity, updated_at: iso(ctx) });
    recordUpdate(ctx, inc, actor, 'severity', null, null, `Confirmed severity set to ${severity}${note ? `: ${note}` : ''}`);
    audit(ctx, actor, inc.eventId, 'incident.severity', 'incident', id, { from: inc.confirmedSeverity, to: severity, note });
  });
  ctx.bus.emit(inc.eventId, 'incident');
  return ctx.store.incident(id)!;
}

export function addIncidentNote(ctx: Ctx, actor: User, id: string, note: string) {
  const inc = getIncidentOr404(ctx, id);
  ctx.store.tx(() => {
    ctx.store.update('incidents', id, { updated_at: iso(ctx) });
    recordUpdate(ctx, inc, actor, 'note', null, null, note);
    audit(ctx, actor, inc.eventId, 'incident.note', 'incident', id, { note });
  });
  ctx.bus.emit(inc.eventId, 'incident');
}

/** Merge a related report into a primary incident, keeping both records and their histories. */
export function mergeIncident(ctx: Ctx, actor: User, childId: string, parentId: string, note: string) {
  const child = getIncidentOr404(ctx, childId);
  const parent = getIncidentOr404(ctx, parentId);
  if (child.id === parent.id) throw new HttpError(400, 'An incident cannot be merged into itself.');
  if (child.eventId !== parent.eventId) throw new HttpError(400, 'Incidents belong to different events.');
  if (parent.mergedInto) throw new HttpError(409, 'Target incident has itself been merged; choose its primary record.');
  if (child.mergedInto) throw new HttpError(409, 'This report is already merged.');
  if (ctx.store.get('SELECT 1 FROM assignments WHERE incident_id = ? AND status IN (\'assigned\',\'acknowledged\',\'en_route\',\'on_scene\')', childId)) {
    throw new HttpError(409, 'Cancel or complete the active assignment on this report before merging.');
  }
  const at = iso(ctx);
  ctx.store.tx(() => {
    ctx.store.update('incidents', childId, { merged_into: parentId, status: 'closed', closed_at: at, updated_at: at });
    ctx.store.update('incidents', parentId, { updated_at: at });
    recordUpdate(ctx, child, actor, 'merged', child.status, 'closed', `Merged into ${parent.ref}. Original report retained. ${note}`.trim());
    recordUpdate(ctx, parent, actor, 'merge_received', null, null, `Related report ${child.ref} (by ${child.reporterName}) merged into this incident. ${note}`.trim());
    audit(ctx, actor, child.eventId, 'incident.merged', 'incident', childId, { into: parentId, childRef: child.ref, parentRef: parent.ref, note });
  });
  ctx.bus.emit(child.eventId, 'incident');
  return ctx.store.incident(parentId)!;
}

function instantiatePlaybook(ctx: Ctx, inc: Incident) {
  const existing = ctx.store.get('SELECT 1 FROM incident_actions WHERE incident_id = ?', inc.id);
  if (existing) return;
  const pbs = ctx.store.playbooks();
  const pb = pbs.find((p) => p.categories.includes(inc.category)) ?? pbs.find((p) => p.key === 'general');
  if (!pb) return;
  const now = ctx.now().getTime();
  pb.steps.forEach((st, idx) => {
    ctx.store.insert('incident_actions', {
      id: newId('act'),
      event_id: inc.eventId,
      incident_id: inc.id,
      playbook_id: pb.id,
      step_index: idx,
      title: st.title,
      detail: st.detail,
      approval: st.approval,
      action: st.action ?? null,
      status: 'pending',
      due_at: st.dueMinutes ? new Date(now + st.dueMinutes * 60_000).toISOString() : null,
      note: '',
    });
  });
  recordUpdate(ctx, inc, null, 'playbook', null, null, `Playbook proposed: ${pb.title} (${pb.steps.length} steps). Recommendations require human approval.`);
}

export function updateAction(ctx: Ctx, actor: User, actionId: string, status: 'done' | 'skipped' | 'overridden' | 'pending', note: string) {
  const a = ctx.store.get('SELECT * FROM incident_actions WHERE id = ?', actionId);
  if (!a) throw new HttpError(404, 'Playbook action not found.');
  if ((status === 'skipped' || status === 'overridden') && !note.trim()) throw new HttpError(400, 'A reason is required to skip or override a playbook step.');
  if (a.approval === 'safety_authority' && status === 'done' && !note.trim()) {
    throw new HttpError(400, 'This step requires the designated safety authority. Record who authorised the decision.');
  }
  const inc = getIncidentOr404(ctx, a.incident_id);
  const at = iso(ctx);
  ctx.store.tx(() => {
    ctx.store.update('incident_actions', actionId, {
      status,
      note,
      completed_by: status === 'pending' ? null : actor.id,
      completed_at: status === 'pending' ? null : at,
    });
    ctx.store.update('incidents', inc.id, { updated_at: at });
    recordUpdate(ctx, inc, actor, 'playbook_step', null, null, `Step "${a.title}" marked ${status}${note ? `: ${note}` : ''}`);
    audit(ctx, actor, inc.eventId, status === 'overridden' ? 'playbook.override' : 'playbook.step', 'incident_action', actionId, { incident: inc.ref, step: a.title, status, note });
  });
  ctx.bus.emit(inc.eventId, 'incident');
}
