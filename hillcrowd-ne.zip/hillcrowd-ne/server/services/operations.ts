import { audit, HttpError, iso, type Ctx } from '../context';
import { newId } from '../db';
import { setSegmentStatus } from './network';
import { can } from '../../shared/permissions';
import type { AdvisoryVerification, ChecklistStatus, User } from '../../shared/types';

// ---------------- Advisories ----------------

export interface AdvisoryInput {
  title: string;
  issuer: string;
  sourceUrl?: string | null;
  coverage: string;
  body?: string;
  issuedAt: string;
  expiresAt?: string | null;
  affectedZoneIds?: string[];
  affectedSegmentIds?: string[];
  actionsNote?: string;
  isSample?: boolean;
}

export function createAdvisory(ctx: Ctx, actor: User, eventId: string, input: AdvisoryInput) {
  const s = ctx.store;
  const zones = new Set(s.zones(eventId).map((z) => z.id));
  const segs = new Set(s.segments(eventId).map((x) => x.id));
  for (const z of input.affectedZoneIds ?? []) if (!zones.has(z)) throw new HttpError(400, `Unknown zone ${z}.`);
  for (const x of input.affectedSegmentIds ?? []) if (!segs.has(x)) throw new HttpError(400, `Unknown route segment ${x}.`);
  if (input.expiresAt && input.expiresAt <= input.issuedAt) throw new HttpError(400, 'Expiry must be after the issue time.');
  const id = newId('adv');
  s.tx(() => {
    s.insert('advisories', {
      id,
      event_id: eventId,
      title: input.title,
      issuer: input.issuer,
      source_url: input.sourceUrl || null,
      coverage: input.coverage,
      body: input.body ?? '',
      issued_at: input.issuedAt,
      expires_at: input.expiresAt || null,
      verification: 'unverified',
      is_sample: !!input.isSample,
      affected_zone_ids: input.affectedZoneIds ?? [],
      affected_segment_ids: input.affectedSegmentIds ?? [],
      actions_note: input.actionsNote ?? '',
      created_by: actor.id,
      created_at: iso(ctx),
    });
    audit(ctx, actor, eventId, 'advisory.created', 'advisory', id, { title: input.title, issuer: input.issuer, isSample: !!input.isSample, sourceUrl: input.sourceUrl ?? null });
  });
  ctx.bus.emit(eventId, 'advisory');
  return s.advisories(eventId).find((a) => a.id === id)!;
}

/**
 * Verify or reject an advisory. Verifying marks affected open route segments "under review" —
 * it never closes roads, redirects traffic or issues public instructions.
 */
export function setAdvisoryVerification(ctx: Ctx, actor: User, advisoryId: string, verification: AdvisoryVerification, note: string) {
  const s = ctx.store;
  const row = s.get('SELECT * FROM advisories WHERE id = ?', advisoryId);
  if (!row) throw new HttpError(404, 'Advisory not found.');
  if (row.verification === verification) throw new HttpError(409, `Advisory is already ${verification}.`);
  if (verification === 'rejected' && !note.trim()) throw new HttpError(400, 'A reason is required to reject an advisory.');
  const marked: string[] = [];
  s.tx(() => {
    s.update('advisories', advisoryId, { verification, verified_by: actor.id, verified_at: iso(ctx) });
    audit(ctx, actor, row.event_id, `advisory.${verification}`, 'advisory', advisoryId, { title: row.title, note });
    if (verification === 'verified') {
      for (const segId of JSON.parse(row.affected_segment_ids) as string[]) {
        const seg = s.get('SELECT status FROM route_segments WHERE id = ?', segId);
        if (seg?.status === 'open') {
          setSegmentStatus(ctx, actor, segId, { status: 'under_review', reason: `Advisory: ${row.title}`, source: row.issuer, advisoryId });
          marked.push(segId);
        }
      }
    }
  });
  ctx.bus.emit(row.event_id, 'advisory');
  return { advisory: s.advisories(row.event_id).find((a) => a.id === advisoryId)!, segmentsMarkedForReview: marked };
}

// ---------------- Occupancy ----------------

export function reportOccupancy(ctx: Ctx, actor: User, zoneId: string, value: number, source: string, observedAt?: string | null, clientId?: string | null) {
  const s = ctx.store;
  if (clientId) {
    const existing = s.get('SELECT * FROM occupancy_observations WHERE id = ?', `occ-${clientId}`);
    if (existing) {
      if (existing.reported_by !== actor.id) throw new HttpError(409, 'This submission ID is already in use.');
      return { id: existing.id, zoneId, value: existing.value, observedAt: existing.observed_at, source: existing.source, receivedAt: ctx.now().toISOString(), duplicateSubmission: true };
    }
  }
  const z = s.get('SELECT * FROM zones WHERE id = ?', zoneId);
  if (!z) throw new HttpError(404, 'Zone not found.');
  if (!Number.isInteger(value) || value < 0) throw new HttpError(400, 'Occupancy must be a whole number of people, zero or more.');
  if (z.capacity && value > z.capacity * 5) throw new HttpError(400, 'Estimate is implausibly high for the configured capacity; please re-check.');
  const now = ctx.now();
  const at = observedAt ? new Date(observedAt) : now;
  if (Number.isNaN(at.getTime()) || at.getTime() > now.getTime() + 5 * 60_000) throw new HttpError(400, 'Invalid observation time.');
  const id = clientId ? `occ-${clientId}` : newId('occ');
  s.tx(() => {
    s.insert('occupancy_observations', { id, event_id: z.event_id, zone_id: zoneId, value, observed_at: at.toISOString(), source, reported_by: actor.id });
    audit(ctx, actor, z.event_id, 'occupancy.reported', 'zone', zoneId, { value, source });
  });
  ctx.bus.emit(z.event_id, 'occupancy');
  return { id, zoneId, value, observedAt: at.toISOString(), source, receivedAt: now.toISOString(), duplicateSubmission: false };
}

// ---------------- Checklist ----------------

export function updateChecklist(ctx: Ctx, actor: User, itemId: string, status: ChecklistStatus, note: string, zoneId?: string | null) {
  const s = ctx.store;
  const row = s.get('SELECT * FROM checklist_items WHERE id = ?', itemId);
  if (!row) throw new HttpError(404, 'Checklist item not found.');
  if (status === 'mitigation_verified' && !can(actor.role, 'checklist.verifyMitigation')) {
    throw new HttpError(403, 'Only an administrator (event safety lead) can record a mitigation as verified.');
  }
  if ((status === 'issue_identified' || status === 'mitigation_planned' || status === 'mitigation_verified') && !note.trim()) {
    throw new HttpError(400, 'Describe the issue or mitigation.');
  }
  s.tx(() => {
    s.update('checklist_items', itemId, { status, note, zone_id: zoneId === undefined ? row.zone_id : zoneId, updated_by: actor.id, updated_at: iso(ctx) });
    audit(ctx, actor, row.event_id, 'checklist.updated', 'checklist_item', itemId, { label: row.label, from: row.status, to: status, note });
  });
  ctx.bus.emit(row.event_id, 'config');
}
