import { audit, HttpError, iso, type Ctx } from '../context';
import { newId } from '../db';
import { findRoute, validateNamedRoutes } from '../../shared/routing';
import { haversineM } from '../../shared/geo';
import type { AccessLevel, FacilityStatus, RouteNode, SegmentStatus, TravelMode, User } from '../../shared/types';

export function setSegmentStatus(
  ctx: Ctx,
  actor: User,
  segmentId: string,
  input: { status: SegmentStatus; reason: string; source: string; advisoryId?: string | null },
) {
  const seg = ctx.store.get('SELECT * FROM route_segments WHERE id = ?', segmentId);
  if (!seg) throw new HttpError(404, 'Route segment not found.');
  if (seg.status === input.status) throw new HttpError(409, `Segment is already ${input.status.replace('_', ' ')}.`);
  if (input.status !== 'open' && !input.reason.trim()) throw new HttpError(400, 'A reason is required to close a segment or mark it for review.');
  const at = iso(ctx);
  ctx.store.tx(() => {
    ctx.store.update('route_segments', segmentId, {
      status: input.status,
      status_reason: input.status === 'open' ? null : input.reason,
      status_source: input.source,
      status_updated_at: at,
    });
    // Close out any open closure record, then open a new one for non-open states.
    ctx.store.run('UPDATE route_closures SET lifted_at = ?, lifted_by = ? WHERE segment_id = ? AND lifted_at IS NULL', at, actor.id, segmentId);
    if (input.status !== 'open') {
      ctx.store.insert('route_closures', {
        id: newId('clo'),
        event_id: seg.event_id,
        segment_id: segmentId,
        status: input.status,
        reason: input.reason,
        source: input.source,
        advisory_id: input.advisoryId ?? null,
        created_by: actor.id,
        created_at: at,
      });
    }
    audit(ctx, actor, seg.event_id, `segment.${input.status}`, 'route_segment', segmentId, {
      name: seg.name,
      from: seg.status,
      to: input.status,
      reason: input.reason,
      source: input.source,
    });
  });
  ctx.bus.emit(seg.event_id, 'network');
  // Report which approved routes are now affected so the caller can surface them.
  const affected = namedRouteValidity(ctx, seg.event_id).filter((v) => v.blockedSegments.some((b) => b.id === segmentId) || v.reviewSegments.some((b) => b.id === segmentId));
  return { segmentId, status: input.status, affectedRoutes: affected };
}

export function setFacilityStatus(ctx: Ctx, actor: User, facilityId: string, input: { status: FacilityStatus; reason: string }) {
  const fac = ctx.store.get('SELECT * FROM facilities WHERE id = ?', facilityId);
  if (!fac) throw new HttpError(404, 'Facility not found.');
  if (fac.status === input.status) throw new HttpError(409, `${fac.name} is already ${input.status}.`);
  if (input.status === 'closed' && !input.reason.trim()) throw new HttpError(400, 'A reason is required to mark a facility unavailable.');
  ctx.store.tx(() => {
    ctx.store.update('facilities', facilityId, { status: input.status, status_reason: input.status === 'closed' ? input.reason : null, status_updated_at: iso(ctx) });
    audit(ctx, actor, fac.event_id, `facility.${input.status}`, 'facility', facilityId, { name: fac.name, kind: fac.kind, reason: input.reason });
  });
  ctx.bus.emit(fac.event_id, 'network');
  return { facilityId, status: input.status };
}

export function namedRouteValidity(ctx: Ctx, eventId: string) {
  return validateNamedRoutes(ctx.store.nodes(eventId), ctx.store.segments(eventId), ctx.store.namedRoutes(eventId), ctx.now());
}

export function computeRoute(ctx: Ctx, eventId: string, req: { from: string; to: string; mode: TravelMode; access: AccessLevel; avoidUnderReview?: boolean }) {
  return findRoute(ctx.store.nodes(eventId), ctx.store.segments(eventId), req, ctx.now());
}

export function nearestNode(nodes: RouteNode[], lat: number, lng: number): RouteNode | null {
  let best: RouteNode | null = null;
  let bestD = Infinity;
  for (const n of nodes) {
    const d = haversineM([lat, lng], [n.lat, n.lng]);
    if (d < bestD) {
      bestD = d;
      best = n;
    }
  }
  return best;
}
