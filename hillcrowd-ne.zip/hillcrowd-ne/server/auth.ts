import { randomBytes, scryptSync, timingSafeEqual, createHash } from 'node:crypto';
import type { Ctx } from './context';
import type { User } from '../shared/types';

const SCRYPT_N = 16384;

export function hashPassword(password: string): string {
  const salt = randomBytes(16);
  const hash = scryptSync(password, salt, 64, { N: SCRYPT_N });
  return `scrypt$${SCRYPT_N}$${salt.toString('base64')}$${hash.toString('base64')}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [scheme, n, saltB64, hashB64] = stored.split('$');
  if (scheme !== 'scrypt' || !saltB64 || !hashB64) return false;
  const expected = Buffer.from(hashB64, 'base64');
  const actual = scryptSync(password, Buffer.from(saltB64, 'base64'), expected.length, { N: Number(n) });
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

const tokenHash = (t: string) => createHash('sha256').update(t).digest('hex');

export function createSession(ctx: Ctx, userId: string, hours: number): string {
  const token = randomBytes(32).toString('base64url');
  const now = ctx.now();
  ctx.store.insert('sessions', {
    token_hash: tokenHash(token),
    user_id: userId,
    created_at: now.toISOString(),
    expires_at: new Date(now.getTime() + hours * 3600_000).toISOString(),
  });
  return token;
}

export function userForToken(ctx: Ctx, token: string | undefined): User | null {
  if (!token) return null;
  const row = ctx.store.get<{ user_id: string; expires_at: string }>('SELECT user_id, expires_at FROM sessions WHERE token_hash = ?', tokenHash(token));
  if (!row || row.expires_at < ctx.now().toISOString()) return null;
  return ctx.store.userById(row.user_id);
}

export function destroySession(ctx: Ctx, token: string | undefined) {
  if (token) ctx.store.run('DELETE FROM sessions WHERE token_hash = ?', tokenHash(token));
}

export function login(ctx: Ctx, username: string, password: string): User | null {
  const row = ctx.store.get<{ id: string; password_hash: string }>('SELECT id, password_hash FROM users WHERE username = ? AND active = 1', username.trim().toLowerCase());
  if (!row) {
    // Equalise timing for unknown users.
    verifyPassword(password, 'scrypt$16384$AAAAAAAAAAAAAAAAAAAAAA==$' + Buffer.alloc(64).toString('base64'));
    return null;
  }
  return verifyPassword(password, row.password_hash) ? ctx.store.userById(row.id) : null;
}
