import { createApp } from './app';
import { Store } from './db';
import { Bus, type Ctx } from './context';
import { seedBase, seedDemoEvent } from './services/demo';
import { runEscalations } from './services/assignments';
import { refreshRisk } from './services/risk';

const env = process.env;
const port = Number(env.PORT ?? 4000);
const ctx: Ctx = {
  store: new Store(env.DB_PATH ?? 'data/hillcrowd.db'),
  now: () => new Date(),
  bus: new Bus(),
  demoMode: (env.DEMO_MODE ?? 'true') !== 'false',
};

seedBase(ctx);
if (ctx.demoMode) seedDemoEvent(ctx);

const app = createApp(ctx, { sessionHours: Number(env.SESSION_HOURS ?? 12), cookieSecure: env.COOKIE_SECURE === 'true' });

// Periodic housekeeping: escalations, time-based risk changes (staleness), expired sessions.
setInterval(() => {
  try {
    for (const { id } of ctx.store.all<{ id: string }>('SELECT id FROM events')) {
      runEscalations(ctx, id);
      refreshRisk(ctx, id);
    }
    ctx.store.run('DELETE FROM sessions WHERE expires_at < ?', new Date().toISOString());
  } catch (e) {
    console.error('Housekeeping failed', e);
  }
}, 15_000).unref();

app.listen(port, () => {
  console.log(`HillCrowd NE API listening on http://localhost:${port}  (demo mode: ${ctx.demoMode ? 'ON' : 'off'})`);
});
