import express, { type NextFunction, type Request, type Response } from 'express';
import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { z, ZodError } from 'zod';
import { HttpError, type Ctx } from './context';
import { createSession, destroySession, login, userForToken } from './auth';
import { can, type Permission } from '../shared/permissions';
import { CATEGORIES, EVENT_TYPES, NE_STATES, SEVERITIES } from '../shared/constants';
import { isValidLatLng } from '../shared/geo';
import type { User } from '../shared/types';
import { addIncidentNote, createIncident, getIncidentOr404, mergeIncident, setConfirmedSeverity, transitionIncident, updateAction } from './services/incidents';
import { createAssignment, updateAssignment } from './services/assignments';
import { computeRoute, setFacilityStatus, setSegmentStatus } from './services/network';
import { createAdvisory, reportOccupancy, setAdvisoryVerification, updateChecklist } from './services/operations';
import { buildSnapshot } from './services/snapshot';
import { analyticsCsv, computeAnalytics } from './services/analytics';
import { refreshRisk } from './services/risk';
import { INJECTIONS, injectEvent, resetDemo, runScenarioStep, scenarioState, setResponderAvailability } from './services/demo';
import { recordStressTest, simulate } from './services/resilience';
import { DEMO_PASSWORD, DEMO_USERS } from './seed/demoData';
import * as config from './services/config';
import { Store } from './db';

declare module 'express-serve-static-core' {
  interface Request {
    user?: User;
  }
}

const COOKIE = 'hc_session';

// ---------------- validation schemas ----------------
const latLng = z.tuple([z.number().min(-90).max(90), z.number().min(-180).max(180)]);
const isoDate = z.string().refine((v) => !Number.isNaN(Date.parse(v)), 'Invalid date/time').transform((v) => new Date(v).toISOString());
const category = z.enum(CATEGORIES.map((c) => c.key) as [string, ...string[]]);
const severity = z.enum(SEVERITIES as [string, ...string[]]);
const mode = z.enum(['foot', 'vehicle']);
const access = z.enum(['public', 'staff', 'emergency']);
const role = z.enum(['admin', 'coordinator', 'steward', 'responder']);
const shortText = (max = 200) => z.string().trim().max(max);
const mins = z.number().int().min(1).max(600);
const stageTargets = z.object({ verify: mins, assign: mins, accept: mins, arrive: mins, resolve: mins, confirm: mins });
const scenario = z.object({
  closedSegments: z.array(z.string().max(80)).max(200).default([]),
  closedFacilities: z.array(z.string().max(80)).max(200).default([]),
  weatherExposedClosed: z.boolean().optional(),
  unavailableResponders: z.array(z.string().max(80)).max(100).optional(),
  commsLostZones: z.array(z.string().max(80)).max(100).optional(),
});

const S = {
  login: z.object({ username: z.string().trim().min(1).max(64), password: z.string().min(1).max(200) }),
  incident: z
    .object({
      clientId: z.string().trim().min(8).max(80).regex(/^[A-Za-z0-9_-]+$/).nullish(),
      category,
      zoneId: z.string().max(80).nullish(),
      lat: z.number().nullish(),
      lng: z.number().nullish(),
      description: z.string().trim().min(3, 'Add a short description').max(1000),
      severityEstimate: severity,
      urgent: z.boolean().optional(),
      createdLocalAt: isoDate.nullish(),
      attachmentNote: shortText(300).nullish(),
    })
    .superRefine((v, c) => {
      if ((v.lat == null) !== (v.lng == null)) c.addIssue({ code: 'custom', message: 'Latitude and longitude must be given together.' });
      if (v.lat != null && !isValidLatLng(v.lat, v.lng)) c.addIssue({ code: 'custom', message: 'Invalid coordinates.' });
      if (!v.zoneId && v.lat == null) c.addIssue({ code: 'custom', message: 'Select a venue zone or a map location.' });
    }),
  transition: z.object({
    to: z.enum(['under_review', 'verified', 'rejected', 'resolved', 'closed', 'in_progress']),
    note: shortText(1000).default(''),
    confirmedSeverity: severity.nullish(),
  }),
  severity: z.object({ severity, note: shortText(500).default('') }),
  note: z.object({ note: z.string().trim().min(1).max(1000) }),
  merge: z.object({ intoId: z.string().min(1).max(80), note: shortText(500).default('') }),
  assign: z.object({ responderId: z.string().min(1).max(80), note: shortText(500).default('') }),
  assignmentStatus: z.object({ status: z.enum(['acknowledged', 'en_route', 'on_scene', 'resolved', 'declined', 'unable', 'cancelled']), note: shortText(1000).default('') }),
  action: z.object({ status: z.enum(['pending', 'done', 'skipped', 'overridden']), note: shortText(1000).default('') }),
  occupancy: z.object({ clientId: z.string().trim().min(8).max(80).regex(/^[A-Za-z0-9_-]+$/).nullish(), zoneId: z.string().min(1), value: z.number().int().min(0).max(1_000_000), source: shortText(120).min(3), observedAt: isoDate.nullish() }),
  route: z.object({ from: z.string().min(1), to: z.string().min(1), mode, access, avoidUnderReview: z.boolean().optional() }),
  segmentStatus: z.object({ status: z.enum(['open', 'under_review', 'closed']), reason: shortText(500).default(''), source: shortText(200).min(2), advisoryId: z.string().nullish() }),
  facilityStatus: z.object({ status: z.enum(['open', 'closed']), reason: shortText(500).default('') }),
  advisory: z.object({
    title: shortText(200).min(3),
    issuer: shortText(200).min(2),
    sourceUrl: z.string().trim().url().max(500).refine((u) => /^https?:\/\//.test(u), 'Use an http(s) URL').nullish().or(z.literal('')),
    coverage: shortText(300).min(2),
    body: shortText(4000).default(''),
    issuedAt: isoDate,
    expiresAt: isoDate.nullish().or(z.literal('')),
    affectedZoneIds: z.array(z.string()).max(50).default([]),
    affectedSegmentIds: z.array(z.string()).max(200).default([]),
    actionsNote: shortText(1000).default(''),
    isSample: z.boolean().default(false),
  }),
  advisoryVerify: z.object({ verification: z.enum(['verified', 'rejected', 'unverified']), note: shortText(500).default('') }),
  checklist: z.object({ status: z.enum(['not_assessed', 'no_issue', 'issue_identified', 'mitigation_planned', 'mitigation_verified']), note: shortText(1000).default(''), zoneId: z.string().nullish() }),
  event: z.object({
    name: shortText(160).min(3),
    eventType: z.enum(EVENT_TYPES as [string, ...string[]]),
    state: z.enum(NE_STATES as [string, ...string[]]),
    district: shortText(80).min(2),
    locationLabel: shortText(200).default(''),
    venueName: shortText(200).min(2),
    venueIsFictional: z.boolean(),
    startsAt: isoDate,
    endsAt: isoDate,
    expectedAttendance: z.number().int().min(0).max(5_000_000).nullable(),
    venueCapacity: z.number().int().min(0).max(5_000_000).nullable(),
    controlContact: shortText(200).default(''),
    centerLat: z.number().min(-90).max(90),
    centerLng: z.number().min(-180).max(180),
    zoom: z.number().int().min(3).max(19).default(16),
  }),
  settings: z
    .object({
      staleMinutes: z.number().int().min(1).max(240),
      duplicateWindowMinutes: z.number().int().min(1).max(240),
      duplicateRadiusM: z.number().int().min(5).max(2000),
      corroborationWindowMinutes: z.number().int().min(1).max(240),
      corroborationMinReporters: z.number().int().min(2).max(20),
      responseTargets: z.record(severity, stageTargets),
      categoryTargets: z.record(category, stageTargets.partial()),
      missingOccupancyLevel: z.enum(['normal', 'watch', 'elevated']),
      requireResolutionVerification: z.boolean(),
    })
    .partial(),
  zone: z.object({
    name: shortText(120).min(2),
    polygon: z.array(latLng).min(3).max(200),
    capacity: z.number().int().min(1).max(5_000_000).nullable(),
    watchPct: z.number().min(1).max(500),
    elevatedPct: z.number().min(1).max(500),
    criticalPct: z.number().min(1).max(500).nullable(),
    requiredExitIds: z.array(z.string()).default([]),
    exitIds: z.array(z.string()).default([]),
    notes: shortText(1000).default(''),
    commsFallback: shortText(200).default(''),
  }),
  facility: z.object({
    kind: z.enum(['gate', 'exit', 'medical', 'assembly', 'control', 'handover']),
    name: shortText(120).min(2),
    lat: z.number().min(-90).max(90),
    lng: z.number().min(-180).max(180),
    zoneId: z.string().nullable().default(null),
    capacityPerMin: z.number().int().min(0).max(100000).nullable().default(null),
    notes: shortText(500).default(''),
  }),
  facilityPatch: z.object({ name: shortText(120).min(2), zoneId: z.string().nullable(), capacityPerMin: z.number().int().min(0).max(100000).nullable(), notes: shortText(500) }).partial(),
  node: z.object({ name: shortText(120).min(2), lat: z.number().min(-90).max(90), lng: z.number().min(-180).max(180) }),
  segment: z.object({
    name: shortText(160).min(2),
    fromNode: z.string().min(1),
    toNode: z.string().min(1),
    modes: z.array(mode).min(1),
    access,
    approved: z.boolean().default(true),
    constraintNote: shortText(300).default(''),
    terrainNote: shortText(300).default(''),
    weatherExposed: z.boolean().default(false),
    distanceM: z.number().min(0).max(1_000_000).nullish(),
  }),
  namedRoute: z.object({ name: shortText(160).min(2), purpose: shortText(300).default(''), mode, access, fromNode: z.string().min(1), toNode: z.string().min(1) }),
  location: z.object({ lat: z.number().min(-90).max(90), lng: z.number().min(-180).max(180) }),
  user: z.object({
    username: z.string().trim().min(3).max(40).regex(/^[a-z0-9._-]+$/i),
    displayName: shortText(80).min(2),
    role,
    password: z.string().min(10, 'Use at least 10 characters').max(200),
    eventIds: z.array(z.string()).default([]),
  }),
  userPatch: z.object({ role, active: z.boolean(), displayName: shortText(80).min(2), eventIds: z.array(z.string()) }).partial(),
  playbook: z.object({
    title: shortText(120).min(2),
    trigger: shortText(500),
    escalation: shortText(500),
    steps: z
      .array(z.object({ title: shortText(200).min(2), detail: shortText(1000).default(''), approval: z.enum(['coordinator', 'safety_authority', 'none']), action: z.string().max(40).optional(), dueMinutes: z.number().int().min(1).max(240).optional() }))
      .min(1)
      .max(30),
  }).partial(),
};

// ---------------- helpers ----------------
function parseCookies(header: string | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  for (const part of (header ?? '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

type Handler = (req: Request, res: Response) => unknown;
const wrap = (fn: Handler) => async (req: Request, res: Response, next: NextFunction) => {
  try {
    const out = await fn(req, res);
    if (!res.headersSent) res.json({ ok: true, data: out ?? null });
  } catch (e) {
    next(e);
  }
};

export function createApp(ctx: Ctx, opts: { sessionHours?: number; cookieSecure?: boolean; staticDir?: string } = {}) {
  const app = express();
  const sessionHours = opts.sessionHours ?? 12;
  app.disable('x-powered-by');
  app.set('trust proxy', false);
  app.use(express.json({ limit: '100kb' }));

  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'same-origin');
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(self)');
    next();
  });

  // Authentication from httpOnly session cookie.
  app.use('/api', (req, _res, next) => {
    const token = parseCookies(req.headers.cookie)[COOKIE];
    req.user = userForToken(ctx, token) ?? undefined;
    next();
  });

  // CSRF mitigation: state-changing requests must carry a custom header (forces a CORS preflight cross-site).
  app.use('/api', (req, _res, next) => {
    if (['POST', 'PATCH', 'PUT', 'DELETE'].includes(req.method) && req.get('x-hillcrowd-client') !== '1') {
      return next(new HttpError(403, 'Missing client header.'));
    }
    next();
  });

  const requireAuth = (req: Request): User => {
    if (!req.user) throw new HttpError(401, 'Please sign in.');
    return req.user;
  };
  const requirePerm = (req: Request, perm: Permission): User => {
    const u = requireAuth(req);
    if (!can(u.role, perm)) throw new HttpError(403, 'Your role is not permitted to perform this action.');
    return u;
  };
  const hasEventAccess = (u: User, eventId: string) => u.role === 'admin' || !!ctx.store.get('SELECT 1 FROM event_access WHERE user_id = ? AND event_id = ?', u.id, eventId);
  const requireEvent = (u: User, eventId: string) => {
    if (!ctx.store.event(eventId)) throw new HttpError(404, 'Event not found.');
    if (!hasEventAccess(u, eventId)) throw new HttpError(403, 'You do not have access to this event.');
  };
  const eventOf = (table: string, id: string) => {
    const row = ctx.store.get<{ event_id: string }>(`SELECT event_id FROM ${table} WHERE id = ?`, id);
    if (!row) throw new HttpError(404, 'Record not found.');
    return row.event_id;
  };
  const afterMutation = (eventId: string) => refreshRisk(ctx, eventId);

  // ---------------- public ----------------
  app.get('/api/health', wrap(() => ({ status: 'ok', time: ctx.now().toISOString(), demoMode: ctx.demoMode })));

  app.get('/api/demo/accounts', wrap(() => {
    if (!ctx.demoMode) return { enabled: false, accounts: [] };
    return { enabled: true, password: DEMO_PASSWORD, accounts: DEMO_USERS.map((u) => ({ username: u.username, displayName: u.displayName, role: u.role })) };
  }));

  // Simple in-memory login throttle.
  const failures = new Map<string, { n: number; until: number }>();
  app.post('/api/auth/login', wrap((req, res) => {
    const { username, password } = S.login.parse(req.body);
    const key = `${req.ip}|${username.toLowerCase()}`;
    const f = failures.get(key);
    if (f && f.n >= 5 && f.until > Date.now()) throw new HttpError(429, 'Too many failed attempts. Try again in a few minutes.');
    const user = login(ctx, username, password);
    if (!user) {
      failures.set(key, { n: (f?.n ?? 0) + 1, until: Date.now() + 5 * 60_000 });
      throw new HttpError(401, 'Incorrect username or password.');
    }
    failures.delete(key);
    const token = createSession(ctx, user.id, sessionHours);
    res.setHeader('Set-Cookie', `${COOKIE}=${token}; HttpOnly; Path=/; SameSite=Lax; Max-Age=${sessionHours * 3600}${opts.cookieSecure ? '; Secure' : ''}`);
    return { user };
  }));

  app.post('/api/auth/logout', wrap((req, res) => {
    destroySession(ctx, parseCookies(req.headers.cookie)[COOKIE]);
    res.setHeader('Set-Cookie', `${COOKIE}=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0`);
    return {};
  }));

  app.get('/api/auth/me', wrap((req) => {
    const u = requireAuth(req);
    const events = (u.role === 'admin'
      ? ctx.store.all('SELECT * FROM events ORDER BY is_demo DESC, starts_at DESC')
      : ctx.store.all('SELECT e.* FROM events e JOIN event_access a ON a.event_id = e.id WHERE a.user_id = ? ORDER BY e.is_demo DESC, e.starts_at DESC', u.id)
    ).map((r) => ({ id: r.id, name: r.name, state: r.state, district: r.district, isDemo: r.is_demo === 1, startsAt: r.starts_at }));
    return { user: u, events, demoMode: ctx.demoMode };
  }));

  // ---------------- events ----------------
  app.post('/api/events', wrap((req) => {
    const u = requirePerm(req, 'event.create');
    const body = S.event.extend({ template: z.enum(['blank', 'demo_layout']).default('blank') }).parse(req.body);
    return config.createEvent(ctx, u, body as any);
  }));

  app.patch('/api/events/:eventId', wrap((req) => {
    const u = requirePerm(req, 'event.configure');
    requireEvent(u, req.params.eventId);
    const body = S.event.partial().extend({ settings: S.settings.optional(), boundary: z.array(latLng).max(200).optional() }).parse(req.body);
    const ev = config.updateEvent(ctx, u, req.params.eventId, body as any);
    afterMutation(ev.id);
    return ev;
  }));

  app.get('/api/events/:eventId/snapshot', wrap((req) => {
    const u = requirePerm(req, 'event.view');
    requireEvent(u, req.params.eventId);
    return buildSnapshot(ctx, req.params.eventId, u);
  }));

  // ---------------- incidents ----------------
  app.post('/api/events/:eventId/incidents', wrap((req, res) => {
    const u = requirePerm(req, 'incident.create');
    requireEvent(u, req.params.eventId);
    const body = S.incident.parse(req.body);
    const out = createIncident(ctx, u, req.params.eventId, body as any);
    afterMutation(req.params.eventId);
    res.status(out.duplicateSubmission ? 200 : 201);
    return out;
  }));

  const canSeeIncident = (u: User, incidentId: string, reporterId: string) => {
    if (can(u.role, 'incident.viewAll')) return true;
    if (u.role === 'steward' && reporterId === u.id) return true;
    if (u.role === 'responder' || u.role === 'steward') {
      return !!ctx.store.get('SELECT 1 FROM assignments a JOIN responders r ON r.id = a.responder_id WHERE a.incident_id = ? AND r.user_id = ?', incidentId, u.id);
    }
    return false;
  };

  app.get('/api/incidents/:id', wrap((req) => {
    const u = requireAuth(req);
    const inc = getIncidentOr404(ctx, req.params.id);
    requireEvent(u, inc.eventId);
    if (!canSeeIncident(u, inc.id, inc.reporterId)) throw new HttpError(403, 'You do not have access to this incident.');
    const ops = can(u.role, 'incident.viewAll');
    const dupes = inc.possibleDuplicateOf.map((id) => ctx.store.incident(id)).filter(Boolean);
    const mergedChildren = ctx.store.all<{ id: string }>('SELECT id FROM incidents WHERE merged_into = ?', inc.id).map((r) => ctx.store.incident(r.id));
    const relatedDupes = ops ? ctx.store.incidents(inc.eventId).filter((i) => i.possibleDuplicateOf.includes(inc.id)) : [];
    return {
      incident: inc,
      history: ctx.store.incidentUpdates(inc.id),
      actions: ops ? ctx.store.actions(inc.id) : [],
      assignments: ctx.store.all('SELECT * FROM assignments WHERE incident_id = ? ORDER BY assigned_at', inc.id).map(Store.assignment),
      possibleDuplicates: ops ? [...dupes, ...relatedDupes] : [],
      mergedChildren: ops ? mergedChildren : [],
    };
  }));

  app.post('/api/incidents/:id/transition', wrap((req) => {
    const body = S.transition.parse(req.body);
    const perm: Permission = body.to === 'closed' ? 'incident.close' : body.to === 'under_review' ? 'incident.review' : 'incident.review';
    const u = requirePerm(req, perm);
    const inc = getIncidentOr404(ctx, req.params.id);
    requireEvent(u, inc.eventId);
    if (body.to === 'under_review' && ['resolved', 'closed', 'rejected'].includes(inc.status)) requirePerm(req, 'incident.reopen');
    const out = transitionIncident(ctx, u, inc.id, body.to, body.note, { confirmedSeverity: (body.confirmedSeverity as any) ?? null });
    afterMutation(inc.eventId);
    return out;
  }));

  app.post('/api/incidents/:id/severity', wrap((req) => {
    const u = requirePerm(req, 'incident.review');
    const body = S.severity.parse(req.body);
    const inc = getIncidentOr404(ctx, req.params.id);
    requireEvent(u, inc.eventId);
    const out = setConfirmedSeverity(ctx, u, inc.id, body.severity as any, body.note);
    afterMutation(inc.eventId);
    return out;
  }));

  app.post('/api/incidents/:id/notes', wrap((req) => {
    const u = requireAuth(req);
    const body = S.note.parse(req.body);
    const inc = getIncidentOr404(ctx, req.params.id);
    requireEvent(u, inc.eventId);
    if (!canSeeIncident(u, inc.id, inc.reporterId)) throw new HttpError(403, 'You do not have access to this incident.');
    addIncidentNote(ctx, u, inc.id, body.note);
    return {};
  }));

  app.post('/api/incidents/:id/merge', wrap((req) => {
    const u = requirePerm(req, 'incident.merge');
    const body = S.merge.parse(req.body);
    const inc = getIncidentOr404(ctx, req.params.id);
    requireEvent(u, inc.eventId);
    const out = mergeIncident(ctx, u, inc.id, body.intoId, body.note);
    afterMutation(inc.eventId);
    return out;
  }));

  app.post('/api/incidents/:id/assignments', wrap((req) => {
    const u = requirePerm(req, 'assignment.create');
    const body = S.assign.parse(req.body);
    const inc = getIncidentOr404(ctx, req.params.id);
    requireEvent(u, inc.eventId);
    const out = createAssignment(ctx, u, inc.id, body.responderId, body.note);
    afterMutation(inc.eventId);
    return out;
  }));

  app.post('/api/assignments/:id/status', wrap((req) => {
    const u = requireAuth(req);
    if (!can(u.role, 'assignment.updateOwn') && !can(u.role, 'assignment.recordOnBehalf')) throw new HttpError(403, 'Your role cannot update assignments.');
    const body = S.assignmentStatus.parse(req.body);
    const eventId = eventOf('assignments', req.params.id);
    requireEvent(u, eventId);
    const out = updateAssignment(ctx, u, req.params.id, body.status as any, body.note);
    afterMutation(eventId);
    return out;
  }));

  app.post('/api/actions/:id', wrap((req) => {
    const u = requirePerm(req, 'incident.playbook');
    const body = S.action.parse(req.body);
    const eventId = eventOf('incident_actions', req.params.id);
    requireEvent(u, eventId);
    updateAction(ctx, u, req.params.id, body.status as any, body.note);
    return {};
  }));

  // ---------------- occupancy / routes / facilities ----------------
  app.post('/api/events/:eventId/occupancy', wrap((req) => {
    const u = requirePerm(req, 'occupancy.report');
    requireEvent(u, req.params.eventId);
    const body = S.occupancy.parse(req.body);
    if (eventOf('zones', body.zoneId) !== req.params.eventId) throw new HttpError(400, 'Zone does not belong to this event.');
    const out = reportOccupancy(ctx, u, body.zoneId, body.value, body.source, body.observedAt, body.clientId);
    afterMutation(req.params.eventId);
    return out;
  }));

  app.post('/api/events/:eventId/routes/compute', wrap((req) => {
    const u = requirePerm(req, 'route.compute');
    requireEvent(u, req.params.eventId);
    return computeRoute(ctx, req.params.eventId, S.route.parse(req.body) as any);
  }));

  app.post('/api/segments/:id/status', wrap((req) => {
    const u = requirePerm(req, 'route.setStatus');
    const body = S.segmentStatus.parse(req.body);
    const eventId = eventOf('route_segments', req.params.id);
    requireEvent(u, eventId);
    const out = setSegmentStatus(ctx, u, req.params.id, body as any);
    afterMutation(eventId);
    return out;
  }));

  app.patch('/api/segments/:id', wrap((req) => {
    const u = requirePerm(req, 'route.configure');
    const eventId = eventOf('route_segments', req.params.id);
    requireEvent(u, eventId);
    config.updateSegment(ctx, u, req.params.id, S.segment.omit({ fromNode: true, toNode: true }).partial().parse(req.body) as any);
    afterMutation(eventId);
    return {};
  }));

  app.post('/api/events/:eventId/segments', wrap((req) => {
    const u = requirePerm(req, 'route.configure');
    requireEvent(u, req.params.eventId);
    const id = config.createSegment(ctx, u, req.params.eventId, S.segment.parse(req.body) as any);
    afterMutation(req.params.eventId);
    return { id };
  }));

  app.post('/api/events/:eventId/nodes', wrap((req) => {
    const u = requirePerm(req, 'route.configure');
    requireEvent(u, req.params.eventId);
    return { id: config.createNode(ctx, u, req.params.eventId, S.node.parse(req.body)) };
  }));

  app.post('/api/events/:eventId/named-routes', wrap((req) => {
    const u = requirePerm(req, 'route.configure');
    requireEvent(u, req.params.eventId);
    return { id: config.createNamedRoute(ctx, u, req.params.eventId, S.namedRoute.parse(req.body) as any) };
  }));

  app.post('/api/facilities/:id/status', wrap((req) => {
    const u = requirePerm(req, 'facility.setStatus');
    const body = S.facilityStatus.parse(req.body);
    const eventId = eventOf('facilities', req.params.id);
    requireEvent(u, eventId);
    const out = setFacilityStatus(ctx, u, req.params.id, body as any);
    afterMutation(eventId);
    return out;
  }));

  app.patch('/api/facilities/:id', wrap((req) => {
    const u = requirePerm(req, 'facility.configure');
    const eventId = eventOf('facilities', req.params.id);
    requireEvent(u, eventId);
    config.updateFacility(ctx, u, req.params.id, S.facilityPatch.parse(req.body));
    afterMutation(eventId);
    return {};
  }));

  app.post('/api/events/:eventId/facilities', wrap((req) => {
    const u = requirePerm(req, 'facility.configure');
    requireEvent(u, req.params.eventId);
    const id = config.createFacility(ctx, u, req.params.eventId, S.facility.parse(req.body) as any);
    afterMutation(req.params.eventId);
    return { id };
  }));

  app.post('/api/events/:eventId/zones', wrap((req) => {
    const u = requirePerm(req, 'zone.configure');
    requireEvent(u, req.params.eventId);
    const id = config.createZone(ctx, u, req.params.eventId, S.zone.parse(req.body) as any);
    afterMutation(req.params.eventId);
    return { id };
  }));

  app.patch('/api/zones/:id', wrap((req) => {
    const u = requirePerm(req, 'zone.configure');
    const eventId = eventOf('zones', req.params.id);
    requireEvent(u, eventId);
    config.updateZone(ctx, u, req.params.id, S.zone.partial().parse(req.body) as any);
    afterMutation(eventId);
    return {};
  }));

  app.patch('/api/responders/:id/location', wrap((req) => {
    const u = requirePerm(req, 'assignment.create');
    const eventId = eventOf('responders', req.params.id);
    requireEvent(u, eventId);
    const b = S.location.parse(req.body);
    config.setResponderLocation(ctx, u, req.params.id, b.lat, b.lng);
    return {};
  }));

  // ---------------- resilience & stress tests ----------------
  app.post('/api/events/:eventId/resilience/simulate', wrap((req) => {
    const u = requirePerm(req, 'event.viewOps');
    requireEvent(u, req.params.eventId);
    return simulate(ctx, req.params.eventId, scenario.parse(req.body?.scenario ?? {}));
  }));

  app.post('/api/events/:eventId/stress-tests', wrap((req) => {
    const u = requirePerm(req, 'checklist.update');
    requireEvent(u, req.params.eventId);
    const b = z.object({ name: shortText(160).min(3), scenario }).parse(req.body);
    return recordStressTest(ctx, u, req.params.eventId, b.name, b.scenario);
  }));

  app.post('/api/responders/:id/availability', wrap((req) => {
    const u = requirePerm(req, 'assignment.create');
    const eventId = eventOf('responders', req.params.id);
    requireEvent(u, eventId);
    const b = z.object({ available: z.boolean(), reason: shortText(300) }).parse(req.body);
    setResponderAvailability(ctx, u, req.params.id, b.available, b.reason);
    afterMutation(eventId);
    return {};
  }));

  // ---------------- advisories / checklist / playbooks ----------------
  app.post('/api/events/:eventId/advisories', wrap((req) => {
    const u = requirePerm(req, 'advisory.create');
    requireEvent(u, req.params.eventId);
    const b = S.advisory.parse(req.body);
    const out = createAdvisory(ctx, u, req.params.eventId, { ...b, sourceUrl: b.sourceUrl || null, expiresAt: b.expiresAt || null });
    afterMutation(req.params.eventId);
    return out;
  }));

  app.post('/api/advisories/:id/verification', wrap((req) => {
    const u = requirePerm(req, 'advisory.verify');
    const eventId = eventOf('advisories', req.params.id);
    requireEvent(u, eventId);
    const b = S.advisoryVerify.parse(req.body);
    const out = setAdvisoryVerification(ctx, u, req.params.id, b.verification as any, b.note);
    afterMutation(eventId);
    return out;
  }));

  app.patch('/api/checklist/:id', wrap((req) => {
    const u = requirePerm(req, 'checklist.update');
    const eventId = eventOf('checklist_items', req.params.id);
    requireEvent(u, eventId);
    const b = S.checklist.parse(req.body);
    updateChecklist(ctx, u, req.params.id, b.status as any, b.note, b.zoneId);
    afterMutation(eventId);
    return {};
  }));

  app.patch('/api/playbooks/:id', wrap((req) => {
    const u = requirePerm(req, 'playbook.configure');
    config.updatePlaybook(ctx, u, req.params.id, S.playbook.parse(req.body) as any);
    return {};
  }));

  // ---------------- users ----------------
  app.get('/api/users', wrap((req) => {
    requirePerm(req, 'users.manage');
    return config.listUsers(ctx);
  }));
  app.post('/api/users', wrap((req) => {
    const u = requirePerm(req, 'users.manage');
    return { id: config.createUser(ctx, u, S.user.parse(req.body) as any) };
  }));
  app.patch('/api/users/:id', wrap((req) => {
    const u = requirePerm(req, 'users.manage');
    config.updateUser(ctx, u, req.params.id, S.userPatch.parse(req.body) as any);
    return {};
  }));

  // ---------------- audit / analytics ----------------
  app.get('/api/events/:eventId/audit', wrap((req) => {
    const u = requirePerm(req, 'audit.view');
    requireEvent(u, req.params.eventId);
    const limit = Math.min(500, Math.max(1, Number(req.query.limit ?? 200)));
    const includeGlobal = u.role === 'admin' && req.query.global === '1';
    const rows = includeGlobal
      ? ctx.store.all('SELECT * FROM audit_log WHERE event_id = ? OR event_id IS NULL ORDER BY id DESC LIMIT ?', req.params.eventId, limit)
      : ctx.store.all('SELECT * FROM audit_log WHERE event_id = ? ORDER BY id DESC LIMIT ?', req.params.eventId, limit);
    return rows.map((r) => ({ id: r.id, at: r.at, actorName: r.actor_name, actorRole: r.actor_role, action: r.action, entityType: r.entity_type, entityId: r.entity_id, details: JSON.parse(r.details) }));
  }));

  const analyticsFilter = (q: Request['query']) =>
    z.object({ from: isoDate.optional(), to: isoDate.optional(), category: category.optional(), status: z.string().max(30).optional() }).parse({
      from: q.from || undefined,
      to: q.to || undefined,
      category: q.category || undefined,
      status: q.status || undefined,
    });

  app.get('/api/events/:eventId/analytics', wrap((req) => {
    const u = requirePerm(req, 'analytics.view');
    requireEvent(u, req.params.eventId);
    return computeAnalytics(ctx, req.params.eventId, analyticsFilter(req.query) as any);
  }));

  app.get('/api/events/:eventId/analytics.csv', (req, res, next) => {
    try {
      const u = requirePerm(req, 'analytics.view');
      requireEvent(u, req.params.eventId);
      const csv = analyticsCsv(ctx, req.params.eventId, analyticsFilter(req.query) as any);
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="hillcrowd-report-${req.params.eventId}.csv"`);
      res.send('﻿' + csv);
    } catch (e) {
      next(e);
    }
  });

  // ---------------- demo ----------------
  app.get('/api/demo/scenario', wrap((req) => {
    requirePerm(req, 'demo.control');
    if (!ctx.demoMode) throw new HttpError(404, 'Demo mode is disabled.');
    return scenarioState(ctx);
  }));
  app.post('/api/demo/scenario/:step', wrap((req) => {
    requirePerm(req, 'demo.control');
    return runScenarioStep(ctx, req.params.step);
  }));
  app.get('/api/demo/injections', wrap((req) => {
    requirePerm(req, 'demo.control');
    if (!ctx.demoMode) throw new HttpError(404, 'Demo mode is disabled.');
    return INJECTIONS;
  }));
  app.post('/api/demo/inject/:key', wrap((req) => {
    const u = requirePerm(req, 'demo.control');
    return injectEvent(ctx, u, req.params.key);
  }));
  app.post('/api/demo/reset', wrap((req) => {
    const u = requirePerm(req, 'demo.control');
    resetDemo(ctx, u);
    return scenarioState(ctx);
  }));

  // ---------------- live updates (SSE) ----------------
  app.get('/api/stream', (req, res) => {
    const u = req.user;
    const eventId = String(req.query.eventId ?? '');
    if (!u) return res.status(401).end();
    if (!ctx.store.event(eventId) || !hasEventAccess(u, eventId)) return res.status(403).end();
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
    res.write(`event: hello\ndata: ${JSON.stringify({ at: ctx.now().toISOString() })}\n\n`);
    let pending: NodeJS.Timeout | null = null;
    const off = ctx.bus.on((evId, kind) => {
      if (evId !== eventId || pending) return;
      // Coalesce bursts of changes into one refresh signal.
      pending = setTimeout(() => {
        pending = null;
        res.write(`event: change\ndata: ${JSON.stringify({ kind, at: ctx.now().toISOString() })}\n\n`);
      }, 150);
    });
    const ping = setInterval(() => res.write(`: ping\n\n`), 20_000);
    req.on('close', () => {
      off();
      clearInterval(ping);
      if (pending) clearTimeout(pending);
    });
  });

  app.use('/api', (_req, _res, next) => next(new HttpError(404, 'API route not found.')));

  // ---------------- static client ----------------
  const staticDir = opts.staticDir ?? resolve('dist/client');
  if (existsSync(staticDir)) {
    app.use((_req, res, next) => {
      res.setHeader(
        'Content-Security-Policy',
        "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https://tile.openstreetmap.org https://*.tile.openstreetmap.org https://*.tile.opentopomap.org; connect-src 'self'; font-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'",
      );
      next();
    });
    app.use(express.static(staticDir, { index: false, maxAge: '1h', setHeaders: (res, p) => p.endsWith('sw.js') && res.setHeader('Cache-Control', 'no-cache') }));
    app.get('*', (_req, res) => res.sendFile(resolve(staticDir, 'index.html')));
  }

  // ---------------- errors ----------------
  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    if (err instanceof ZodError) {
      return res.status(400).json({ ok: false, error: { message: err.issues.map((i) => (i.path.length ? `${i.path.join('.')}: ${i.message}` : i.message)).join('; '), details: err.issues } });
    }
    if (err instanceof HttpError) return res.status(err.status).json({ ok: false, error: { message: err.message, details: err.details } });
    if (err instanceof SyntaxError && 'body' in (err as object)) return res.status(400).json({ ok: false, error: { message: 'Malformed JSON body.' } });
    console.error(err);
    return res.status(500).json({ ok: false, error: { message: 'Unexpected server error. The action was not completed.' } });
  });

  return app;
}
