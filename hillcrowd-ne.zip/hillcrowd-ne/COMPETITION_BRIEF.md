# HillCrowd NE — Competition brief

*Category: Disaster Mitigation and Resilience — crowd safety, geospatial access resilience and emergency-response coordination.*

**Positioning:** *Route resilience before the event, accountable incident coordination during it.*

Labels used below:
- **[Assumption]** — a design assumption.
- **[Target]** — a proposed, unmeasured goal.
- **[Measured]** — observed behaviour of this prototype.

## 1. Problem

Large gatherings in hill regions combine crowd dynamics with constrained access. A venue may depend on a handful of narrow or steep roads, and rain can take one out. **[Assumption]** Two coordination problems follow, which we treat as hypotheses to validate with organisers, not established findings:

1. **Before the event:** nobody can easily see which zones, exits or medical routes depend on a single road. That only becomes obvious when the road fails.
2. **During the event:** reports arrive from many channels, and the hand-off from *report* to a *verified, assigned, acknowledged, resolved* action is hard to track. Delays are hard to attribute to a stage or an actor.

We make no claim that any named event's arrangements are inadequate.

## 2. Solution

- **Route Resilience Engine.** Models the venue's approved route network and its critical access links: every zone's walk-out to an assembly point, the medical post to every zone, ambulance access, and each approved route. It finds single points of failure and second-failure exposure, and simulates closures, rain, unusable exits, unavailable teams and mobile-data loss. It explains each detour, and says "No approved route available" when the plan has no valid alternative.
- **Event-readiness stress tests.** Recorded scenarios list affected zones, uncovered areas and missing fallbacks. They never award a blanket "safe" status.
- **Accountable incident coordination.** Field reports (offline-capable) → verification → explainable, trend-aware risk flags → assignment with route checks → acknowledgement → resolution. Every stage is timed against targets set by severity and incident type, and names who must act next.
- **Exercise and replay.** Labelled simulated events can be injected live, and a replay reconstructs every report, verification, decision, acknowledgement and resolution.

It supports, and does not replace, official warning systems and the judgement of the designated safety authority.

## 3. Why Meghalaya first

- **[Fact]** Shillong, the capital of Meghalaya, is the headquarters of the East Khasi Hills district and lies in hilly terrain at about 1,496 m above sea level.[^1]
- **[Fact]** Meghalaya contains the world's wettest places — Mawsynram and Cherrapunji, in the East Khasi Hills, hold the records for the highest average annual rainfall on Earth (around 11,900 mm).[^2] Heavy monsoon rain and the resulting landslides and flooding are recognised hazards in the state's own disaster-management planning.[^3]
- **[Assumption]** Some venues have steep or single-lane approaches, limited route redundancy and patchy mobile coverage. These are exactly the conditions the resilience engine tests, but each must be verified per venue. The product records only conditions confirmed by venue staff (for example the "rain-exposed" flag on a segment).
- **[Assumption]** Shillong hosts festivals, concerts and sporting events that draw large crowds, giving realistic pilot contexts.

## 4. Differentiation

National and state systems issue weather and disaster warnings and run emergency response; HillCrowd NE doesn't compete with them. It works at **event level** and **after** an alert or report. It focuses on whether the venue's approved access still works, and whether the response is moving and who must act. **[Assumption]** We haven't found generic event tools that combine an approved route graph, single-point-of-failure and second-failure analysis, and closure-driven invalidation. We'll confirm this with a structured review before claiming uniqueness.

## 5. Technical approach (what is actually built)

- **Resilience analysis:**
  - redundancy is counted as segment-disjoint approved routes;
  - single points of failure are found by single-segment removal;
  - second-failure pairs are tested over the best route plus its first alternative;
  - scenario evaluation layers simulated failures over live status, and never writes live data.
- **Max-of-conditions risk model:**
  - designated critical conditions can't be averaged away;
  - missing and stale inputs are explicit, and only distinct reporters count as independent corroboration;
  - trends come from a least-squares fit over manual estimates, with contradiction checks.
- **Stage-based accountability:**
  - per-stage targets by severity and type, with escalation once per stage;
  - route feasibility is rechecked before reassignment.
- **Idempotent offline outbox** with four user-facing states and separate device and server timestamps.
- **Audit trail:**
  - entries can't be edited or deleted through the application (enforced with database triggers);
  - this is *not* tamper-proof against direct database-file access;
  - production would add write-once or hash-chained storage.

## 6. Prototype status **[Measured]**

- Runs locally with `npm install && npm run setup && npm start`; no paid services or API keys.
- On the fictional demo venue, the engine identifies three single points of failure. One — the *Medical access lane* — cuts both approved ambulance routes. Closing the lower service road produces an explained detour; also closing the upper ring road produces "No approved route available".
- **Tests:** 73 automated unit and API tests, and a 24-check browser smoke test with zero console errors (see `TESTING.md`).
- **Not yet verified:** real map tiles, and offline behaviour under real field connectivity.
- **Demo timings:** response times in the demo come from simulated incidents run in minutes. They demonstrate measurement only, not real-world performance.

## 7. Pilot evaluation metrics **[Target]**

All measured against a baseline from the organiser's current process at a comparable event:

**Resilience**
- Number of single points of failure and access gaps found before the event.
- How many were mitigated, with a recorded fallback, before doors open.

**Response**
- Median time per stage (verification, assignment, acceptance, travel, resolution).
- The stages that most often overrun, analysed with their context (route, terrain).
- Acknowledgement within target.

**Data quality**
- Share of zones with fresh estimates.
- Contradictions resolved.
- Report completeness.

**Usability**
- Coordinator and steward task completion and SUS score.

**Accountability**
- Share of decisions reconstructable from the replay.

## 8. Pilot strategy

1. Partner with one organiser in Shillong. No partnership exists yet.
2. Map their **verified** route network and safety plan.
3. Run a resilience workshop with their safety officer: review single points of failure and record mitigations.
4. Tabletop exercise using the Exercise and replay features.
5. Shadow deployment at a small event, in parallel with radio procedures.
6. Review the results, then try a larger event.
7. Add verified Khasi and Garo interface translations.
8. Engage the district disaster-management authority on information sharing.

## 9. Scalability

The regional model is configurable: state, district, venue, hazards, routes, rain-exposed sections, teams, communication fallbacks, response targets and playbooks. The same core can be used in other Northeast states without code changes.

The production path:
- PostgreSQL;
- SSO and MFA;
- write-once audit storage and backups;
- multi-instance live updates;
- SMS or radio-gateway reporting;
- official-feed integration only through authorised interfaces.

## 10. Limitations and risks

**Prototype scope**
- The demo venue is fictional.
- There is no live advisory feed, live GPS, sensor, gate-counter or dispatch integration.

**Model limits**
- Resilience analysis covers only the configured network and the failures tested. It doesn't model travel time, congestion or physical road safety.
- Risk thresholds and response targets are configuration agreed with the event's safety officer, not validated safety science.
- Crowd trends are straight-line fits over manual estimates.

**Operational risks**
- Staff may over-rely on a "no gaps" result. This is mitigated by explicit wording ("not a safety certification") and training.
- Offline reports are invisible to the control room until synchronised.

**Not yet built or proven**
- No local-language interface yet.
- The prototype's security posture is not production-ready.

## Sources

1. Government of Meghalaya — *About Meghalaya* (capital, altitude and district list): https://www.meghalaya.gov.in/about · East Khasi Hills district administration — *District Profile* (district headquarters): https://eastkhasihills.gov.in/district-profile/
2. Government of Meghalaya — *Meghalaya State Climate Change Action Plan* (Ministry of Environment, Forest and Climate Change / MSCS&D): Cherrapunji's average rainfall of 11,952 mm over 35 years, and Meghalaya as "one of the wettest places in the world" — https://moef.gov.in/uploads/2017/08/Meghalaya.pdf
3. Meghalaya State Disaster Management Authority — *Meghalaya State Disaster Management Plan, Volume 2*, Chapters 5 (Floods) and 6 (Landslides): "The State is affected by landslide due to its hilly terrain and steep slopes and the vulnerability of landslide increases during the rainy seasons" — https://msdma.gov.in/SDMP/Volume-2.pdf
