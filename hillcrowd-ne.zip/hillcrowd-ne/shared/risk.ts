import { CATEGORY_LABEL, RISK_ORDER, maxLevel } from './constants';
import { reachableAny } from './routing';
import type {
  Advisory,
  ChecklistItem,
  EventSettings,
  Facility,
  Incident,
  OccupancyObservation,
  OccupancyTrend,
  RiskCondition,
  RiskLevel,
  RouteNode,
  RouteSegment,
  Zone,
  ZoneRisk,
} from './types';

export interface RiskInputs {
  zone: Zone;
  observations: OccupancyObservation[];
  incidents: Incident[];
  facilities: Facility[];
  nodes: RouteNode[];
  segments: RouteSegment[];
  advisories: Advisory[];
  checklist: ChecklistItem[];
  settings: EventSettings;
  now: Date;
  /** Conditions computed elsewhere (e.g. medical access lost in the route network). */
  extraConditions?: RiskCondition[];
}

const UNVERIFIED: Incident['status'][] = ['submitted', 'under_review'];
const VERIFIED_ACTIVE: Incident['status'][] = ['verified', 'assigned', 'acknowledged', 'in_progress'];
/** Verified categories that warrant prompt assignment by default. */
const ELEVATING_CATEGORIES = new Set(['crowd_congestion', 'exit_blockage', 'medical', 'missing_person', 'route_obstruction', 'weather']);
const CORROBORATABLE = new Set(['crowd_congestion', 'exit_blockage', 'route_obstruction']);

const minutesBetween = (a: string, now: Date) => (now.getTime() - new Date(a).getTime()) / 60000;

/** A rise of this much of capacity per 10 minutes is flagged even below the watch threshold. */
export const RAPID_RISE_PCT_PER_10MIN = 10;

/** Least-squares trend over recent (non-stale-window) estimates. Needs ≥2 readings spanning ≥2 min. */
export function occupancyTrend(obs: OccupancyObservation[], capacity: number | null, staleMinutes: number, now: Date): OccupancyTrend {
  const windowMin = Math.max(30, staleMinutes * 2);
  const recent = obs.filter((o) => minutesBetween(o.observedAt, now) <= windowMin && minutesBetween(o.observedAt, now) >= -5);
  const readings = recent.slice(-6).map((o) => ({ value: o.value, observedAt: o.observedAt, source: o.source, ageMin: Math.max(0, Math.round(minutesBetween(o.observedAt, now))) }));
  if (recent.length < 2) return { direction: 'unknown', ratePerMin: null, spanMin: null, readings };
  const t0 = Date.parse(recent[0].observedAt);
  const xs = recent.map((o) => (Date.parse(o.observedAt) - t0) / 60000);
  const span = xs[xs.length - 1];
  if (span < 2) return { direction: 'unknown', ratePerMin: null, spanMin: span, readings };
  const ys = recent.map((o) => o.value);
  const mx = xs.reduce((a, b) => a + b, 0) / xs.length;
  const my = ys.reduce((a, b) => a + b, 0) / ys.length;
  let num = 0;
  let den = 0;
  for (let i = 0; i < xs.length; i++) {
    num += (xs[i] - mx) * (ys[i] - my);
    den += (xs[i] - mx) ** 2;
  }
  const rate = den ? num / den : 0;
  // "Stable" if the change is below 2% of capacity per 10 minutes (or 5 people/min without a capacity).
  const stableBand = capacity ? (capacity * 0.02) / 10 : 5;
  const direction = Math.abs(rate) < stableBand ? 'stable' : rate > 0 ? 'rising' : 'falling';
  return { direction, ratePerMin: Math.round(rate * 10) / 10, spanMin: Math.round(span), readings };
}

/** Two readings from different sources within 10 minutes that differ by ≥20% of capacity. */
export function findConflict(obs: OccupancyObservation[], capacity: number | null, now: Date) {
  if (!capacity) return null;
  const recent = obs.filter((o) => minutesBetween(o.observedAt, now) <= 15).slice(-6).reverse();
  for (let i = 0; i < recent.length; i++)
    for (let j = i + 1; j < recent.length; j++) {
      const a = recent[i];
      const b = recent[j];
      const mins = Math.abs(Date.parse(a.observedAt) - Date.parse(b.observedAt)) / 60000;
      if (a.source !== b.source && mins <= 10 && Math.abs(a.value - b.value) >= capacity * 0.2) return { a, b, mins: Math.max(1, Math.round(mins)) };
    }
  return null;
}

export const POINTS: Record<RiskLevel, number> = { normal: 0, watch: 1, elevated: 3, critical: 10 };

/**
 * Rules-based, explainable zone risk assessment.
 * - The zone level is the MAXIMUM level of its conditions; nothing is averaged,
 *   so a designated critical condition can never be hidden by an aggregate score.
 * - Missing inputs are listed explicitly and never treated as "zero" / "empty".
 * - Each condition carries its source, observation time, staleness and verification state.
 */
export function assessZone(inp: RiskInputs): ZoneRisk {
  const { zone, settings, now } = inp;
  const conditions: RiskCondition[] = [];
  const missingInputs: string[] = [];
  const add = (c: RiskCondition) => conditions.push(c);

  // ---- 1. Occupancy against configured thresholds ----
  const obs = [...inp.observations].filter((o) => o.zoneId === zone.id).sort((a, b) => a.observedAt.localeCompare(b.observedAt));
  const latest = obs.at(-1) ?? null;
  const occStale = latest ? minutesBetween(latest.observedAt, now) > settings.staleMinutes : false;
  const trend = occupancyTrend(obs, zone.capacity, settings.staleMinutes, now);
  let pct: number | null = null;

  if (zone.capacity == null || zone.capacity <= 0) {
    missingInputs.push('Configured zone capacity');
    add({ code: 'CAPACITY_MISSING', level: 'watch', critical: false, message: 'No configured capacity for this zone, so occupancy thresholds cannot be evaluated.', source: 'Event configuration', observedAt: null, stale: false, verified: null });
  }
  if (!latest) {
    missingInputs.push('Occupancy estimate');
    add({
      code: 'OCCUPANCY_MISSING',
      level: settings.missingOccupancyLevel,
      critical: false,
      message: 'No occupancy estimate has been recorded. The zone is NOT assumed to be empty; request an estimate.',
      source: 'Data gap',
      observedAt: null,
      stale: false,
      verified: null,
    });
  } else {
    if (occStale) {
      add({
        code: 'OCCUPANCY_STALE',
        level: 'watch',
        critical: false,
        message: `Latest occupancy estimate is ${Math.round(minutesBetween(latest.observedAt, now))} min old (stale after ${settings.staleMinutes} min). Treat the figure below as out of date.`,
        source: latest.source,
        observedAt: latest.observedAt,
        stale: true,
        verified: null,
      });
    }
    if (zone.capacity && zone.capacity > 0) {
      pct = (latest.value / zone.capacity) * 100;
      const pctTxt = `${Math.round(pct)}% of configured capacity (${latest.value.toLocaleString('en-IN')} / ${zone.capacity.toLocaleString('en-IN')})`;
      if (zone.criticalPct != null && pct >= zone.criticalPct) {
        add({ code: 'OCCUPANCY_CRITICAL', level: 'critical', critical: true, message: `Estimated occupancy at ${pctTxt}, at or above the configured critical threshold of ${zone.criticalPct}%.`, source: latest.source, observedAt: latest.observedAt, stale: occStale, verified: null });
      } else if (pct >= zone.elevatedPct) {
        add({ code: 'OCCUPANCY_ELEVATED', level: 'elevated', critical: false, message: `Estimated occupancy at ${pctTxt}, at or above the configured elevated threshold of ${zone.elevatedPct}%.`, source: latest.source, observedAt: latest.observedAt, stale: occStale, verified: null });
      } else if (pct >= zone.watchPct) {
        add({ code: 'OCCUPANCY_WATCH', level: 'watch', critical: false, message: `Estimated occupancy at ${pctTxt}, approaching the configured watch threshold of ${zone.watchPct}%.`, source: latest.source, observedAt: latest.observedAt, stale: occStale, verified: null });
      }
      // Trend: projected crossing of the elevated threshold, and rapid rise even well below thresholds.
      if (!occStale && trend.ratePerMin != null && trend.ratePerMin > 0 && pct < zone.elevatedPct) {
        const projected = latest.value + trend.ratePerMin * 15;
        const ratePctPer10 = ((trend.ratePerMin * 10) / zone.capacity) * 100;
        const crosses = (projected / zone.capacity) * 100 >= zone.elevatedPct;
        if (crosses || ratePctPer10 >= RAPID_RISE_PCT_PER_10MIN) {
          add({
            code: 'OCCUPANCY_RISING',
            level: 'watch',
            critical: false,
            message: `Occupancy rising ~${Math.round(trend.ratePerMin)} people/min (≈${Math.round(ratePctPer10)}% of capacity per 10 min) across ${trend.readings.length} estimates over ${Math.round(trend.spanMin ?? 0)} min.${crosses ? ' A straight-line projection reaches the elevated threshold within 15 min.' : ''} Projection from manual estimates only — not a forecast.`,
            source: 'Trend of recorded estimates',
            observedAt: latest.observedAt,
            stale: false,
            verified: null,
          });
        }
      }
    }
    // Contradictory estimates: recent readings from different sources that disagree substantially.
    const conflict = findConflict(obs, zone.capacity, now);
    if (conflict) {
      add({ code: 'ESTIMATES_CONFLICT', level: 'watch', critical: false, message: `Estimates disagree: ${conflict.a.value.toLocaleString('en-IN')} (${conflict.a.source}) vs ${conflict.b.value.toLocaleString('en-IN')} (${conflict.b.source}) within ${conflict.mins} min. Confirm on the ground before relying on either.`, source: 'Data-quality check', observedAt: conflict.a.observedAt, stale: false, verified: null });
    }
  }

  // ---- 2. Incidents in this zone ----
  const zoneIncidents = inp.incidents.filter((i) => i.zoneId === zone.id);
  const active = zoneIncidents.filter((i) => !i.mergedInto && [...UNVERIFIED, ...VERIFIED_ACTIVE].includes(i.status));
  for (const inc of active) {
    const stale = minutesBetween(inc.updatedAt, now) > settings.staleMinutes;
    const label = `${CATEGORY_LABEL[inc.category]} (${inc.ref})`;
    if (UNVERIFIED.includes(inc.status)) {
      add({ code: 'INCIDENT_UNVERIFIED', level: 'watch', critical: false, message: `UNVERIFIED report: ${label}${inc.urgent ? ' — marked urgent by reporter' : ''}. Awaiting control-room review.`, source: `Field report by ${inc.reporterName ?? 'user'}`, observedAt: inc.receivedAt, stale, verified: false });
    } else {
      const sev = inc.confirmedSeverity;
      if (sev === 'critical') {
        add({ code: 'INCIDENT_CRITICAL', level: 'critical', critical: true, message: `Verified ${label} confirmed as CRITICAL severity by the control room.`, source: 'Control-room verification', observedAt: inc.verifiedAt ?? inc.updatedAt, stale, verified: true });
      } else {
        const lvl: RiskLevel = ELEVATING_CATEGORIES.has(inc.category) || sev === 'high' ? 'elevated' : 'watch';
        add({ code: 'INCIDENT_VERIFIED', level: lvl, critical: false, message: `Verified ${label}; status ${inc.status.replace('_', ' ')}${inc.status === 'verified' ? ' — no responder assigned yet' : ''}.`, source: 'Control-room verification', observedAt: inc.verifiedAt ?? inc.updatedAt, stale, verified: true });
      }
    }
  }
  // Independent corroboration: distinct reporters, unverified reports of the same corroboratable category.
  const windowed = zoneIncidents.filter(
    (i) => UNVERIFIED.includes(i.status) || (i.mergedInto && zoneIncidents.some((p) => p.id === i.mergedInto && UNVERIFIED.includes(p.status))),
  ).filter((i) => CORROBORATABLE.has(i.category) && minutesBetween(i.receivedAt, now) <= settings.corroborationWindowMinutes);
  const byCat = new Map<string, Set<string>>();
  for (const i of windowed) (byCat.get(i.category) ?? byCat.set(i.category, new Set()).get(i.category)!).add(i.reporterId);
  for (const [cat, reporters] of byCat) {
    if (reporters.size >= settings.corroborationMinReporters) {
      add({ code: 'CORROBORATED', level: 'elevated', critical: false, message: `${CATEGORY_LABEL[cat as Incident['category']]} reported by ${reporters.size} independent reporters within ${settings.corroborationWindowMinutes} min (still unverified). Same-reporter repeats are counted once.`, source: 'Multiple field reports', observedAt: windowed.map((w) => w.receivedAt).sort().at(-1) ?? null, stale: false, verified: false });
    }
  }

  // ---- 3. Exits and egress feasibility ----
  const exits = zone.exitIds.map((id) => inp.facilities.find((f) => f.id === id)).filter((f): f is Facility => !!f);
  const assemblyNodes = inp.facilities.filter((f) => f.kind === 'assembly' && f.status === 'open' && f.nodeId).map((f) => f.nodeId!);
  if (zone.exitIds.length === 0) missingInputs.push('Configured exits for zone');
  let usableExits = 0;
  for (const ex of exits) {
    const required = zone.requiredExitIds.includes(ex.id);
    if (ex.status === 'closed') {
      add({
        code: required ? 'REQUIRED_EXIT_UNAVAILABLE' : 'EXIT_UNAVAILABLE',
        level: required ? 'critical' : 'elevated',
        critical: required,
        message: required
          ? `${ex.name} is marked unavailable, but the approved safety plan requires it to remain available for this zone${ex.statusReason ? ` (${ex.statusReason})` : ''}.`
          : `${ex.name} is marked unavailable${ex.statusReason ? ` (${ex.statusReason})` : ''}.`,
        source: 'Exit status set by control room',
        observedAt: ex.statusUpdatedAt,
        stale: false,
        verified: true,
      });
      continue;
    }
    if (!ex.nodeId) continue;
    if (assemblyNodes.length === 0) {
      if (!missingInputs.includes('Assembly points')) missingInputs.push('Assembly points');
      continue;
    }
    const egress = reachableAny(inp.nodes, inp.segments, ex.nodeId, assemblyNodes);
    if (!egress) {
      add({ code: required ? 'REQUIRED_EGRESS_BLOCKED' : 'EGRESS_BLOCKED', level: required ? 'critical' : 'elevated', critical: required, message: `No open, approved walking route from ${ex.name} to any assembly point with current closures.`, source: 'Route network status', observedAt: null, stale: false, verified: true });
    } else {
      usableExits++;
      if (egress.warnings.length) {
        add({ code: 'EGRESS_UNDER_REVIEW', level: 'watch', critical: false, message: `Walking route from ${ex.name} to assembly relies on a segment under review: ${egress.warnings.join(' ')}`, source: 'Route network status', observedAt: egress.oldestStatusAt, stale: false, verified: null });
      }
    }
  }
  if (exits.length > 0 && usableExits === 0) {
    add({ code: 'NO_USABLE_EXIT', level: 'critical', critical: true, message: 'No configured exit for this zone currently has a usable route to an assembly point.', source: 'Exit and route status', observedAt: null, stale: false, verified: true });
  }

  // ---- 4. Advisories ----
  for (const adv of inp.advisories.filter((a) => a.affectedZoneIds.includes(zone.id) && a.verification !== 'rejected')) {
    const expired = adv.expiresAt ? new Date(adv.expiresAt) < now : false;
    if (expired) continue;
    const validity = adv.expiresAt ? `valid until ${new Date(adv.expiresAt).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })} IST` : 'validity period unknown';
    add({
      code: adv.verification === 'verified' ? 'ADVISORY_ACTIVE' : 'ADVISORY_UNVERIFIED',
      level: 'watch',
      critical: false,
      message: `${adv.verification === 'verified' ? 'Verified' : 'UNVERIFIED'} advisory${adv.isSample ? ' [SAMPLE / DEMO]' : ''}: "${adv.title}" — ${adv.issuer}; ${validity}.`,
      source: adv.issuer,
      observedAt: adv.issuedAt,
      stale: false,
      verified: adv.verification === 'verified',
    });
  }

  // ---- 5. Pre-event assessment findings ----
  for (const item of inp.checklist.filter((c) => c.zoneId === zone.id && (c.status === 'issue_identified' || c.status === 'mitigation_planned'))) {
    add({ code: 'PLAN_FINDING_OPEN', level: 'watch', critical: false, message: `Pre-event finding not yet verified as mitigated: ${item.label}${item.note ? ` — ${item.note}` : ''}.`, source: 'Venue risk assessment', observedAt: item.updatedAt, stale: false, verified: null });
  }

  for (const c of inp.extraConditions ?? []) add(c);

  // ---- Level: maximum, never averaged ----
  let level: RiskLevel = 'normal';
  for (const c of conditions) level = maxLevel(level, c.level);
  const attentionPoints = conditions.reduce((s, c) => s + POINTS[c.level], 0);
  conditions.sort((a, b) => RISK_ORDER[b.level] - RISK_ORDER[a.level]);

  return {
    zoneId: zone.id,
    level,
    conditions,
    missingInputs,
    occupancy: { value: latest?.value ?? null, capacity: zone.capacity, pct: pct == null ? null : Math.round(pct), observedAt: latest?.observedAt ?? null, source: latest?.source ?? null, stale: occStale, trend },
    attentionPoints,
    recommendedNextStep: recommend(level, conditions, missingInputs),
    computedAt: now.toISOString(),
  };
}

function recommend(level: RiskLevel, conditions: RiskCondition[], missing: string[]): string {
  const top = conditions[0];
  switch (level) {
    case 'critical':
      return `Immediate assessment by the designated safety authority. ${top?.message ?? ''} Any public instruction requires an authorised decision.`;
    case 'elevated':
      if (conditions.some((c) => c.code === 'CORROBORATED')) return 'Verify the corroborated reports and assign a responder to assess the zone.';
      if (conditions.some((c) => c.code === 'INCIDENT_VERIFIED' && c.message.includes('no responder'))) return 'Assign an appropriate responder to the verified incident and track acknowledgement.';
      return 'Prompt review: confirm the condition, check alternative exits/routes and assign an action.';
    case 'watch':
      if (missing.includes('Occupancy estimate')) return 'Request a current occupancy estimate from a steward in this zone.';
      if (conditions.some((c) => c.code === 'INCIDENT_UNVERIFIED')) return 'Review the unverified report(s) for this zone.';
      if (conditions.some((c) => c.stale)) return 'Refresh stale information before relying on it.';
      return 'Monitor; no action required yet beyond the listed conditions.';
    default:
      return 'No active configured threshold or unresolved condition. Continue routine monitoring.';
  }
}
