import type { EventSettings, IncidentCategory, IncidentStatus, RiskLevel, Severity, AssignmentStatus, StageTargets } from './types';

export const RISK_ORDER: Record<RiskLevel, number> = { normal: 0, watch: 1, elevated: 2, critical: 3 };

export const maxLevel = (a: RiskLevel, b: RiskLevel): RiskLevel => (RISK_ORDER[a] >= RISK_ORDER[b] ? a : b);

export const RISK_LABEL: Record<RiskLevel, string> = {
  normal: 'Normal',
  watch: 'Watch',
  elevated: 'Elevated',
  critical: 'Critical',
};

export const CATEGORIES: { key: IncidentCategory; label: string; short: string }[] = [
  { key: 'crowd_congestion', label: 'Crowd congestion', short: 'Congestion' },
  { key: 'exit_blockage', label: 'Exit or gate blockage', short: 'Exit blocked' },
  { key: 'medical', label: 'Medical incident', short: 'Medical' },
  { key: 'missing_person', label: 'Missing person', short: 'Missing person' },
  { key: 'infrastructure', label: 'Infrastructure or equipment failure', short: 'Infrastructure' },
  { key: 'route_obstruction', label: 'Route obstruction', short: 'Route obstruction' },
  { key: 'weather', label: 'Severe weather or environmental concern', short: 'Weather' },
  { key: 'communication', label: 'Communication failure', short: 'Comms failure' },
  { key: 'other', label: 'Other operational issue', short: 'Other' },
];

export const CATEGORY_LABEL = Object.fromEntries(CATEGORIES.map((c) => [c.key, c.label])) as Record<IncidentCategory, string>;

export const STATUS_LABEL: Record<IncidentStatus, string> = {
  submitted: 'Submitted',
  under_review: 'Under review',
  verified: 'Verified',
  rejected: 'Rejected',
  assigned: 'Assigned',
  acknowledged: 'Acknowledged',
  in_progress: 'In progress',
  resolved: 'Resolved',
  closed: 'Closed',
};

export const ASSIGNMENT_LABEL: Record<AssignmentStatus, string> = {
  assigned: 'Assigned (awaiting acknowledgement)',
  acknowledged: 'Acknowledged',
  en_route: 'En route',
  on_scene: 'On scene',
  resolved: 'Resolved',
  declined: 'Declined',
  unable: 'Unable to respond',
  cancelled: 'Cancelled',
};

export const SEVERITIES: Severity[] = ['low', 'moderate', 'high', 'critical'];
export const SEVERITY_ORDER: Record<Severity, number> = { low: 0, moderate: 1, high: 2, critical: 3 };

export const ACTIVE_INCIDENT_STATUSES: IncidentStatus[] = ['submitted', 'under_review', 'verified', 'assigned', 'acknowledged', 'in_progress'];
export const ACTIVE_ASSIGNMENT_STATUSES: AssignmentStatus[] = ['assigned', 'acknowledged', 'en_route', 'on_scene'];

export const DEFAULT_SETTINGS: EventSettings = {
  staleMinutes: 15,
  duplicateWindowMinutes: 10,
  duplicateRadiusM: 60,
  corroborationWindowMinutes: 15,
  corroborationMinReporters: 2,
  responseTargets: {
    low: { verify: 10, assign: 15, accept: 5, arrive: 20, resolve: 60, confirm: 15 },
    moderate: { verify: 5, assign: 10, accept: 4, arrive: 15, resolve: 45, confirm: 15 },
    high: { verify: 2, assign: 3, accept: 3, arrive: 10, resolve: 30, confirm: 10 },
    critical: { verify: 1, assign: 2, accept: 2, arrive: 6, resolve: 20, confirm: 5 },
  },
  categoryTargets: { medical: { accept: 2, arrive: 6 } },
  missingOccupancyLevel: 'watch',
  requireResolutionVerification: true,
};

export const NE_STATES = ['Meghalaya', 'Assam', 'Arunachal Pradesh', 'Manipur', 'Mizoram', 'Nagaland', 'Sikkim', 'Tripura'];

export const EVENT_TYPES = ['Concert', 'Festival', 'Cultural gathering', 'Sports event', 'Public gathering', 'Religious gathering', 'Other'];

export const STAGE_KEYS: (keyof StageTargets)[] = ['verify', 'assign', 'accept', 'arrive', 'resolve', 'confirm'];
export const STAGE_LABEL: Record<keyof StageTargets, string> = {
  verify: 'Verification',
  assign: 'Assignment',
  accept: 'Acceptance',
  arrive: 'Travel to scene',
  resolve: 'On-scene resolution',
  confirm: 'Closure confirmation',
};
