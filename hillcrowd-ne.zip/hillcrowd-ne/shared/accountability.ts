import { STAGE_LABEL } from './constants';
import type { Assignment, EventSettings, Incident, StageTargets } from './types';

export type StageKey = keyof StageTargets;

export interface StageRecord {
  key: StageKey;
  label: string;
  startedAt: string | null;
  completedAt: string | null;
  durationSec: number | null;
  targetSec: number;
  overdue: boolean;
  state: 'done' | 'current' | 'pending' | 'skipped';
}

export interface StageStatus {
  /** Stage currently waiting, or null when the incident is finished / rejected / merged. */
  current: StageKey | null;
  elapsedSec: number | null;
  targetSec: number | null;
  overdue: boolean;
  /** Fraction of the target used (can exceed 1). */
  progress: number | null;
  nextActor: string | null;
  nextAction: string | null;
  stages: StageRecord[];
}

/** Effective targets: severity targets, then category overrides. */
export function targetsFor(settings: EventSettings, inc: Pick<Incident, 'category' | 'confirmedSeverity' | 'severityEstimate'>): StageTargets {
  const sev = inc.confirmedSeverity ?? inc.severityEstimate;
  return { ...settings.responseTargets[sev], ...(settings.categoryTargets[inc.category] ?? {}) };
}

const secs = (a: string | null, b: string | null) => (a && b ? Math.max(0, (Date.parse(b) - Date.parse(a)) / 1000) : null);

/**
 * Break an incident's response into stages with their own targets, so a delay can be attributed
 * to the stage (and actor) where it happened. Durations are facts; whether a delay was reasonable
 * (terrain, inaccessible route, difficult case) is a human judgement the UI does not make.
 */
export function incidentStages(inc: Incident, assignments: Assignment[], settings: EventSettings, responderName: (id: string) => string, now: Date): StageStatus {
  const t = targetsFor(settings, inc);
  const mine = assignments.filter((a) => a.incidentId === inc.id).sort((a, b) => a.assignedAt.localeCompare(b.assignedAt));
  const active = mine.filter((a) => ['assigned', 'acknowledged', 'en_route', 'on_scene'].includes(a.status));
  // The assignment that currently carries the response (latest active), else the latest one.
  const cur = active.at(-1) ?? mine.at(-1) ?? null;
  const nowIso = now.toISOString();

  // Stage boundaries. Acceptance/travel/on-scene use the carrying assignment so a reassignment restarts them.
  const verifiedAt = inc.verifiedAt;
  const assignedAt = cur?.assignedAt ?? null;
  const acceptedAt = cur?.acknowledgedAt ?? null;
  const onSceneAt = cur?.onSceneAt ?? null;
  const resolvedAt = inc.resolvedAt ?? cur?.resolvedAt ?? null;
  const closedAt = inc.closedAt;

  const bounds: [StageKey, string | null, string | null][] = [
    ['verify', inc.receivedAt, verifiedAt],
    ['assign', verifiedAt, assignedAt],
    ['accept', assignedAt, acceptedAt],
    ['arrive', acceptedAt, onSceneAt],
    ['resolve', onSceneAt, resolvedAt],
    ['confirm', resolvedAt, closedAt],
  ];

  const finished = inc.status === 'closed' || inc.status === 'rejected' || !!inc.mergedInto;
  let current: StageKey | null = null;
  const stages: StageRecord[] = bounds.map(([key, start, end]) => {
    const targetSec = t[key] * 60;
    if (start && end) {
      const d = secs(start, end)!;
      return { key, label: STAGE_LABEL[key], startedAt: start, completedAt: end, durationSec: d, targetSec, overdue: d > targetSec, state: 'done' };
    }
    if (start && !end && !finished && current === null) {
      current = key;
      const d = secs(start, nowIso)!;
      return { key, label: STAGE_LABEL[key], startedAt: start, completedAt: null, durationSec: d, targetSec, overdue: d > targetSec, state: 'current' };
    }
    return { key, label: STAGE_LABEL[key], startedAt: start, completedAt: null, durationSec: null, targetSec, overdue: false, state: finished || inc.status === 'resolved' ? 'skipped' : 'pending' };
  });
  // A coordinator may resolve directly without an assignment: earlier unreached stages are skipped, not pending.
  if (resolvedAt) for (const st of stages) if (st.state === 'pending' && ['assign', 'accept', 'arrive', 'resolve'].includes(st.key)) st.state = 'skipped';

  const curRec = stages.find((s) => s.state === 'current') ?? null;
  const who = cur ? responderName(cur.responderId) : null;
  const ACTOR: Record<StageKey, [string | null, string]> = {
    verify: ['Control room', 'Review and verify or reject the report'],
    assign: ['Control room', 'Assign a responder with a valid route'],
    accept: [who, 'Acknowledge the assignment (or the control room confirms by radio / reassigns)'],
    arrive: [who, 'Travel to the scene and report on-scene'],
    resolve: [who, 'Resolve on scene and report the outcome'],
    confirm: ['Control room', 'Confirm the resolution and close'],
  };
  return {
    current: curRec?.key ?? null,
    elapsedSec: curRec?.durationSec ?? null,
    targetSec: curRec?.targetSec ?? null,
    overdue: curRec?.overdue ?? false,
    progress: curRec ? curRec.durationSec! / curRec.targetSec : null,
    nextActor: curRec ? ACTOR[curRec.key][0] : null,
    nextAction: curRec ? ACTOR[curRec.key][1] : null,
    stages,
  };
}
