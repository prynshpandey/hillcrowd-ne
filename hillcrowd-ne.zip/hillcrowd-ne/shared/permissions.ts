import type { Role } from './types';

/**
 * Permission matrix. The server enforces these on every mutating route;
 * the client uses the same table only to hide controls a role cannot use.
 */
export const PERMISSIONS = {
  'event.view': ['admin', 'coordinator', 'steward', 'responder'],
  'event.viewOps': ['admin', 'coordinator'],
  'event.configure': ['admin'],
  'event.create': ['admin'],
  'incident.create': ['admin', 'coordinator', 'steward'],
  'incident.viewAll': ['admin', 'coordinator'],
  'incident.review': ['admin', 'coordinator'],
  'incident.merge': ['admin', 'coordinator'],
  'incident.reopen': ['admin', 'coordinator'],
  'incident.close': ['admin', 'coordinator'],
  'incident.playbook': ['admin', 'coordinator'],
  'assignment.create': ['admin', 'coordinator'],
  'assignment.recordOnBehalf': ['admin', 'coordinator'],
  'assignment.updateOwn': ['responder', 'steward'],
  'occupancy.report': ['admin', 'coordinator', 'steward'],
  'route.compute': ['admin', 'coordinator', 'responder'],
  'route.setStatus': ['admin', 'coordinator'],
  'route.configure': ['admin'],
  'facility.setStatus': ['admin', 'coordinator'],
  'facility.configure': ['admin'],
  'zone.configure': ['admin'],
  'advisory.create': ['admin', 'coordinator'],
  'advisory.verify': ['admin', 'coordinator'],
  'checklist.update': ['admin', 'coordinator'],
  'checklist.verifyMitigation': ['admin'],
  'playbook.configure': ['admin'],
  'users.manage': ['admin'],
  'audit.view': ['admin', 'coordinator'],
  'analytics.view': ['admin', 'coordinator'],
  'demo.control': ['admin', 'coordinator'],
} as const satisfies Record<string, readonly Role[]>;

export type Permission = keyof typeof PERMISSIONS;

export function can(role: Role | null | undefined, perm: Permission): boolean {
  if (!role) return false;
  return (PERMISSIONS[perm] as readonly Role[]).includes(role);
}

export const ROLE_LABEL: Record<Role, string> = {
  admin: 'Administrator',
  coordinator: 'Control-room coordinator',
  steward: 'Field steward',
  responder: 'Responder',
};
