import { findRoute } from './routing';
import { pointInPolygon } from './geo';
import type { AccessLevel, Facility, NamedRoute, Responder, RouteNode, RouteResult, RouteSegment, TravelMode, Zone } from './types';

/**
 * Route Resilience Engine.
 *
 * Works only on the manually configured, approved venue route network. It answers:
 *  - Which critical access links depend on a single segment (single points of failure)?
 *  - Which links survive any one failure but would be lost if a second segment also failed?
 *  - Under a simulated set of failures, which links keep their planned route, which need a
 *    detour (and what that detour involves), and which have NO approved route at all?
 * It never invents a route and never claims a route is physically safe.
 */

export type LinkKind = 'egress' | 'medical_access' | 'vehicle_access' | 'approved_route';

export interface CriticalLink {
  id: string;
  kind: LinkKind;
  label: string;
  zoneId: string | null;
  sources: string[];
  targets: string[];
  mode: TravelMode;
  access: AccessLevel;
  /** Facilities whose availability is a precondition (e.g. exits used as sources). */
  sourceFacilities: string[];
}

export interface Scenario {
  closedSegments: string[];
  closedFacilities: string[];
  /** Treat every segment marked weather-exposed as unusable (heavy-rain stress test). */
  weatherExposedClosed?: boolean;
  unavailableResponders?: string[];
  /** Zones where mobile data is assumed to fail. */
  commsLostZones?: string[];
}

export const EMPTY_SCENARIO: Scenario = { closedSegments: [], closedFacilities: [] };

export interface DetourExplanation {
  extraDistanceM: number | null;
  addedSegments: { id: string; name: string; modes: TravelMode[]; access: AccessLevel; constraint: string; terrain: string; status: string }[];
  removedSegments: { id: string; name: string; reason: string }[];
}

export interface LinkResult {
  link: CriticalLink;
  plan: RouteResult | null;
  scenario: RouteResult | null;
  status: 'ok' | 'detour' | 'lost';
  detour: DetourExplanation | null;
  /** Independent (segment-disjoint) approved routes in the plan network, capped at 3. */
  redundancy: number;
  singlePoints: { id: string; name: string }[];
  secondFailures: { a: { id: string; name: string }; b: { id: string; name: string } }[];
}

export interface CoverageResult {
  zoneId: string;
  zoneName: string;
  medical: string[];
  stewards: string[];
  gaps: string[];
}

export interface CommsResult {
  zoneId: string;
  zoneName: string;
  fallback: string;
  gap: boolean;
}

export interface Gap {
  severity: 'critical' | 'major' | 'minor';
  area: string;
  message: string;
}

export interface ResilienceReport {
  links: LinkResult[];
  singlePointRanking: { id: string; name: string; links: string[] }[];
  coverage: CoverageResult[];
  comms: CommsResult[];
  gaps: Gap[];
  summary: { links: number; ok: number; detour: number; lost: number; singlePoints: number; gaps: number };
  statement: string;
}

export interface NetworkInput {
  zones: Zone[];
  facilities: Facility[];
  nodes: RouteNode[];
  segments: RouteSegment[];
  namedRoutes: NamedRoute[];
  responders?: Responder[];
}

/** Nodes considered "inside" a zone: those within its polygon plus the zone's exit nodes. */
export function zoneAccessNodes(zone: Zone, nodes: RouteNode[], facilities: Facility[]): string[] {
  const set = new Set<string>();
  for (const n of nodes) if (zone.polygon.length > 2 && pointInPolygon([n.lat, n.lng], zone.polygon)) set.add(n.id);
  for (const id of zone.exitIds) {
    const f = facilities.find((x) => x.id === id);
    if (f?.nodeId) set.add(f.nodeId);
  }
  return [...set];
}

export function criticalLinks(inp: NetworkInput): CriticalLink[] {
  const { zones, facilities, nodes, namedRoutes } = inp;
  const links: CriticalLink[] = [];
  const nodeOf = (fid: string) => facilities.find((f) => f.id === fid)?.nodeId ?? null;
  const assembly = facilities.filter((f) => f.kind === 'assembly' && f.nodeId);
  const medical = facilities.filter((f) => f.kind === 'medical' && f.nodeId);
  const handover = facilities.filter((f) => f.kind === 'handover' && f.nodeId);

  for (const z of zones) {
    const exits = z.exitIds.filter((id) => nodeOf(id));
    if (exits.length && assembly.length) {
      links.push({
        id: `egress:${z.id}`,
        kind: 'egress',
        label: `${z.name} → any assembly point (walk-out)`,
        zoneId: z.id,
        sources: exits.map((id) => nodeOf(id)!),
        targets: assembly.map((a) => a.nodeId!),
        mode: 'foot',
        access: 'public',
        sourceFacilities: exits,
      });
    }
    const inside = zoneAccessNodes(z, nodes, facilities);
    for (const m of medical) {
      if (!inside.length || inside.includes(m.nodeId!)) continue;
      links.push({
        id: `med:${m.id}:${z.id}`,
        kind: 'medical_access',
        label: `${m.name} → ${z.name} (medical team on foot)`,
        zoneId: z.id,
        sources: [m.nodeId!],
        targets: inside,
        mode: 'foot',
        access: 'staff',
        sourceFacilities: [m.id],
      });
    }
  }

  const covered = new Set(namedRoutes.map((r) => [r.fromNode, r.toNode].sort().join('|') + `|${r.mode}`));
  for (const h of handover)
    for (const m of medical) {
      if (covered.has([h.nodeId!, m.nodeId!].sort().join('|') + '|vehicle')) continue;
      links.push({ id: `veh:${h.id}:${m.id}`, kind: 'vehicle_access', label: `${h.name} ↔ ${m.name} (emergency vehicle)`, zoneId: null, sources: [m.nodeId!], targets: [h.nodeId!], mode: 'vehicle', access: 'emergency', sourceFacilities: [m.id, h.id] });
    }

  for (const r of namedRoutes) {
    links.push({ id: `route:${r.id}`, kind: 'approved_route', label: r.name, zoneId: null, sources: [r.fromNode], targets: [r.toNode], mode: r.mode, access: r.access, sourceFacilities: [] });
  }
  return links;
}

/** Network as planned: every approved segment available. */
export function planNetwork(segments: RouteSegment[]): RouteSegment[] {
  return segments.map((s) => ({ ...s, status: 'open', statusReason: null }));
}

/** Live network with simulated failures applied on top (does not modify the input). */
export function applyScenario(segments: RouteSegment[], sc: Scenario): RouteSegment[] {
  const closed = new Set(sc.closedSegments);
  return segments.map((s) => {
    if (closed.has(s.id)) return { ...s, status: 'closed', statusReason: 'Simulated failure' };
    if (sc.weatherExposedClosed && s.weatherExposed) return { ...s, status: 'closed', statusReason: 'Simulated: weather-exposed section unusable in heavy rain' };
    return s;
  });
}

/** Best route for a link across all its sources/targets. Closed facilities remove their nodes as sources/targets. */
export function bestRoute(link: CriticalLink, nodes: RouteNode[], segments: RouteSegment[], facilities: Facility[], closedFacilities: Set<string>): RouteResult | null {
  const blockedNodes = new Set(facilities.filter((f) => closedFacilities.has(f.id) || f.status === 'closed').map((f) => f.nodeId));
  const sources = link.sources.filter((n) => !blockedNodes.has(n));
  const targets = link.targets.filter((n) => !blockedNodes.has(n) || link.kind === 'medical_access');
  let best: RouteResult | null = null;
  for (const s of sources)
    for (const t of targets) {
      const r = findRoute(nodes, segments, { from: s, to: t, mode: link.mode, access: link.access });
      if (r.found && (!best || (r.distanceM ?? Infinity) < (best.distanceM ?? Infinity))) best = r;
    }
  return best;
}

const withClosed = (segments: RouteSegment[], ids: string[]) => {
  const set = new Set(ids);
  return segments.map((s) => (set.has(s.id) ? { ...s, status: 'closed' as const } : s));
};

function redundancyOf(link: CriticalLink, nodes: RouteNode[], segments: RouteSegment[], facilities: Facility[]): number {
  let segs = segments;
  let n = 0;
  while (n < 3) {
    const r = bestRoute(link, nodes, segs, facilities, new Set());
    if (!r) break;
    n++;
    segs = withClosed(segs, r.segmentIds);
  }
  return n;
}

export function analyseNetwork(inp: NetworkInput, sc: Scenario = EMPTY_SCENARIO): ResilienceReport {
  const { nodes, facilities, zones } = inp;
  const segName = new Map(inp.segments.map((s) => [s.id, s.name]));
  const segById = new Map(inp.segments.map((s) => [s.id, s]));
  const plan = planNetwork(inp.segments);
  const live = applyScenario(inp.segments, sc);
  const closedFac = new Set(sc.closedFacilities);
  const links = criticalLinks(inp);
  const results: LinkResult[] = [];
  const spRank = new Map<string, Set<string>>();

  for (const link of links) {
    const planRoute = bestRoute(link, nodes, plan, facilities.map((f) => ({ ...f, status: 'open' as const })), new Set());
    const scRoute = bestRoute(link, nodes, live, facilities, closedFac);

    // Single points of failure and second-failure exposure, assessed on the planned network.
    const singlePoints: LinkResult['singlePoints'] = [];
    const secondFailures: LinkResult['secondFailures'] = [];
    let redundancy = 0;
    if (planRoute) {
      redundancy = redundancyOf(link, nodes, plan, facilities);
      for (const id of planRoute.segmentIds) {
        if (!bestRoute(link, nodes, withClosed(plan, [id]), facilities, new Set())) {
          singlePoints.push({ id, name: segName.get(id) ?? id });
          (spRank.get(id) ?? spRank.set(id, new Set()).get(id)!).add(link.label);
        }
      }
      if (!singlePoints.length) {
        const alt = bestRoute(link, nodes, withClosed(plan, planRoute.segmentIds), facilities, new Set());
        const cand = [...new Set([...planRoute.segmentIds, ...(alt?.segmentIds ?? [])])];
        outer: for (let i = 0; i < cand.length; i++)
          for (let j = i + 1; j < cand.length; j++) {
            if (!bestRoute(link, nodes, withClosed(plan, [cand[i], cand[j]]), facilities, new Set())) {
              secondFailures.push({ a: { id: cand[i], name: segName.get(cand[i])! }, b: { id: cand[j], name: segName.get(cand[j])! } });
              if (secondFailures.length >= 4) break outer;
            }
          }
      }
    }

    let status: LinkResult['status'] = 'ok';
    let detour: DetourExplanation | null = null;
    if (!scRoute) status = 'lost';
    else if (planRoute && scRoute.segmentIds.join() !== planRoute.segmentIds.join()) {
      status = 'detour';
      const planSet = new Set(planRoute.segmentIds);
      const scSet = new Set(scRoute.segmentIds);
      detour = {
        extraDistanceM: planRoute.distanceM != null && scRoute.distanceM != null ? scRoute.distanceM - planRoute.distanceM : null,
        addedSegments: scRoute.segmentIds
          .filter((id) => !planSet.has(id))
          .map((id) => {
            const s = segById.get(id)!;
            return { id, name: s.name, modes: s.modes, access: s.access, constraint: s.constraintNote, terrain: s.terrainNote, status: live.find((x) => x.id === id)!.status };
          }),
        removedSegments: planRoute.segmentIds
          .filter((id) => !scSet.has(id))
          .map((id) => ({ id, name: segName.get(id)!, reason: live.find((x) => x.id === id)?.statusReason ?? (live.find((x) => x.id === id)?.status === 'closed' ? 'Closed' : 'Not on shortest available route') })),
      };
    }
    results.push({ link, plan: planRoute, scenario: scRoute, status, detour, redundancy, singlePoints, secondFailures });
  }

  // Responder coverage: which available teams can still reach each zone.
  const coverage: CoverageResult[] = [];
  const unavailable = new Set(sc.unavailableResponders ?? []);
  const responders = (inp.responders ?? []).filter((r) => !unavailable.has(r.id) && r.status !== 'off_duty');
  if (inp.responders) {
    for (const z of zones) {
      const inside = zoneAccessNodes(z, nodes, facilities);
      const reach = (r: Responder) => {
        const origin = r.baseNodeId;
        if (!origin || !inside.length) return false;
        return r.modes.some((mode) => inside.some((t) => findRoute(nodes, live, { from: origin, to: t, mode, access: r.access }).found));
      };
      const medical = responders.filter((r) => (r.kind === 'medical' || r.kind === 'ambulance') && reach(r)).map((r) => r.name);
      const stewards = responders.filter((r) => r.kind === 'steward_team' && reach(r)).map((r) => r.name);
      const gaps: string[] = [];
      if (!medical.length) gaps.push('No available medical responder can reach this zone on an approved route');
      if (!stewards.length) gaps.push('No available steward team can reach this zone on an approved route');
      coverage.push({ zoneId: z.id, zoneName: z.name, medical, stewards, gaps });
    }
  }

  const comms: CommsResult[] = (sc.commsLostZones ?? []).map((id) => {
    const z = zones.find((x) => x.id === id)!;
    return { zoneId: id, zoneName: z?.name ?? id, fallback: z?.commsFallback ?? '', gap: !z?.commsFallback?.trim() };
  });

  const gaps: Gap[] = [];
  for (const r of results) {
    if (r.status === 'lost') gaps.push({ severity: r.link.kind === 'egress' || r.link.kind === 'vehicle_access' || r.link.kind === 'approved_route' ? 'critical' : 'major', area: r.link.label, message: 'No approved route available. The venue plan has no valid alternative — a plan decision is needed.' });
  }
  for (const f of sc.closedFacilities) {
    const fac = facilities.find((x) => x.id === f);
    for (const z of zones.filter((zz) => zz.requiredExitIds.includes(f))) gaps.push({ severity: 'critical', area: z.name, message: `${fac?.name ?? f} is required by the safety plan for this zone but is unavailable in this scenario.` });
  }
  for (const c of coverage) for (const g of c.gaps) gaps.push({ severity: 'major', area: c.zoneName, message: g });
  for (const c of comms) if (c.gap) gaps.push({ severity: 'major', area: c.zoneName, message: 'Mobile data lost and no communication fallback is recorded for this zone. Field reports would queue on devices and not reach the control room.' });

  const singlePointRanking = [...spRank.entries()].map(([id, set]) => ({ id, name: segName.get(id) ?? id, links: [...set] })).sort((a, b) => b.links.length - a.links.length);
  const summary = {
    links: results.length,
    ok: results.filter((r) => r.status === 'ok').length,
    detour: results.filter((r) => r.status === 'detour').length,
    lost: results.filter((r) => r.status === 'lost').length,
    singlePoints: singlePointRanking.length,
    gaps: gaps.length,
  };
  return {
    links: results,
    singlePointRanking,
    coverage,
    comms,
    gaps,
    summary,
    statement: gaps.length
      ? `${gaps.length} unresolved gap(s) found for this scenario. Each needs a plan decision or a recorded fallback.`
      : 'No gaps found for the failures tested. This covers only the simulated failures and the configured network; it is not a safety certification.',
  };
}
