import type { AssignmentStatus, IncidentStatus, Role } from './types';

/**
 * Incident status workflow:
 * Submitted → Under Review → Verified | Rejected → Assigned → Acknowledged → In Progress → Resolved → Closed
 *
 * Transitions driven by assignments (assigned/acknowledged/in_progress) are applied by the
 * assignment service, not requested directly. "reopen" returns a finished incident to review.
 */
export interface Transition {
  from: IncidentStatus[];
  to: IncidentStatus;
  roles: Role[];
  /** Reason/note is mandatory for this transition. */
  requiresNote?: boolean;
  /** Internal transitions are only applied by the assignment service. */
  internal?: boolean;
  label: string;
}

export const INCIDENT_TRANSITIONS: Transition[] = [
  { from: ['submitted'], to: 'under_review', roles: ['coordinator', 'admin'], label: 'Start review' },
  { from: ['submitted', 'under_review'], to: 'verified', roles: ['coordinator', 'admin'], label: 'Verify' },
  { from: ['submitted', 'under_review'], to: 'rejected', roles: ['coordinator', 'admin'], requiresNote: true, label: 'Reject' },
  { from: ['verified'], to: 'assigned', roles: ['coordinator', 'admin'], internal: true, label: 'Assign' },
  { from: ['assigned'], to: 'acknowledged', roles: ['responder', 'steward', 'coordinator', 'admin'], internal: true, label: 'Acknowledge' },
  { from: ['acknowledged'], to: 'in_progress', roles: ['responder', 'steward', 'coordinator', 'admin'], internal: true, label: 'Start' },
  // Declined / unable assignment returns the incident to verified for reassignment.
  { from: ['assigned', 'acknowledged', 'in_progress'], to: 'verified', roles: ['responder', 'steward', 'coordinator', 'admin'], internal: true, label: 'Return for reassignment' },
  { from: ['in_progress', 'acknowledged', 'assigned', 'verified'], to: 'resolved', roles: ['responder', 'steward', 'coordinator', 'admin'], requiresNote: true, label: 'Mark resolved' },
  { from: ['resolved'], to: 'closed', roles: ['coordinator', 'admin'], label: 'Confirm & close' },
  { from: ['resolved'], to: 'in_progress', roles: ['coordinator', 'admin'], requiresNote: true, label: 'Return to in progress' },
  { from: ['resolved', 'closed', 'rejected'], to: 'under_review', roles: ['coordinator', 'admin'], requiresNote: true, label: 'Reopen' },
];

export class WorkflowError extends Error {
  constructor(message: string, public status = 409) {
    super(message);
  }
}

export function findTransition(from: IncidentStatus, to: IncidentStatus, role: Role, opts: { internal?: boolean } = {}): Transition {
  const candidates = INCIDENT_TRANSITIONS.filter((t) => t.to === to && t.from.includes(from));
  if (candidates.length === 0) {
    throw new WorkflowError(`Transition from "${from}" to "${to}" is not permitted by the incident workflow.`);
  }
  const allowed = candidates.find((t) => t.roles.includes(role) && (opts.internal || !t.internal));
  if (!allowed) {
    const internalOnly = candidates.every((t) => t.internal) && !opts.internal;
    throw new WorkflowError(
      internalOnly
        ? `"${to}" is set through the assignment workflow, not directly.`
        : `Role "${role}" may not move an incident from "${from}" to "${to}".`,
      403,
    );
  }
  return allowed;
}

/** Manual (non-internal) transitions available to a role from a given status, for UI buttons. */
export function availableTransitions(from: IncidentStatus, role: Role): Transition[] {
  // Field roles change incident status only through their assignment.
  if (role === 'responder' || role === 'steward') return [];
  return INCIDENT_TRANSITIONS.filter((t) => !t.internal && t.from.includes(from) && t.roles.includes(role));
}

/** Assignment / responder workflow: Assigned → Acknowledged → En Route → On Scene → Resolved. */
export const ASSIGNMENT_FLOW: Record<AssignmentStatus, AssignmentStatus[]> = {
  assigned: ['acknowledged', 'declined', 'unable', 'cancelled'],
  acknowledged: ['en_route', 'on_scene', 'unable', 'cancelled'],
  en_route: ['on_scene', 'unable', 'cancelled'],
  on_scene: ['resolved', 'unable', 'cancelled'],
  resolved: [],
  declined: [],
  unable: [],
  cancelled: [],
};

export function assertAssignmentTransition(from: AssignmentStatus, to: AssignmentStatus): void {
  if (!ASSIGNMENT_FLOW[from].includes(to)) {
    throw new WorkflowError(`Assignment cannot move from "${from}" to "${to}".`);
  }
}

export const TERMINAL_ASSIGNMENT: AssignmentStatus[] = ['resolved', 'declined', 'unable', 'cancelled'];
