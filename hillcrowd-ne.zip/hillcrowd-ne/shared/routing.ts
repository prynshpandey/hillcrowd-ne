import type { AccessLevel, NamedRoute, NamedRouteValidity, RouteNode, RouteRequest, RouteResult, RouteSegment } from './types';

const ACCESS_RANK: Record<AccessLevel, number> = { public: 0, staff: 1, emergency: 2 };

/** A traveller with access level X may use segments whose access requirement is <= X. */
export function accessAllows(traveller: AccessLevel, segment: AccessLevel): boolean {
  return ACCESS_RANK[traveller] >= ACCESS_RANK[segment];
}

interface Edge {
  seg: RouteSegment;
  to: string;
}

/** Explain why a segment cannot be used for a request, or null if usable. */
export function segmentExclusionReason(seg: RouteSegment, req: RouteRequest): string | null {
  if (seg.status === 'closed') return `Closed${seg.statusReason ? `: ${seg.statusReason}` : ''}`;
  if (!seg.approved) return 'Not approved in the venue route network';
  if (!seg.modes.includes(req.mode)) return `Not configured for ${req.mode} travel`;
  if (!accessAllows(req.access, seg.access)) return `Requires ${seg.access} access`;
  if (seg.status === 'under_review' && req.avoidUnderReview) return `Under review${seg.statusReason ? `: ${seg.statusReason}` : ''}`;
  return null;
}

/**
 * Find the shortest feasible route over the manually configured, approved network.
 * Never invents a route: if the filtered graph has no path, `found` is false.
 * Distance is the configured distance; a route existing here does NOT mean it is physically safe.
 */
export function findRoute(nodes: RouteNode[], segments: RouteSegment[], req: RouteRequest, now = new Date()): RouteResult {
  const nodeIds = new Set(nodes.map((n) => n.id));
  const base: RouteResult = {
    found: false,
    from: req.from,
    to: req.to,
    mode: req.mode,
    access: req.access,
    nodeIds: [],
    segmentIds: [],
    distanceM: null,
    constraints: [],
    warnings: [],
    excludedSegments: [],
    oldestStatusAt: null,
    approvalStatus: 'none',
    reason: '',
    computedAt: now.toISOString(),
  };
  if (!nodeIds.has(req.from) || !nodeIds.has(req.to)) {
    return { ...base, reason: 'Origin or destination is not part of the configured route network.' };
  }
  if (req.from === req.to) {
    return { ...base, found: true, nodeIds: [req.from], distanceM: 0, approvalStatus: 'approved_network', reason: 'Origin and destination are the same location.' };
  }

  const adj = new Map<string, Edge[]>();
  for (const seg of segments) {
    const why = segmentExclusionReason(seg, req);
    if (why) {
      base.excludedSegments.push({ id: seg.id, name: seg.name, reason: why });
      continue;
    }
    if (!nodeIds.has(seg.fromNode) || !nodeIds.has(seg.toNode)) continue;
    // Segments are bidirectional in this prototype.
    (adj.get(seg.fromNode) ?? adj.set(seg.fromNode, []).get(seg.fromNode)!).push({ seg, to: seg.toNode });
    (adj.get(seg.toNode) ?? adj.set(seg.toNode, []).get(seg.toNode)!).push({ seg, to: seg.fromNode });
  }

  // Dijkstra (small graphs: simple O(V^2) selection is fine and deterministic).
  const dist = new Map<string, number>([[req.from, 0]]);
  const prev = new Map<string, { node: string; seg: RouteSegment }>();
  const done = new Set<string>();
  while (true) {
    let cur: string | null = null;
    let best = Infinity;
    for (const [n, d] of dist) {
      if (!done.has(n) && (d < best || (d === best && cur !== null && n < cur))) {
        best = d;
        cur = n;
      }
    }
    if (cur === null || cur === req.to) break;
    done.add(cur);
    for (const e of adj.get(cur) ?? []) {
      const nd = best + e.seg.distanceM;
      if (nd < (dist.get(e.to) ?? Infinity)) {
        dist.set(e.to, nd);
        prev.set(e.to, { node: cur, seg: e.seg });
      }
    }
  }

  if (!dist.has(req.to)) {
    return {
      ...base,
      reason: `No valid ${req.mode} route was found in the approved network for ${req.access} access with current closures. Escalate to the control-room coordinator; do not improvise a route.`,
    };
  }

  const path: string[] = [req.to];
  const segs: RouteSegment[] = [];
  let walk = req.to;
  while (walk !== req.from) {
    const p = prev.get(walk)!;
    segs.unshift(p.seg);
    path.unshift(p.node);
    walk = p.node;
  }

  const constraints = new Set<string>();
  const warnings: string[] = [];
  let oldest: string | null = null;
  for (const s of segs) {
    if (s.constraintNote) constraints.add(`${s.name}: ${s.constraintNote}`);
    if (s.terrainNote) constraints.add(`${s.name}: ${s.terrainNote}`);
    if (s.status === 'under_review') warnings.push(`${s.name} is under review${s.statusReason ? ` (${s.statusReason})` : ''}; confirm before use.`);
    if (!oldest || s.statusUpdatedAt < oldest) oldest = s.statusUpdatedAt;
  }

  return {
    ...base,
    found: true,
    nodeIds: path,
    segmentIds: segs.map((s) => s.id),
    distanceM: Math.round(dist.get(req.to)!),
    constraints: [...constraints],
    warnings,
    oldestStatusAt: oldest,
    approvalStatus: segs.every((s) => s.approved) ? 'approved_network' : 'contains_unapproved',
    reason: `Shortest configured ${req.mode} route using only approved, open segments permitted for ${req.access} access${
      base.excludedSegments.length ? `; ${base.excludedSegments.length} segment(s) excluded` : ''
    }.`,
  };
}

/** Which named (pre-approved) routes depend on segments that are closed or under review, with alternatives. */
export function validateNamedRoutes(nodes: RouteNode[], segments: RouteSegment[], routes: NamedRoute[], now = new Date()): NamedRouteValidity[] {
  const byId = new Map(segments.map((s) => [s.id, s]));
  return routes.map((r) => {
    const blocked: NamedRouteValidity['blockedSegments'] = [];
    const review: NamedRouteValidity['reviewSegments'] = [];
    for (const id of r.segmentIds) {
      const s = byId.get(id);
      if (!s) {
        blocked.push({ id, name: id, status: 'closed', reason: 'Segment no longer exists in the network' });
        continue;
      }
      const unusable = s.status === 'closed' || !s.approved || !s.modes.includes(r.mode) || !accessAllows(r.access, s.access);
      if (unusable) blocked.push({ id, name: s.name, status: s.status, reason: s.statusReason ?? (s.approved ? 'Not usable for this route mode/access' : 'Not approved') });
      else if (s.status === 'under_review') review.push({ id, name: s.name, reason: s.statusReason });
    }
    const valid = blocked.length === 0;
    const alternative = valid
      ? null
      : findRoute(nodes, segments, { from: r.fromNode, to: r.toNode, mode: r.mode, access: r.access }, now);
    return { routeId: r.id, valid, blockedSegments: blocked, reviewSegments: review, alternative };
  });
}

/** Can a node reach any of the target nodes on foot (public access) using open segments? Used for egress checks. */
export function reachableAny(nodes: RouteNode[], segments: RouteSegment[], from: string, targets: string[]): RouteResult | null {
  let best: RouteResult | null = null;
  for (const t of targets) {
    const r = findRoute(nodes, segments, { from, to: t, mode: 'foot', access: 'public' });
    if (r.found && (!best || (r.distanceM ?? Infinity) < (best.distanceM ?? Infinity))) best = r;
  }
  return best;
}
