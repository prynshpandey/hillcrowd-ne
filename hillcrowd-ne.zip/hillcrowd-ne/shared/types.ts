// Core domain types shared by the server, the client and the tests.

export type Role = 'admin' | 'coordinator' | 'steward' | 'responder';

export type RiskLevel = 'normal' | 'watch' | 'elevated' | 'critical';

export type IncidentCategory =
  | 'crowd_congestion'
  | 'exit_blockage'
  | 'medical'
  | 'missing_person'
  | 'infrastructure'
  | 'route_obstruction'
  | 'weather'
  | 'communication'
  | 'other';

export type IncidentStatus =
  | 'submitted'
  | 'under_review'
  | 'verified'
  | 'rejected'
  | 'assigned'
  | 'acknowledged'
  | 'in_progress'
  | 'resolved'
  | 'closed';

export type Severity = 'low' | 'moderate' | 'high' | 'critical';

export type AssignmentStatus =
  | 'assigned'
  | 'acknowledged'
  | 'en_route'
  | 'on_scene'
  | 'resolved'
  | 'declined'
  | 'unable'
  | 'cancelled';

export type ResponderStatus = 'available' | 'assigned' | 'acknowledged' | 'en_route' | 'on_scene' | 'off_duty';

export type TravelMode = 'foot' | 'vehicle';

/** Who may use a segment. 'public' < 'staff' < 'emergency' (higher access can use lower). */
export type AccessLevel = 'public' | 'staff' | 'emergency';

export type SegmentStatus = 'open' | 'under_review' | 'closed';

export type FacilityKind = 'gate' | 'exit' | 'medical' | 'assembly' | 'control' | 'handover';

export type FacilityStatus = 'open' | 'closed';

export type AdvisoryVerification = 'unverified' | 'verified' | 'rejected';

export type ChecklistStatus = 'not_assessed' | 'no_issue' | 'issue_identified' | 'mitigation_planned' | 'mitigation_verified';

export interface User {
  id: string;
  username: string;
  displayName: string;
  role: Role;
  responderId: string | null;
  isDemo: boolean;
}

export interface EventRecord {
  id: string;
  name: string;
  eventType: string;
  state: string;
  district: string;
  locationLabel: string;
  venueName: string;
  venueIsFictional: boolean;
  startsAt: string;
  endsAt: string;
  expectedAttendance: number | null;
  venueCapacity: number | null;
  controlContact: string;
  centerLat: number;
  centerLng: number;
  zoom: number;
  boundary: [number, number][];
  isDemo: boolean;
  settings: EventSettings;
}

export interface EventSettings {
  /** Minutes after which an occupancy estimate or report is considered stale. */
  staleMinutes: number;
  /** Time window (minutes) in which similar reports are flagged as possible duplicates. */
  duplicateWindowMinutes: number;
  /** Distance (metres) within which similar reports are flagged as possible duplicates. */
  duplicateRadiusM: number;
  /** Window (minutes) for counting independent corroborating reports. */
  corroborationWindowMinutes: number;
  /** Number of independent reporters needed to treat an unverified condition as corroborated. */
  corroborationMinReporters: number;
  /** Response-stage targets (minutes) by confirmed severity. Escalation happens when a stage overruns. */
  responseTargets: Record<Severity, StageTargets>;
  /** Optional per-category overrides applied on top of the severity targets (e.g. medical acceptance). */
  categoryTargets: Partial<Record<IncidentCategory, Partial<StageTargets>>>;
  /** Risk level raised when a zone has no occupancy estimate at all. */
  missingOccupancyLevel: RiskLevel;
  /** If true, a responder's "resolved" must be confirmed (closed) by a coordinator. */
  requireResolutionVerification: boolean;
}

/** Target minutes for each response stage. Stages are measured separately, not cumulatively. */
export interface StageTargets {
  verify: number;
  assign: number;
  accept: number;
  arrive: number;
  resolve: number;
  confirm: number;
}

export interface Zone {
  id: string;
  eventId: string;
  name: string;
  polygon: [number, number][];
  capacity: number | null;
  watchPct: number;
  elevatedPct: number;
  criticalPct: number | null;
  /** Facility IDs of exits that the approved safety plan requires to stay available. */
  requiredExitIds: string[];
  /** All exits (facility IDs) serving this zone. */
  exitIds: string[];
  notes: string;
  /** Configured fallback if mobile data fails in this zone (e.g. radio channel). Empty = none recorded. */
  commsFallback: string;
}

export interface OccupancyObservation {
  id: string;
  zoneId: string;
  value: number;
  observedAt: string;
  source: string;
  reportedBy: string | null;
}

export interface Facility {
  id: string;
  eventId: string;
  kind: FacilityKind;
  name: string;
  lat: number;
  lng: number;
  zoneId: string | null;
  nodeId: string | null;
  status: FacilityStatus;
  statusReason: string | null;
  statusUpdatedAt: string;
  capacityPerMin: number | null;
  notes: string;
}

export interface RouteNode {
  id: string;
  eventId: string;
  name: string;
  lat: number;
  lng: number;
  facilityId: string | null;
}

export interface RouteSegment {
  id: string;
  eventId: string;
  name: string;
  fromNode: string;
  toNode: string;
  distanceM: number;
  modes: TravelMode[];
  access: AccessLevel;
  status: SegmentStatus;
  statusReason: string | null;
  statusSource: string | null;
  statusUpdatedAt: string;
  approved: boolean;
  constraintNote: string;
  terrainNote: string;
  /** Section confirmed by venue staff as exposed to heavy rain (water-logging, slips). Used by stress tests. */
  weatherExposed: boolean;
  /** Polyline geometry for display (defaults to the straight line between nodes). */
  path: [number, number][];
}

export interface NamedRoute {
  id: string;
  eventId: string;
  name: string;
  purpose: string;
  mode: TravelMode;
  access: AccessLevel;
  fromNode: string;
  toNode: string;
  segmentIds: string[];
  approvedBy: string | null;
  approvedAt: string | null;
}

export interface Incident {
  id: string;
  ref: string;
  eventId: string;
  clientId: string | null;
  category: IncidentCategory;
  zoneId: string | null;
  lat: number | null;
  lng: number | null;
  description: string;
  severityEstimate: Severity;
  confirmedSeverity: Severity | null;
  urgent: boolean;
  status: IncidentStatus;
  reporterId: string;
  reporterName?: string;
  ownerId: string | null;
  createdLocalAt: string;
  receivedAt: string;
  updatedAt: string;
  verifiedAt: string | null;
  assignedAt: string | null;
  acknowledgedAt: string | null;
  resolvedAt: string | null;
  closedAt: string | null;
  mergedInto: string | null;
  possibleDuplicateOf: string[];
  reopenCount: number;
  isDemo: boolean;
  attachmentNote: string | null;
}

export interface IncidentUpdate {
  id: string;
  incidentId: string;
  actorId: string | null;
  actorName?: string;
  kind: string;
  fromStatus: IncidentStatus | null;
  toStatus: IncidentStatus | null;
  note: string;
  createdAt: string;
}

export interface Responder {
  id: string;
  eventId: string;
  name: string;
  team: string;
  kind: 'steward_team' | 'medical' | 'ambulance' | 'security' | 'operations';
  modes: TravelMode[];
  access: AccessLevel;
  status: ResponderStatus;
  baseNodeId: string | null;
  lat: number | null;
  lng: number | null;
  locationSource: string | null;
  locationUpdatedAt: string | null;
  userId: string | null;
}

export interface Assignment {
  id: string;
  incidentId: string;
  responderId: string;
  status: AssignmentStatus;
  assignedBy: string;
  note: string;
  assignedAt: string;
  acknowledgedAt: string | null;
  enRouteAt: string | null;
  onSceneAt: string | null;
  resolvedAt: string | null;
  closedReason: string | null;
  escalatedAt: string | null;
  escalationReason: string | null;
  route: RouteResult | null;
}

export interface Advisory {
  id: string;
  eventId: string;
  title: string;
  issuer: string;
  sourceUrl: string | null;
  coverage: string;
  body: string;
  issuedAt: string;
  expiresAt: string | null;
  verification: AdvisoryVerification;
  verifiedBy: string | null;
  verifiedAt: string | null;
  isSample: boolean;
  affectedZoneIds: string[];
  affectedSegmentIds: string[];
  actionsNote: string;
  createdBy: string;
  createdAt: string;
}

export interface ChecklistItem {
  id: string;
  eventId: string;
  key: string;
  label: string;
  status: ChecklistStatus;
  note: string;
  zoneId: string | null;
  updatedBy: string | null;
  updatedAt: string | null;
}

export interface PlaybookStep {
  title: string;
  detail: string;
  /** Role that must approve/complete the step. */
  approval: 'coordinator' | 'safety_authority' | 'none';
  /** Optional UI action key: assign | compute_route | close_exit | review_routes | record_outcome */
  action?: string;
  dueMinutes?: number;
}

export interface Playbook {
  id: string;
  key: string;
  title: string;
  categories: IncidentCategory[];
  trigger: string;
  escalation: string;
  steps: PlaybookStep[];
}

export interface IncidentAction {
  id: string;
  incidentId: string;
  playbookId: string;
  stepIndex: number;
  title: string;
  detail: string;
  approval: PlaybookStep['approval'];
  action: string | null;
  status: 'pending' | 'done' | 'skipped' | 'overridden';
  dueAt: string | null;
  completedBy: string | null;
  completedAt: string | null;
  note: string;
}

export interface AuditEntry {
  id: number;
  at: string;
  actorId: string | null;
  actorName: string | null;
  actorRole: string | null;
  eventId: string | null;
  action: string;
  entityType: string;
  entityId: string | null;
  details: Record<string, unknown>;
}

// ---------- Risk engine ----------

export interface RiskCondition {
  code: string;
  level: RiskLevel;
  /** Designated critical conditions are never averaged away. */
  critical: boolean;
  message: string;
  source: string;
  observedAt: string | null;
  stale: boolean;
  verified: boolean | null;
}

export interface ZoneRisk {
  zoneId: string;
  level: RiskLevel;
  conditions: RiskCondition[];
  missingInputs: string[];
  occupancy: { value: number | null; capacity: number | null; pct: number | null; observedAt: string | null; source: string | null; stale: boolean; trend: OccupancyTrend };
  /** Informational sorting aid only. NOT a probability and never used to set the level. */
  attentionPoints: number;
  recommendedNextStep: string;
  computedAt: string;
}

export interface OccupancyTrend {
  direction: 'rising' | 'stable' | 'falling' | 'unknown';
  /** People per minute from a least-squares fit over recent readings; null when not enough data. */
  ratePerMin: number | null;
  spanMin: number | null;
  readings: { value: number; observedAt: string; source: string; ageMin: number }[];
}

// ---------- Routing ----------

export interface RouteRequest {
  from: string;
  to: string;
  mode: TravelMode;
  access: AccessLevel;
  avoidUnderReview?: boolean;
}

export interface RouteResult {
  found: boolean;
  from: string;
  to: string;
  mode: TravelMode;
  access: AccessLevel;
  nodeIds: string[];
  segmentIds: string[];
  distanceM: number | null;
  constraints: string[];
  warnings: string[];
  excludedSegments: { id: string; name: string; reason: string }[];
  oldestStatusAt: string | null;
  approvalStatus: 'approved_network' | 'contains_unapproved' | 'none';
  reason: string;
  computedAt: string;
}

export interface NamedRouteValidity {
  routeId: string;
  valid: boolean;
  blockedSegments: { id: string; name: string; status: SegmentStatus; reason: string | null }[];
  reviewSegments: { id: string; name: string; reason: string | null }[];
  alternative: RouteResult | null;
}

export interface Notification {
  id: string;
  level: RiskLevel;
  title: string;
  detail: string;
  link: string;
  at: string;
}
