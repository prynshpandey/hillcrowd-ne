# HillCrowd NE — Architecture

## 1. Components

```
┌──────────────────────────── Browser ────────────────────────────┐
│ Control room (desktop)   Field app (steward)   Responder app     │
│  Overview, Map, Incidents, Routes, Responders, Advisories,       │
│  Setup, Analytics, Settings          ▲ offline outbox (localStorage)
│        │ LiveProvider: snapshot fetch + SSE "change" + polling   │
│        │ Service worker: app shell + map-tile cache (prod build) │
└────────┼─────────────────────────────────────────────────────────┘
         │ JSON over HTTPS (cookie session, X-HillCrowd-Client header)
┌────────▼──────────── Express (server/app.ts) ────────────────────┐
│ auth · Zod validation · permission + event-membership checks     │
│ services/: incidents · assignments · network · operations ·      │
│   risk · resilience · snapshot · analytics · config · demo       │
│ Bus (in-process) → SSE /api/stream                               │
│ 15 s housekeeping: escalations, time-based risk refresh, sessions│
└────────┬──────────────────────────────────────────────────────────┘
         │ node:sqlite (synchronous, transactional)
┌────────▼─────────┐        shared/ (imported by server, client, tests)
│ SQLite database  │        types · constants · permissions · workflow
│ (append-only     │        risk.ts (assessZone, occupancyTrend) · routing.ts
│  triggers)       │        resilience.ts · accountability.ts · geo.ts
└──────────────────┘
```

The risk engine, route engine, workflow and permission matrix live in `shared/` as pure functions. The server is the authority; the client reuses `findRoute` only to preview candidate routes before assignment (the server recomputes on assignment).

## 2. Data flow

1. A steward creates a report in the field app. It is written to the local outbox with a stable client ID and its device creation time, then sent.
2. `POST /api/events/:id/incidents` validates, resolves the zone (explicit or point-in-polygon), flags possible duplicates, stores the incident (`submitted`) and an `incident_updates` row, writes an audit entry, recomputes risk and emits a bus event.
3. SSE clients receive `change` and re-fetch `/api/events/:id/snapshot`, a role-filtered view of the whole event (ops view includes computed risk, route validity, notifications and readiness).
4. The coordinator verifies → a playbook is instantiated as `incident_actions`; risk recomputes; the zone flag explains why.
5. The coordinator assigns a responder → the server computes a route from the responder's base/position to the network node nearest the incident, respecting mode and access, and stores it on the assignment.
6. The responder acknowledges and progresses; each change propagates to the incident status, timestamps and history.
7. Analytics and CSV are computed on demand from incidents, assignments, closures, risk history and the audit log.

## 3. Core entities

| Table | Purpose / key relationships |
|---|---|
| `users`, `sessions`, `event_access` | Accounts (role), hashed session tokens, which events a non-admin may access |
| `events` | Event metadata, NE state/district, map centre/boundary, `settings` JSON (thresholds/time windows), `is_demo` |
| `zones` | Polygon, capacity, watch/elevated/critical %, `exit_ids`, `required_exit_ids` → `facilities`, `comms_fallback` |
| `occupancy_observations` | Time series of estimates with source and reporter |
| `facilities` | Gates, exits, medical, assembly, control, handover; `node_id` → `route_nodes`; open/closed with reason |
| `route_nodes`, `route_segments` | Curated graph; segments have modes, access level, status, approval, constraint/terrain notes, `weather_exposed`, geometry |
| `route_closures` | Every close/review with reason, source, advisory, lifted time |
| `named_routes` | Approved operational routes stored as segment lists (so closures can invalidate them) |
| `incidents` | Report + workflow state + timestamps, `client_id` (unique, idempotency), `merged_into`, `possible_duplicate_of` |
| `incident_updates` | Append-only per-incident history |
| `assignments`, `responders` | Assignment state machine + timestamps + escalation + route snapshot |
| `advisories` | Issuer, source URL, coverage, issue/expiry, verification, `is_sample`, affected zones/segments |
| `checklist_items` | Pre-event assessment with finding status |
| `playbooks`, `incident_actions` | Templates and per-incident steps with approval, due time, outcome |
| `risk_history` | Each change of zone level with reasons |
| `stress_tests` | Recorded resilience scenarios with summary and gaps (readiness evidence) |
| `audit_log` | Operational/admin actions; UPDATE/DELETE rejected by triggers (application-level protection, not tamper-proof against direct file access) |

## 4. Incident state transitions

```
submitted ─▶ under_review ─▶ verified ─▶ assigned ─▶ acknowledged ─▶ in_progress ─▶ resolved ─▶ closed
     └──────────┴──▶ rejected                ▲  (declined/unable)  │                    │
                                             └──────────────────────┘                    │
resolved/closed/rejected ──(reopen, reason required)──▶ under_review ◀──────────────────┘
```

- `assigned / acknowledged / in_progress` are **internal**: they are applied only by the assignment service, never requested directly.
- Reject, resolve, reopen and return-to-in-progress require a note. Field roles have no direct incident transitions.
- With `requireResolutionVerification` (default), a responder's *resolved* waits for a coordinator *close*.
- Assignment flow: `assigned → acknowledged → en_route → on_scene → resolved`, or `declined / unable / cancelled` (note required). If no active assignment remains the incident returns to `verified` for reassignment.
- Escalation: see §6b — any response stage that overruns its target escalates once (history + audit + notification).

## 5. Risk assessment (`shared/risk.ts`)

Per zone, each rule produces zero or more **conditions** `{code, level, critical, message, source, observedAt, stale, verified}`:

| Rule | Level |
|---|---|
| No capacity configured | Watch + missing input |
| No occupancy estimate | `missingOccupancyLevel` (default Watch) + missing input — *never* "empty" |
| Latest estimate older than `staleMinutes` | Watch (figure marked stale) |
| Occupancy ≥ watch / elevated / critical % | Watch / Elevated / **Critical (designated)** |
| Rising trend (least-squares over recent estimates) that projects the elevated threshold within 15 min, or rises ≥10% of capacity per 10 min | Watch (labelled as a projection from manual estimates) |
| Two recent estimates from different sources within 10 min differing by ≥20% of capacity | Watch — contradictory estimates |
| Medical post has no approved walking route into the zone (live network) | Elevated (from the Resilience Engine) |
| Unverified report | Watch, marked unverified |
| Verified incident (congestion, blockage, medical, missing person, route, weather, or confirmed high) | Elevated; others Watch |
| Verified incident confirmed **critical** | **Critical (designated)** |
| ≥ `corroborationMinReporters` *distinct* reporters of the same corroboratable category within the window | Elevated (still unverified) |
| Required exit unavailable / no open foot route from a required exit to any assembly point | **Critical (designated)** |
| Non-required exit unavailable or cut off | Elevated |
| No usable exit at all | **Critical** |
| Active advisory affecting the zone (verified or not; expired ignored) | Watch, with validity text |
| Open pre-event finding linked to the zone | Watch |

**Zone level = max(condition levels).** `attentionPoints` is a sorting aid only and never sets the level; nothing is presented as a probability. Each level change is stored in `risk_history` and the audit log. Time-based changes (staleness, expiry) are picked up by the 15 s housekeeping refresh.

## 5b. Crowd trends

`occupancyTrend` fits a straight line to the zone's estimates in the last max(30 min, 2 × stale threshold) and labels the trend rising, stable (|rate| < 2% of capacity per 10 min) or falling, with rate, span and the readings and their ages. With fewer than two readings, or less than 2 minutes between them, the trend is *unknown*. These are manual timestamped estimates; nothing is presented as a forecast or measured density.

## 6. Routing (`shared/routing.ts`)

- Graph: `route_nodes` + approved `route_segments` (bidirectional), configured distance as weight.
- Filters per request: exclude `closed`, unapproved, wrong mode, insufficient access (`public < staff < emergency`), and optionally `under_review`. Excluded segments are reported with reasons; under-review segments that are used produce warnings.
- Dijkstra (deterministic tie-break). If the destination is unreachable the result is `found: false` with an escalation message — **no route is invented**.
- Results carry origin/destination, segments, distance, mode, constraints, warnings, oldest status timestamp (freshness) and approval status.
- `validateNamedRoutes` marks approved routes invalid when any segment is closed/unusable and searches an alternative with the same mode and access.
- Egress check used by the risk engine: foot/public reachability from each exit node to any open assembly point.

## 6a. Route Resilience Engine (`shared/resilience.ts`)

- **Critical access links** are generated from configuration:
  - each zone's exits → any assembly point (foot, public);
  - each medical post → each zone's nodes (foot, staff);
  - handover point ↔ medical post (vehicle, emergency), when no approved route already covers it;
  - every approved operational route.
- **Plan analysis** (all approved segments open):
  - *redundancy* — the number of segment-disjoint approved routes, capped at 3;
  - *single points of failure* — segments whose removal alone disconnects the link;
  - *second-failure exposure* — segment pairs, drawn from the best route and its first alternative, that disconnect a link with no single point of failure.
- **Scenario analysis** applies, on top of live status:
  - simulated segment closures, optionally with every `weather_exposed` segment closed;
  - closed facilities (their nodes cannot be used as sources);
  - unavailable responders;
  - zones with lost mobile data.

  Each link is then *ok* (planned route), *detour* (the extra distance plus added and removed segments with modes, access, constraints and terrain notes), or *lost* ("No approved route available").
- **Coverage:** for each zone, which available medical and steward teams can reach it from their base on an approved route. **Comms:** whether a fallback is recorded for each zone where mobile data fails.
- **Gaps** are listed by severity. A clean result says it covers only the tested failures and is not a safety certification.
- **Uses:** the Resilience Lab (`POST /resilience/simulate`, never writes), stress tests (`POST /stress-tests`, stored in `stress_tests`), live access-gap alerts in the snapshot, and the `MEDICAL_ACCESS_LOST` risk condition.

## 6b. Response accountability (`shared/accountability.ts`)

- **Stages:** verify (received→verified), assign (verified→assigned), accept (assigned→acknowledged), arrive (acknowledged→on scene), resolve (on scene→resolved) and confirm (resolved→closed).
- **Targets** come from `settings.responseTargets[severity]`, overridden by `settings.categoryTargets[category]` (e.g. medical acceptance 2 min).
- Acceptance, travel and on-scene stages follow the *current* assignment, so a reassignment restarts them.
- **Output:** the current stage, elapsed time against target, whether it's overdue, who acts next (control room or the named responder) and the next action.
- **Escalation:** `runEscalations` (every 15 s) escalates each overrunning stage once, keyed per stage, and per assignment for acceptance.
- **After a decline or "unable":** the incident returns to *verified* and the server records a route-feasibility recheck for every available team.

## 7. Permission model (`shared/permissions.ts`)

A static permission → roles matrix used by both server (enforcement) and client (hiding controls). Highlights: only admins configure zones, segments, facilities, playbooks, users and verify mitigations; coordinators verify/assign/close/merge, change segment and exit *status*, manage advisories and run the demo; stewards create reports and occupancy estimates; responders (and stewards linked to a team) update only their own assignments. Non-admins must also hold `event_access` for the event. Admins cannot change their own role; role changes revoke sessions.

## 8. Offline behaviour

- **Outbox** (`client/src/lib/outbox.ts`):
  - Items get a client ID and local creation time.
  - Internal states are `queued → sending → delivered | failed | rejected`.
  - Users see four of them: *Saved on device*, *Waiting to sync*, *Server confirmed*, and *Sync failed — action required* (rejected, or 3 or more failed attempts).
  - The time of the last successful sync is stored and shown.
  - Only a server response marks an item delivered, and it records the server receipt time.
  - Network and 5xx errors retry, on reconnect and every 15 s. 4xx validation errors become `rejected` and are not retried.
  - Concurrent flushes share one run.
  - The server treats a repeated client ID from the same user as the same submission (HTTP 200, `duplicateSubmission: true`).
- **Map honesty**: a status chip on the map states whether tiles loaded or the fallback grid is in use, and whether venue data is live or a cached copy.
- **Snapshot cache**: the last snapshot is kept in localStorage and shown marked "cached copy"/stale if the server is unreachable.
- **Service worker** (production build): network-first app shell, cache-first hashed assets and map tiles (capped). API responses are deliberately not cached by the service worker.
- The control room cannot see a report until it is synchronised; the UI says so.

## 9. External integrations

| Integration | Status |
|---|---|
| OpenStreetMap tiles | Used for basemap with attribution; app falls back to a schematic view if tiles fail |
| OpenTopoMap tiles | Optional terrain-context layer (contours, CC-BY-SA); context only |
| Official weather/disaster advisories | **Not integrated.** Manual entry + verification. No scraping, no fake live data |
| GPS / CAD / ambulance dispatch / SMS | Not integrated |
