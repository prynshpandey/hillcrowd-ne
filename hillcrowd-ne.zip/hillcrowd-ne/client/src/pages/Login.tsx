import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogIn } from 'lucide-react';
import { api } from '../lib/api';
import { useSession } from '../lib/session';
import { ROLE_LABEL } from '@shared/permissions';
import { Notice } from '../components/ui';
import { t } from '../i18n';
import type { Role } from '@shared/types';

interface DemoAccounts {
  enabled: boolean;
  password?: string;
  accounts: { username: string; displayName: string; role: Role }[];
}

export default function LoginPage() {
  const { login } = useSession();
  const nav = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [demo, setDemo] = useState<DemoAccounts | null>(null);

  useEffect(() => {
    api.get<DemoAccounts>('/api/demo/accounts').then(setDemo).catch(() => setDemo(null));
  }, []);

  const submit = async (u = username, p = password) => {
    setBusy(true);
    setErr(null);
    try {
      const user = await login(u, p);
      nav(user.role === 'steward' ? '/field' : user.role === 'responder' ? '/respond' : '/overview', { replace: true });
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Sign-in failed');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="login">
      <div className="login-art" aria-hidden>
        <svg viewBox="0 0 600 400" preserveAspectRatio="xMidYMid slice">
          <defs>
            <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#0f2a22" />
              <stop offset="1" stopColor="#1d4a3a" />
            </linearGradient>
          </defs>
          <rect width="600" height="400" fill="url(#sky)" />
          {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
            <path key={i} d={`M0 ${300 - i * 22} C 120 ${250 - i * 26}, 200 ${310 - i * 20}, 300 ${255 - i * 24} S 480 ${200 - i * 22}, 600 ${260 - i * 20}`} fill="none" stroke="#e8efe9" strokeOpacity={0.08 + i * 0.015} strokeWidth="1.2" />
          ))}
          <path d="M0 400 L0 300 L90 220 L160 280 L250 170 L340 260 L420 200 L520 290 L600 240 L600 400 Z" fill="#163d30" />
          <path d="M0 400 L0 340 L120 280 L220 330 L330 270 L430 330 L600 300 L600 400 Z" fill="#1b4a3a" />
        </svg>
        <div className="login-art-text">
          <h1>{t('app.name')}</h1>
          <p>{t('app.tagline')}</p>
          <ul>
            <li>Terrain-aware venue map with approved routes and closures</li>
            <li>Structured field reports → verify → prioritise → assign → resolve</li>
            <li>Explainable risk flags and post-event review</li>
          </ul>
          <p className="login-region">Designed first for Meghalaya; configurable across Northeast India.</p>
        </div>
      </div>
      <div className="login-panel">
        <form
          className="login-form"
          onSubmit={(e) => {
            e.preventDefault();
            submit();
          }}
        >
          <h2>Sign in</h2>
          <p className="muted">For authorised event personnel.</p>
          <label className="field">
            <span>Username</span>
            <input autoComplete="username" value={username} onChange={(e) => setUsername(e.target.value)} required />
          </label>
          <label className="field">
            <span>Password</span>
            <input type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </label>
          {err && <Notice tone="danger">{err}</Notice>}
          <button className="btn btn-primary btn-block" disabled={busy}>
            <LogIn size={16} /> {busy ? 'Signing in…' : 'Sign in'}
          </button>
        </form>

        {demo?.enabled && (
          <div className="demo-access">
            <div className="demo-access-head">
              <span className="demo-badge">DEMO ACCESS</span>
              <span>Seeded demonstration accounts — password <code>{demo.password}</code></span>
            </div>
            <p className="muted small">These accounts exist only because the server runs with DEMO_MODE enabled. They sign in through the normal password check.</p>
            <div className="demo-accounts">
              {demo.accounts.map((a) => (
                <button key={a.username} className="demo-acct" onClick={() => submit(a.username, demo.password!)} disabled={busy}>
                  <strong>{a.displayName}</strong>
                  <span>
                    {ROLE_LABEL[a.role]} · <code>{a.username}</code>
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}
        <p className="disclaimer small">{t('app.disclaimer')}</p>
      </div>
    </div>
  );
}
