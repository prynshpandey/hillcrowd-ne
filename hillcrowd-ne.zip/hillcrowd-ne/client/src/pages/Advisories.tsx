import { useState } from 'react';
import { ExternalLink, Plus } from 'lucide-react';
import { useLive } from '../lib/live';
import { useSession } from '../lib/session';
import { api } from '../lib/api';
import { can } from '@shared/permissions';
import type { Advisory } from '@shared/types';
import { Card, Empty, Modal, Notice, ReasonDialog, useAction } from '../components/ui';
import { fmtDateTime } from '../lib/format';

function validity(a: Advisory) {
  if (!a.expiresAt) return { label: 'Validity unknown', tone: 'warn' };
  if (new Date(a.expiresAt) < new Date()) return { label: `Expired ${fmtDateTime(a.expiresAt)}`, tone: 'muted' };
  return { label: `Valid until ${fmtDateTime(a.expiresAt)}`, tone: 'ok' };
}

export default function AdvisoriesPage() {
  const { snap, reload } = useLive();
  const { me } = useSession();
  const s = snap!;
  const role = me!.user.role;
  const [creating, setCreating] = useState(false);
  const [dialog, setDialog] = useState<React.ReactNode>(null);
  const zones = new Map(s.zones.map((z) => [z.id, z.name]));
  const segs = new Map(s.segments.map((x) => [x.id, x.name]));

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h1>Official alerts & weather context</h1>
          <p className="muted">Manual entry and verification of advisories, with source and validity. HillCrowd NE does not forecast weather and does not replace IMD, SDMA or other official warning systems.</p>
        </div>
        {can(role, 'advisory.create') && (
          <button className="btn btn-primary" onClick={() => setCreating(true)}>
            <Plus size={15} /> Enter advisory
          </button>
        )}
      </div>
      <Notice tone="info" title="No live official feed is connected.">
        This prototype does not integrate an official advisory API. Enter advisories from official channels manually and verify them against the issuing agency. Sample advisories used in the demo are labelled SAMPLE and are not real warnings.
      </Notice>
      {s.advisories.length === 0 && <Empty>No advisories recorded for this event.</Empty>}
      <div className="adv-list">
        {s.advisories.map((a) => {
          const v = validity(a);
          return (
            <Card
              key={a.id}
              className={`adv adv-${a.verification}`}
              title={
                <>
                  {a.isSample && <span className="tag tag-sample">SAMPLE — NOT A REAL WARNING</span>} {a.title}
                </>
              }
              subtitle={
                <>
                  Issued by <strong>{a.issuer}</strong> · {fmtDateTime(a.issuedAt)} · <span className={`text-${v.tone}`}>{v.label}</span>
                </>
              }
              actions={
                <span className={`chip ${a.verification === 'verified' ? 'chip-verified' : a.verification === 'rejected' ? 'chip-muted' : 'chip-unverified'}`}>{a.verification.toUpperCase()}</span>
              }
            >
              {a.body && <p>{a.body}</p>}
              <dl className="kv">
                <dt>Coverage</dt>
                <dd>{a.coverage}</dd>
                <dt>Source</dt>
                <dd>
                  {a.sourceUrl ? (
                    <a href={a.sourceUrl} target="_blank" rel="noopener noreferrer">
                      {a.sourceUrl} <ExternalLink size={12} />
                    </a>
                  ) : (
                    <span className="muted">No source URL recorded</span>
                  )}
                </dd>
                <dt>Affected zones</dt>
                <dd>{a.affectedZoneIds.map((z) => zones.get(z)).join(', ') || '—'}</dd>
                <dt>Affected route segments</dt>
                <dd>{a.affectedSegmentIds.map((x) => segs.get(x)).join(', ') || '—'}</dd>
                {a.actionsNote && (
                  <>
                    <dt>Associated actions</dt>
                    <dd>{a.actionsNote}</dd>
                  </>
                )}
                {a.verifiedAt && (
                  <>
                    <dt>Verification</dt>
                    <dd>
                      {a.verification} at {fmtDateTime(a.verifiedAt)}
                    </dd>
                  </>
                )}
              </dl>
              {can(role, 'advisory.verify') && a.verification === 'unverified' && (
                <div className="btn-row">
                  <button
                    className="btn btn-primary"
                    onClick={() =>
                      setDialog(
                        <ReasonDialog
                          title="Verify advisory"
                          label="How was it verified against the issuing agency?"
                          extra={<p className="small">Verifying marks the affected open route segments as “under review”. It does not close roads or issue any public instruction.</p>}
                          onSubmit={(n) => api.post(`/api/advisories/${a.id}/verification`, { verification: 'verified', note: n }).then(reload)}
                          onClose={() => setDialog(null)}
                        />,
                      )
                    }
                  >
                    Verify
                  </button>
                  <button className="btn btn-danger-ghost" onClick={() => setDialog(<ReasonDialog title="Reject advisory" required tone="danger" onSubmit={(n) => api.post(`/api/advisories/${a.id}/verification`, { verification: 'rejected', note: n }).then(reload)} onClose={() => setDialog(null)} />)}>
                    Reject
                  </button>
                </div>
              )}
            </Card>
          );
        })}
      </div>
      {creating && <AdvisoryForm onClose={() => setCreating(false)} />}
      {dialog}
    </div>
  );
}

function toLocalInput(d: Date) {
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
}

function AdvisoryForm({ onClose }: { onClose: () => void }) {
  const { snap, reload } = useLive();
  const run = useAction();
  const s = snap!;
  const [f, setF] = useState({
    title: '',
    issuer: '',
    sourceUrl: '',
    coverage: `${s.event.district} district`,
    body: '',
    issuedAt: toLocalInput(new Date()),
    expiresAt: '',
    zones: [] as string[],
    segs: [] as string[],
    actionsNote: '',
    isSample: false,
  });
  const set = (k: keyof typeof f, v: unknown) => setF((x) => ({ ...x, [k]: v }));
  const toggle = (k: 'zones' | 'segs', id: string) => set(k, f[k].includes(id) ? f[k].filter((x) => x !== id) : [...f[k], id]);
  return (
    <Modal title="Enter advisory" onClose={onClose} wide>
      <form
        className="form-grid two"
        onSubmit={async (e) => {
          e.preventDefault();
          const ok = await run(
            () =>
              api.post(`/api/events/${s.event.id}/advisories`, {
                title: f.title,
                issuer: f.issuer,
                sourceUrl: f.sourceUrl || null,
                coverage: f.coverage,
                body: f.body,
                issuedAt: new Date(f.issuedAt).toISOString(),
                expiresAt: f.expiresAt ? new Date(f.expiresAt).toISOString() : null,
                affectedZoneIds: f.zones,
                affectedSegmentIds: f.segs,
                actionsNote: f.actionsNote,
                isSample: f.isSample,
              }),
            'Advisory recorded (unverified)',
          );
          if (ok) {
            await reload();
            onClose();
          }
        }}
      >
        <label className="field span2">
          <span>Advisory title</span>
          <input required value={f.title} onChange={(e) => set('title', e.target.value)} maxLength={200} />
        </label>
        <label className="field">
          <span>Issuing organisation</span>
          <input required value={f.issuer} onChange={(e) => set('issuer', e.target.value)} placeholder="As stated on the official advisory" />
        </label>
        <label className="field">
          <span>
            Source URL <em className="opt">optional</em>
          </span>
          <input type="url" value={f.sourceUrl} onChange={(e) => set('sourceUrl', e.target.value)} placeholder="https://…" />
        </label>
        <label className="field">
          <span>Geographic coverage</span>
          <input required value={f.coverage} onChange={(e) => set('coverage', e.target.value)} />
        </label>
        <label className="field">
          <span>Issue time</span>
          <input type="datetime-local" required value={f.issuedAt} onChange={(e) => set('issuedAt', e.target.value)} />
        </label>
        <label className="field">
          <span>
            Expiry <em className="opt">leave blank if not stated — shown as “validity unknown”</em>
          </span>
          <input type="datetime-local" value={f.expiresAt} onChange={(e) => set('expiresAt', e.target.value)} />
        </label>
        <label className="check">
          <input type="checkbox" checked={f.isSample} onChange={(e) => set('isSample', e.target.checked)} /> This is a SAMPLE / training advisory
        </label>
        <label className="field span2">
          <span>Advisory text</span>
          <textarea rows={3} value={f.body} onChange={(e) => set('body', e.target.value)} />
        </label>
        <fieldset className="span2 pick">
          <legend>Affected zones</legend>
          {s.zones.map((z) => (
            <label key={z.id} className="check">
              <input type="checkbox" checked={f.zones.includes(z.id)} onChange={() => toggle('zones', z.id)} /> {z.name}
            </label>
          ))}
        </fieldset>
        <fieldset className="span2 pick">
          <legend>Affected route segments (marked “under review” when verified)</legend>
          <div className="pick-grid">
            {s.segments.map((x) => (
              <label key={x.id} className="check">
                <input type="checkbox" checked={f.segs.includes(x.id)} onChange={() => toggle('segs', x.id)} /> {x.name}
              </label>
            ))}
          </div>
        </fieldset>
        <label className="field span2">
          <span>Associated actions</span>
          <input value={f.actionsNote} onChange={(e) => set('actionsNote', e.target.value)} placeholder="e.g. Inspect lower service road" />
        </label>
        <div className="modal-actions span2">
          <button type="button" className="btn" onClick={onClose}>
            Cancel
          </button>
          <button className="btn btn-primary">Record advisory</button>
        </div>
      </form>
    </Modal>
  );
}
