import { useState } from 'react';
import { Lock, Plus } from 'lucide-react';
import { useLive } from '../lib/live';
import { useSession } from '../lib/session';
import { api } from '../lib/api';
import { can } from '@shared/permissions';
import { CATEGORIES, EVENT_TYPES, NE_STATES, SEVERITIES, STAGE_KEYS, STAGE_LABEL } from '@shared/constants';
import { offsetM } from '@shared/geo';
import type { AccessLevel, ChecklistItem, ChecklistStatus, EventSettings, FacilityKind, IncidentCategory, Playbook, PlaybookStep, RouteSegment, Severity, StageTargets, TravelMode, Zone } from '@shared/types';
import { Card, Modal, Notice, useAction } from '../components/ui';
import { VenueMap } from '../components/VenueMap';
import { fmtDateTime, metres } from '../lib/format';

type Tab = 'event' | 'checklist' | 'zones' | 'network' | 'routes' | 'playbooks';

const CHECK_LABEL: Record<ChecklistStatus, string> = {
  not_assessed: 'Not assessed',
  no_issue: 'Assessed — no issue',
  issue_identified: 'Issue identified',
  mitigation_planned: 'Mitigation planned (not verified)',
  mitigation_verified: 'Mitigation verified',
};

export default function SetupPage() {
  const { me } = useSession();
  const [tab, setTab] = useState<Tab>('event');
  const admin = can(me!.user.role, 'event.configure');
  return (
    <div className="page setup">
      <div className="page-head">
        <div>
          <h1>Event setup & pre-event risk planning</h1>
          <p className="muted">Venue configuration, thresholds, approved routes and response playbooks. Local conditions (steep approaches, rain-affected or flood-prone sections) must be entered from verified site information — nothing is inferred from location alone.</p>
        </div>
        {can(me!.user.role, 'event.create') && <NewEventButton />}
      </div>
      {!admin && (
        <Notice tone="info">
          <Lock size={14} /> Read-only for your role, except the readiness checklist. Configuration changes require an administrator and are recorded in the audit log.
        </Notice>
      )}
      <div className="tabs" role="tablist">
        {(
          [
            ['event', 'Event & rules'],
            ['checklist', 'Readiness checklist'],
            ['zones', 'Zones & thresholds'],
            ['network', 'Facilities & route network'],
            ['routes', 'Approved routes'],
            ['playbooks', 'Playbooks'],
          ] as [Tab, string][]
        ).map(([k, l]) => (
          <button key={k} role="tab" aria-selected={tab === k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>
            {l}
          </button>
        ))}
      </div>
      {tab === 'event' && <EventTab admin={admin} />}
      {tab === 'checklist' && <ChecklistTab />}
      {tab === 'zones' && <ZonesTab admin={admin} />}
      {tab === 'network' && <NetworkTab admin={admin} />}
      {tab === 'routes' && <NamedRoutesTab admin={admin} />}
      {tab === 'playbooks' && <PlaybooksTab admin={can(me!.user.role, 'playbook.configure')} />}
    </div>
  );
}

const toLocal = (iso: string) => {
  const d = new Date(iso);
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
};

function EventTab({ admin }: { admin: boolean }) {
  const { snap, reload } = useLive();
  const run = useAction();
  const e = snap!.event;
  const [f, setF] = useState({ ...e, startsAt: toLocal(e.startsAt), endsAt: toLocal(e.endsAt) });
  const [st, setSt] = useState<EventSettings>(e.settings);
  const set = (k: string, v: unknown) => setF((x) => ({ ...x, [k]: v }));
  const num = (v: string) => (v === '' ? null : Number(v));
  return (
    <div className="grid-2">
      <Card title="Event details">
        <form
          className="form-grid two"
          onSubmit={(ev) => {
            ev.preventDefault();
            run(
              () =>
                api
                  .patch(`/api/events/${e.id}`, {
                    name: f.name,
                    eventType: f.eventType,
                    state: f.state,
                    district: f.district,
                    locationLabel: f.locationLabel,
                    venueName: f.venueName,
                    venueIsFictional: f.venueIsFictional,
                    startsAt: new Date(f.startsAt).toISOString(),
                    endsAt: new Date(f.endsAt).toISOString(),
                    expectedAttendance: f.expectedAttendance,
                    venueCapacity: f.venueCapacity,
                    controlContact: f.controlContact,
                  })
                  .then(reload),
              'Event updated',
            );
          }}
        >
          <fieldset disabled={!admin} className="contents">
            <label className="field span2">
              <span>Event name</span>
              <input value={f.name} onChange={(x) => set('name', x.target.value)} />
            </label>
            <label className="field">
              <span>Event type</span>
              <select value={f.eventType} onChange={(x) => set('eventType', x.target.value)}>
                {EVENT_TYPES.map((t) => (
                  <option key={t}>{t}</option>
                ))}
              </select>
            </label>
            <label className="field">
              <span>State</span>
              <select value={f.state} onChange={(x) => set('state', x.target.value)}>
                {NE_STATES.map((t) => (
                  <option key={t}>{t}</option>
                ))}
              </select>
            </label>
            <label className="field">
              <span>District</span>
              <input value={f.district} onChange={(x) => set('district', x.target.value)} />
            </label>
            <label className="field">
              <span>Location label</span>
              <input value={f.locationLabel} onChange={(x) => set('locationLabel', x.target.value)} />
            </label>
            <label className="field">
              <span>Venue name</span>
              <input value={f.venueName} onChange={(x) => set('venueName', x.target.value)} />
            </label>
            <label className="check">
              <input type="checkbox" checked={f.venueIsFictional} onChange={(x) => set('venueIsFictional', x.target.checked)} /> Venue layout is fictional / demonstration
            </label>
            <label className="field">
              <span>Starts</span>
              <input type="datetime-local" value={f.startsAt} onChange={(x) => set('startsAt', x.target.value)} />
            </label>
            <label className="field">
              <span>Ends</span>
              <input type="datetime-local" value={f.endsAt} onChange={(x) => set('endsAt', x.target.value)} />
            </label>
            <label className="field">
              <span>Expected attendance</span>
              <input type="number" min={0} value={f.expectedAttendance ?? ''} onChange={(x) => set('expectedAttendance', num(x.target.value))} />
            </label>
            <label className="field">
              <span>Configured venue capacity</span>
              <input type="number" min={0} value={f.venueCapacity ?? ''} onChange={(x) => set('venueCapacity', num(x.target.value))} />
            </label>
            <label className="field span2">
              <span>Control-room contact (as configured)</span>
              <input value={f.controlContact} onChange={(x) => set('controlContact', x.target.value)} placeholder="e.g. radio channel; do not enter unverified phone numbers" />
            </label>
            {admin && <button className="btn btn-primary">Save event details</button>}
          </fieldset>
        </form>
      </Card>
      <Card title="Risk-engine and workflow rules" subtitle="Validate these against the event's approved safety plan. They are configuration, not universal safety rules.">
        <form
          className="form-grid two"
          onSubmit={(ev) => {
            ev.preventDefault();
            run(() => api.patch(`/api/events/${e.id}`, { settings: st }).then(reload), 'Rules updated');
          }}
        >
          <fieldset disabled={!admin} className="contents">
            {(
              [
                ['staleMinutes', 'Information is stale after (min)'],
                ['duplicateWindowMinutes', 'Duplicate-report window (min)'],
                ['duplicateRadiusM', 'Duplicate-report radius (m)'],
                ['corroborationWindowMinutes', 'Corroboration window (min)'],
                ['corroborationMinReporters', 'Independent reporters for corroboration'],
              ] as [keyof EventSettings, string][]
            ).map(([k, l]) => (
              <label key={k} className="field">
                <span>{l}</span>
                <input type="number" min={1} value={st[k] as number} onChange={(x) => setSt((s) => ({ ...s, [k]: Number(x.target.value) }))} />
              </label>
            ))}
            <label className="field">
              <span>Level when occupancy is missing</span>
              <select value={st.missingOccupancyLevel} onChange={(x) => setSt((s) => ({ ...s, missingOccupancyLevel: x.target.value as EventSettings['missingOccupancyLevel'] }))}>
                <option value="watch">Watch (recommended)</option>
                <option value="elevated">Elevated</option>
                <option value="normal">Normal (gap still listed)</option>
              </select>
            </label>
            <label className="check span2">
              <input type="checkbox" checked={st.requireResolutionVerification} onChange={(x) => setSt((s) => ({ ...s, requireResolutionVerification: x.target.checked }))} /> Responder “resolved” must be confirmed by the control room before closing
            </label>
            {admin && <button className="btn btn-primary">Save rules</button>}
          </fieldset>
        </form>
      </Card>
      <ResponseTargetsCard admin={admin} />
    </div>
  );
}

function ResponseTargetsCard({ admin }: { admin: boolean }) {
  const { snap, reload } = useLive();
  const run = useAction();
  const e = snap!.event;
  const [rt, setRt] = useState(e.settings.responseTargets);
  const [ct, setCt] = useState(e.settings.categoryTargets);
  const setT = (sev: Severity, k: keyof StageTargets, v: number) => setRt((x) => ({ ...x, [sev]: { ...x[sev], [k]: v } }));
  const setC = (cat: IncidentCategory, k: keyof StageTargets, v: string) =>
    setCt((x) => {
      const cur = { ...(x[cat] ?? {}) };
      if (v === '') delete cur[k];
      else cur[k] = Number(v);
      return { ...x, [cat]: cur };
    });
  return (
    <Card className="span-all" title="Response targets" subtitle="Minutes allowed for each stage, by confirmed severity. A stage that overruns escalates once and names who must act next. Targets are planning aids agreed with the safety officer — not performance scores.">
      <div className="table-wrap">
        <table className="table compact targets">
          <thead>
            <tr>
              <th>Severity</th>
              {STAGE_KEYS.map((k) => (
                <th key={k}>{STAGE_LABEL[k]}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {SEVERITIES.map((sev) => (
              <tr key={sev}>
                <td className={`sev-cell sev-${sev}`}>{sev}</td>
                {STAGE_KEYS.map((k) => (
                  <td key={k}>
                    <input type="number" min={1} max={600} disabled={!admin} value={rt[sev][k]} onChange={(x) => setT(sev, k, Number(x.target.value))} aria-label={`${sev} ${STAGE_LABEL[k]} minutes`} />
                  </td>
                ))}
              </tr>
            ))}
            {CATEGORIES.filter((c) => ['medical', 'exit_blockage', 'missing_person'].includes(c.key)).map((c) => (
              <tr key={c.key} className="override-row">
                <td>
                  <strong>{c.short}</strong>
                  <div className="tiny muted">override, all severities</div>
                </td>
                {STAGE_KEYS.map((k) => (
                  <td key={k}>
                    <input type="number" min={1} max={600} disabled={!admin} placeholder="—" value={ct[c.key]?.[k] ?? ''} onChange={(x) => setC(c.key, k, x.target.value)} aria-label={`${c.short} ${STAGE_LABEL[k]} override`} />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {admin && (
        <button className="btn btn-primary" onClick={() => run(() => api.patch(`/api/events/${e.id}`, { settings: { responseTargets: rt, categoryTargets: ct } }).then(reload), 'Response targets saved')}>
          Save response targets
        </button>
      )}
    </Card>
  );
}

function ChecklistTab() {
  const { snap, reload } = useLive();
  const { me } = useSession();
  const [edit, setEdit] = useState<ChecklistItem | null>(null);
  const s = snap!;
  const r = s.readiness!;
  return (
    <>
      <Card title="Event-readiness summary">
        <p>{r.statement}</p>
        <div className="readiness-counts">
          <span>Mitigation verified: {r.mitigationVerified}</span>
          <span>No issue: {r.noIssue}</span>
          <span>Mitigation planned: {r.mitigationPlanned}</span>
          <span>Issue identified: {r.issuesIdentified}</span>
          <span>Not assessed: {r.notAssessed}</span>
        </div>
      </Card>
      <Card title="Venue risk assessment checklist" subtitle="“Completed” is not “safe”: an item records either no issue, an identified issue, a planned mitigation, or a mitigation verified by the safety lead.">
        <table className="table">
          <thead>
            <tr>
              <th>Item</th>
              <th>Status</th>
              <th>Finding / mitigation</th>
              <th>Linked zone</th>
              <th>Updated</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {(s.checklist ?? []).map((c) => (
              <tr key={c.id}>
                <td>{c.label}</td>
                <td>
                  <span className={`chip ${c.status === 'mitigation_verified' || c.status === 'no_issue' ? 'chip-ok' : c.status === 'issue_identified' ? 'chip-danger' : c.status === 'mitigation_planned' ? 'chip-warn' : 'chip-muted'}`}>{CHECK_LABEL[c.status]}</span>
                </td>
                <td className="small">{c.note || <span className="muted">—</span>}</td>
                <td className="small">{s.zones.find((z) => z.id === c.zoneId)?.name ?? '—'}</td>
                <td className="small">{fmtDateTime(c.updatedAt)}</td>
                <td>
                  {can(me!.user.role, 'checklist.update') && (
                    <button className="btn btn-sm btn-ghost" onClick={() => setEdit(c)}>
                      Update
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
      {edit && <ChecklistDialog item={edit} onClose={() => setEdit(null)} onDone={reload} />}
    </>
  );
}

function ChecklistDialog({ item, onClose, onDone }: { item: ChecklistItem; onClose: () => void; onDone: () => Promise<void> }) {
  const { snap } = useLive();
  const { me } = useSession();
  const run = useAction();
  const [status, setStatus] = useState<ChecklistStatus>(item.status);
  const [note, setNote] = useState(item.note);
  const [zoneId, setZoneId] = useState(item.zoneId ?? '');
  return (
    <Modal title={item.label} onClose={onClose}>
      <label className="field">
        <span>Status</span>
        <select value={status} onChange={(e) => setStatus(e.target.value as ChecklistStatus)}>
          {(Object.keys(CHECK_LABEL) as ChecklistStatus[]).map((k) => (
            <option key={k} value={k} disabled={k === 'mitigation_verified' && !can(me!.user.role, 'checklist.verifyMitigation')}>
              {CHECK_LABEL[k]}
              {k === 'mitigation_verified' && !can(me!.user.role, 'checklist.verifyMitigation') ? ' (administrator only)' : ''}
            </option>
          ))}
        </select>
      </label>
      <label className="field">
        <span>Finding / mitigation note</span>
        <textarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} />
      </label>
      <label className="field">
        <span>Linked zone (open findings feed that zone's risk assessment)</span>
        <select value={zoneId} onChange={(e) => setZoneId(e.target.value)}>
          <option value="">None</option>
          {snap!.zones.map((z) => (
            <option key={z.id} value={z.id}>
              {z.name}
            </option>
          ))}
        </select>
      </label>
      <div className="modal-actions">
        <button className="btn" onClick={onClose}>
          Cancel
        </button>
        <button
          className="btn btn-primary"
          onClick={async () => {
            const ok = await run(() => api.patch(`/api/checklist/${item.id}`, { status, note, zoneId: zoneId || null }).then(onDone), 'Checklist updated');
            if (ok !== undefined) onClose();
          }}
        >
          Save
        </button>
      </div>
    </Modal>
  );
}

function ZonesTab({ admin }: { admin: boolean }) {
  const { snap } = useLive();
  const [edit, setEdit] = useState<Zone | 'new' | null>(null);
  const s = snap!;
  const fac = (id: string) => s.facilities.find((f) => f.id === id)?.name ?? id;
  return (
    <Card title="Crowd-monitoring zones" actions={admin && <button className="btn btn-sm btn-primary" onClick={() => setEdit('new')}><Plus size={14} /> Add zone</button>}>
      <table className="table">
        <thead>
          <tr>
            <th>Zone</th>
            <th>Capacity</th>
            <th>Thresholds (watch / elevated / critical)</th>
            <th>Exits (required in bold)</th>
            <th />
          </tr>
        </thead>
        <tbody>
          {s.zones.map((z) => (
            <tr key={z.id}>
              <td>
                {z.name}
                <div className="tiny muted">{z.notes}</div>
              </td>
              <td>{z.capacity?.toLocaleString('en-IN') ?? <span className="text-warn">not set</span>}</td>
              <td>
                {z.watchPct}% / {z.elevatedPct}% / {z.criticalPct ?? '—'}%
                <div className={`tiny ${z.commsFallback ? 'muted' : 'text-warn'}`}>Comms fallback: {z.commsFallback || 'none recorded'}</div>
              </td>
              <td className="small">
                {z.exitIds.map((id) => (
                  <div key={id}>{z.requiredExitIds.includes(id) ? <strong>{fac(id)} (required)</strong> : fac(id)}</div>
                ))}
              </td>
              <td>{admin && <button className="btn btn-sm btn-ghost" onClick={() => setEdit(z)}>Edit</button>}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {edit && <ZoneDialog zone={edit === 'new' ? null : edit} onClose={() => setEdit(null)} />}
    </Card>
  );
}

function ZoneDialog({ zone, onClose }: { zone: Zone | null; onClose: () => void }) {
  const { snap, reload } = useLive();
  const run = useAction();
  const s = snap!;
  const exits = s.facilities.filter((f) => f.kind === 'gate' || f.kind === 'exit');
  const [f, setF] = useState({
    name: zone?.name ?? '',
    capacity: zone?.capacity ?? 1000,
    watchPct: zone?.watchPct ?? 80,
    elevatedPct: zone?.elevatedPct ?? 95,
    criticalPct: zone?.criticalPct ?? 110,
    exitIds: zone?.exitIds ?? [],
    requiredExitIds: zone?.requiredExitIds ?? [],
    notes: zone?.notes ?? '',
    commsFallback: zone?.commsFallback ?? '',
    center: null as [number, number] | null,
    widthM: 100,
    heightM: 80,
  });
  const set = (k: string, v: unknown) => setF((x) => ({ ...x, [k]: v }));
  const toggle = (k: 'exitIds' | 'requiredExitIds', id: string) => set(k, f[k].includes(id) ? f[k].filter((x) => x !== id) : [...f[k], id]);
  const save = async () => {
    const body: Record<string, unknown> = {
      name: f.name,
      capacity: f.capacity,
      watchPct: f.watchPct,
      elevatedPct: f.elevatedPct,
      criticalPct: f.criticalPct,
      exitIds: f.exitIds,
      requiredExitIds: f.requiredExitIds.filter((x) => f.exitIds.includes(x)),
      notes: f.notes,
      commsFallback: f.commsFallback,
    };
    if (!zone) {
      if (!f.center) throw new Error('Click the map to place the zone centre.');
      const [c, w, h] = [f.center, f.widthM / 2, f.heightM / 2];
      body.polygon = [offsetM(c, -w, -h), offsetM(c, w, -h), offsetM(c, w, h), offsetM(c, -w, h)];
      await api.post(`/api/events/${s.event.id}/zones`, body);
    } else await api.patch(`/api/zones/${zone.id}`, body);
    await reload();
    onClose();
  };
  return (
    <Modal title={zone ? `Edit ${zone.name}` : 'Add zone'} onClose={onClose} wide>
      <div className="form-grid two">
        <label className="field span2">
          <span>Name</span>
          <input value={f.name} onChange={(e) => set('name', e.target.value)} />
        </label>
        <label className="field">
          <span>Configured capacity (people)</span>
          <input type="number" min={1} value={f.capacity ?? ''} onChange={(e) => set('capacity', e.target.value === '' ? null : Number(e.target.value))} />
        </label>
        <label className="field">
          <span>Watch threshold (% of capacity)</span>
          <input type="number" value={f.watchPct} onChange={(e) => set('watchPct', Number(e.target.value))} />
        </label>
        <label className="field">
          <span>Elevated threshold (%)</span>
          <input type="number" value={f.elevatedPct} onChange={(e) => set('elevatedPct', Number(e.target.value))} />
        </label>
        <label className="field">
          <span>Critical threshold (%) — blank for none</span>
          <input type="number" value={f.criticalPct ?? ''} onChange={(e) => set('criticalPct', e.target.value === '' ? null : Number(e.target.value))} />
        </label>
        <fieldset className="span2 pick">
          <legend>Exits serving this zone · required by the safety plan</legend>
          {exits.map((x) => (
            <div key={x.id} className="exit-pick">
              <label className="check">
                <input type="checkbox" checked={f.exitIds.includes(x.id)} onChange={() => toggle('exitIds', x.id)} /> {x.name}
              </label>
              <label className="check">
                <input type="checkbox" disabled={!f.exitIds.includes(x.id)} checked={f.requiredExitIds.includes(x.id)} onChange={() => toggle('requiredExitIds', x.id)} /> required
              </label>
            </div>
          ))}
        </fieldset>
        <label className="field span2">
          <span>Notes (verified local conditions only)</span>
          <input value={f.notes} onChange={(e) => set('notes', e.target.value)} />
        </label>
        <label className="field span2">
          <span>Communication fallback if mobile data fails <em className="opt">e.g. radio channel; leave blank if none is arranged</em></span>
          <input value={f.commsFallback} onChange={(e) => set('commsFallback', e.target.value)} />
        </label>
        {!zone && (
          <div className="span2">
            <p className="small">Click the map to place the zone centre; a rectangle of the given size is created. Precise boundaries can be supplied as a polygon through the zones API (PATCH /api/zones/:id).</p>
            <div className="form-grid two">
              <label className="field">
                <span>Width (m)</span>
                <input type="number" value={f.widthM} onChange={(e) => set('widthM', Number(e.target.value))} />
              </label>
              <label className="field">
                <span>Height (m)</span>
                <input type="number" value={f.heightM} onChange={(e) => set('heightM', Number(e.target.value))} />
              </label>
            </div>
            <VenueMap snap={s} height={260} compact showLegend={false} showControls={false} onMapClick={(lat, lng) => set('center', [lat, lng])} clickMarker={f.center} />
          </div>
        )}
      </div>
      <div className="modal-actions">
        <button className="btn" onClick={onClose}>
          Cancel
        </button>
        <button className="btn btn-primary" onClick={() => run(save, 'Zone saved')}>
          Save zone
        </button>
      </div>
    </Modal>
  );
}

function NetworkTab({ admin }: { admin: boolean }) {
  const { snap, reload } = useLive();
  const run = useAction();
  const s = snap!;
  const [pt, setPt] = useState<[number, number] | null>(null);
  const [placeKind, setPlaceKind] = useState<FacilityKind | 'junction'>('junction');
  const [placeName, setPlaceName] = useState('');
  const [placeZone, setPlaceZone] = useState('');
  const [seg, setSeg] = useState({ name: '', fromNode: '', toNode: '', modes: ['foot'] as TravelMode[], access: 'public' as AccessLevel, constraintNote: '', terrainNote: '', weatherExposed: false });
  const [editSeg, setEditSeg] = useState<RouteSegment | null>(null);

  const place = () =>
    run(async () => {
      if (!pt) throw new Error('Click the map to choose a location first.');
      if (placeKind === 'junction') await api.post(`/api/events/${s.event.id}/nodes`, { name: placeName, lat: pt[0], lng: pt[1] });
      else await api.post(`/api/events/${s.event.id}/facilities`, { kind: placeKind, name: placeName, lat: pt[0], lng: pt[1], zoneId: placeZone || null, capacityPerMin: null, notes: '' });
      await reload();
      setPlaceName('');
      setPt(null);
    }, 'Added to venue configuration');

  return (
    <div className="grid-2">
      <div className="stack">
        {admin && (
          <Card title="Place a facility or junction" subtitle="Click the map, then describe the point. Facilities automatically become route-network nodes.">
            <div className="form-grid two">
              <label className="field">
                <span>Type</span>
                <select value={placeKind} onChange={(e) => setPlaceKind(e.target.value as FacilityKind | 'junction')}>
                  <option value="junction">Route junction</option>
                  <option value="gate">Entry gate</option>
                  <option value="exit">Exit</option>
                  <option value="medical">Medical / first-aid post</option>
                  <option value="assembly">Assembly point</option>
                  <option value="control">Control room</option>
                  <option value="handover">Ambulance handover point</option>
                </select>
              </label>
              <label className="field">
                <span>Name</span>
                <input value={placeName} onChange={(e) => setPlaceName(e.target.value)} />
              </label>
              {placeKind !== 'junction' && (
                <label className="field">
                  <span>Zone</span>
                  <select value={placeZone} onChange={(e) => setPlaceZone(e.target.value)}>
                    <option value="">None / outside zones</option>
                    {s.zones.map((z) => (
                      <option key={z.id} value={z.id}>
                        {z.name}
                      </option>
                    ))}
                  </select>
                </label>
              )}
              <div className="small">{pt ? `Selected ${pt[0].toFixed(5)}, ${pt[1].toFixed(5)}` : 'No location selected'}</div>
              <button className="btn btn-primary" disabled={!pt || placeName.length < 2} onClick={place}>
                Add
              </button>
            </div>
          </Card>
        )}
        {admin && (
          <Card title="Add route segment" subtitle="Only add segments verified by the venue team. Distance is computed from node positions unless entered.">
            <div className="form-grid two">
              <label className="field span2">
                <span>Name</span>
                <input value={seg.name} onChange={(e) => setSeg({ ...seg, name: e.target.value })} />
              </label>
              {(['fromNode', 'toNode'] as const).map((k) => (
                <label key={k} className="field">
                  <span>{k === 'fromNode' ? 'From' : 'To'}</span>
                  <select value={seg[k]} onChange={(e) => setSeg({ ...seg, [k]: e.target.value })}>
                    <option value="">Select node…</option>
                    {s.nodes.map((n) => (
                      <option key={n.id} value={n.id}>
                        {n.name}
                      </option>
                    ))}
                  </select>
                </label>
              ))}
              <fieldset className="pick">
                <legend>Modes</legend>
                {(['foot', 'vehicle'] as TravelMode[]).map((m) => (
                  <label key={m} className="check">
                    <input type="checkbox" checked={seg.modes.includes(m)} onChange={() => setSeg({ ...seg, modes: seg.modes.includes(m) ? seg.modes.filter((x) => x !== m) : [...seg.modes, m] })} /> {m}
                  </label>
                ))}
              </fieldset>
              <label className="field">
                <span>Minimum access</span>
                <select value={seg.access} onChange={(e) => setSeg({ ...seg, access: e.target.value as AccessLevel })}>
                  <option value="public">Public</option>
                  <option value="staff">Staff</option>
                  <option value="emergency">Emergency only</option>
                </select>
              </label>
              <label className="field">
                <span>Constraint (configured)</span>
                <input value={seg.constraintNote} onChange={(e) => setSeg({ ...seg, constraintNote: e.target.value })} placeholder="e.g. single lane" />
              </label>
              <label className="field">
                <span>Terrain note (verified only)</span>
                <input value={seg.terrainNote} onChange={(e) => setSeg({ ...seg, terrainNote: e.target.value })} placeholder="e.g. steep approach confirmed on site visit" />
              </label>
              <label className="check span2">
                <input type="checkbox" checked={seg.weatherExposed} onChange={(e) => setSeg({ ...seg, weatherExposed: e.target.checked })} /> Rain-exposed section (confirmed by venue staff) — included in heavy-rain stress tests
              </label>
              <button
                className="btn btn-primary"
                disabled={!seg.name || !seg.fromNode || !seg.toNode || !seg.modes.length}
                onClick={() => run(() => api.post(`/api/events/${s.event.id}/segments`, { ...seg, approved: true }).then(reload), 'Segment added')}
              >
                Add segment
              </button>
            </div>
          </Card>
        )}
        <Card title={`Route segments (${s.segments.length})`}>
          <div className="table-wrap tall">
            <table className="table compact">
              <thead>
                <tr>
                  <th>Segment</th>
                  <th>Modes / access</th>
                  <th>Approved</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {s.segments.map((x) => (
                  <tr key={x.id}>
                    <td>
                      {x.name}
                      <div className="tiny muted">
                        {metres(x.distanceM)} {x.constraintNote && `· ${x.constraintNote}`} {x.terrainNote && `· ${x.terrainNote}`} {x.weatherExposed && <span className="tag tag-rain">rain-exposed</span>}
                      </div>
                    </td>
                    <td className="small">
                      {x.modes.join('+')} · {x.access}
                    </td>
                    <td>{x.approved ? 'Yes' : <span className="text-warn">No</span>}</td>
                    <td>{admin && <button className="btn btn-sm btn-ghost" onClick={() => setEditSeg(x)}>Edit</button>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
      <div className="setup-map">
        <VenueMap snap={s} height={620} onMapClick={admin ? (lat, lng) => setPt([lat, lng]) : undefined} clickMarker={pt} initialLayers={{ incidents: false, responders: false }} />
      </div>
      {editSeg && <SegmentConfigDialog seg={editSeg} onClose={() => setEditSeg(null)} />}
    </div>
  );
}

function SegmentConfigDialog({ seg, onClose }: { seg: RouteSegment; onClose: () => void }) {
  const { reload } = useLive();
  const run = useAction();
  const [f, setF] = useState({ name: seg.name, modes: seg.modes, access: seg.access, approved: seg.approved, constraintNote: seg.constraintNote, terrainNote: seg.terrainNote, weatherExposed: seg.weatherExposed, distanceM: seg.distanceM });
  return (
    <Modal title={`Configure ${seg.name}`} onClose={onClose}>
      <div className="form-grid">
        <label className="field">
          <span>Name</span>
          <input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        </label>
        <fieldset className="pick">
          <legend>Modes</legend>
          {(['foot', 'vehicle'] as TravelMode[]).map((m) => (
            <label key={m} className="check">
              <input type="checkbox" checked={f.modes.includes(m)} onChange={() => setF({ ...f, modes: f.modes.includes(m) ? f.modes.filter((x) => x !== m) : [...f.modes, m] })} /> {m}
            </label>
          ))}
        </fieldset>
        <label className="field">
          <span>Minimum access</span>
          <select value={f.access} onChange={(e) => setF({ ...f, access: e.target.value as AccessLevel })}>
            <option value="public">Public</option>
            <option value="staff">Staff</option>
            <option value="emergency">Emergency only</option>
          </select>
        </label>
        <label className="field">
          <span>Configured distance (m)</span>
          <input type="number" value={f.distanceM} onChange={(e) => setF({ ...f, distanceM: Number(e.target.value) })} />
        </label>
        <label className="check">
          <input type="checkbox" checked={f.approved} onChange={(e) => setF({ ...f, approved: e.target.checked })} /> Approved in the venue route plan
        </label>
        <label className="field">
          <span>Constraint</span>
          <input value={f.constraintNote} onChange={(e) => setF({ ...f, constraintNote: e.target.value })} />
        </label>
        <label className="field">
          <span>Terrain note (verified)</span>
          <input value={f.terrainNote} onChange={(e) => setF({ ...f, terrainNote: e.target.value })} />
        </label>
        <label className="check">
          <input type="checkbox" checked={f.weatherExposed} onChange={(e) => setF({ ...f, weatherExposed: e.target.checked })} /> Rain-exposed section (confirmed)
        </label>
      </div>
      <div className="modal-actions">
        <button className="btn" onClick={onClose}>
          Cancel
        </button>
        <button
          className="btn btn-primary"
          disabled={!f.modes.length}
          onClick={async () => {
            const ok = await run(() => api.patch(`/api/segments/${seg.id}`, f).then(reload), 'Segment configuration saved');
            if (ok !== undefined) onClose();
          }}
        >
          Save
        </button>
      </div>
    </Modal>
  );
}

function NamedRoutesTab({ admin }: { admin: boolean }) {
  const { snap, reload } = useLive();
  const run = useAction();
  const s = snap!;
  const [f, setF] = useState({ name: '', purpose: '', mode: 'foot' as TravelMode, access: 'staff' as AccessLevel, fromNode: '', toNode: '' });
  const n = (id: string) => s.nodes.find((x) => x.id === id)?.name ?? id;
  return (
    <div className="grid-2">
      <Card title="Approved operational routes">
        {(s.namedRoutes ?? []).map((r) => {
          const v = s.routeValidity?.find((x) => x.routeId === r.id);
          return (
            <div key={r.id} className="nr-row">
              <strong>{r.name}</strong> {v?.valid ? <span className="chip chip-ok">valid</span> : <span className="chip chip-danger">invalid</span>}
              <div className="small muted">
                {n(r.fromNode)} → {n(r.toNode)} · {r.mode} · {r.access} · {r.segmentIds.length} segments · approved by {r.approvedBy} {fmtDateTime(r.approvedAt)}
              </div>
            </div>
          );
        })}
      </Card>
      {admin && (
        <Card title="Approve a new operational route" subtitle="The route is computed over open, approved segments (avoiding segments under review) and stored with its segment list, so later closures can invalidate it.">
          <div className="form-grid two">
            <label className="field span2">
              <span>Name</span>
              <input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
            </label>
            <label className="field span2">
              <span>Purpose</span>
              <input value={f.purpose} onChange={(e) => setF({ ...f, purpose: e.target.value })} />
            </label>
            {(['fromNode', 'toNode'] as const).map((k) => (
              <label key={k} className="field">
                <span>{k === 'fromNode' ? 'From' : 'To'}</span>
                <select value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })}>
                  <option value="">Select…</option>
                  {s.nodes.map((x) => (
                    <option key={x.id} value={x.id}>
                      {x.name}
                    </option>
                  ))}
                </select>
              </label>
            ))}
            <label className="field">
              <span>Mode</span>
              <select value={f.mode} onChange={(e) => setF({ ...f, mode: e.target.value as TravelMode })}>
                <option value="foot">Foot</option>
                <option value="vehicle">Vehicle</option>
              </select>
            </label>
            <label className="field">
              <span>Access</span>
              <select value={f.access} onChange={(e) => setF({ ...f, access: e.target.value as AccessLevel })}>
                <option value="public">Public</option>
                <option value="staff">Staff</option>
                <option value="emergency">Emergency</option>
              </select>
            </label>
            <button className="btn btn-primary" disabled={!f.name || !f.fromNode || !f.toNode} onClick={() => run(() => api.post(`/api/events/${s.event.id}/named-routes`, f).then(reload), 'Route approved')}>
              Compute & approve
            </button>
          </div>
        </Card>
      )}
    </div>
  );
}

function PlaybooksTab({ admin }: { admin: boolean }) {
  const { snap } = useLive();
  const [edit, setEdit] = useState<Playbook | null>(null);
  return (
    <div className="pb-grid">
      {(snap!.playbooks ?? []).map((p) => (
        <Card key={p.id} title={p.title} subtitle={`Categories: ${p.categories.join(', ')}`} actions={admin && <button className="btn btn-sm btn-ghost" onClick={() => setEdit(p)}>Edit</button>}>
          <p className="small">
            <strong>Trigger:</strong> {p.trigger}
          </p>
          <ol className="small">
            {p.steps.map((st, i) => (
              <li key={i}>
                {st.title} {st.approval === 'safety_authority' && <span className="tag tag-critical">safety authority</span>}
                {st.dueMinutes && <span className="muted tiny"> · target {st.dueMinutes} min</span>}
              </li>
            ))}
          </ol>
          <p className="small">
            <strong>Escalation:</strong> {p.escalation}
          </p>
        </Card>
      ))}
      {edit && <PlaybookDialog pb={edit} onClose={() => setEdit(null)} />}
    </div>
  );
}

function PlaybookDialog({ pb, onClose }: { pb: Playbook; onClose: () => void }) {
  const { reload } = useLive();
  const run = useAction();
  const [steps, setSteps] = useState<PlaybookStep[]>(pb.steps);
  const [trigger, setTrigger] = useState(pb.trigger);
  const [escalation, setEscalation] = useState(pb.escalation);
  const upd = (i: number, p: Partial<PlaybookStep>) => setSteps((s) => s.map((x, k) => (k === i ? { ...x, ...p } : x)));
  return (
    <Modal title={`Edit playbook: ${pb.title}`} onClose={onClose} wide>
      <label className="field">
        <span>Trigger</span>
        <input value={trigger} onChange={(e) => setTrigger(e.target.value)} />
      </label>
      <label className="field">
        <span>Escalation path</span>
        <input value={escalation} onChange={(e) => setEscalation(e.target.value)} />
      </label>
      {steps.map((st, i) => (
        <div key={i} className="pb-edit">
          <input value={st.title} onChange={(e) => upd(i, { title: e.target.value })} aria-label={`Step ${i + 1} title`} />
          <select value={st.approval} onChange={(e) => upd(i, { approval: e.target.value as PlaybookStep['approval'] })} aria-label="Approval">
            <option value="coordinator">Coordinator</option>
            <option value="safety_authority">Safety authority</option>
            <option value="none">None</option>
          </select>
          <input type="number" min={1} placeholder="min" value={st.dueMinutes ?? ''} onChange={(e) => upd(i, { dueMinutes: e.target.value ? Number(e.target.value) : undefined })} aria-label="Target minutes" />
          <button className="btn btn-sm btn-ghost" onClick={() => setSteps((s) => s.filter((_, k) => k !== i))}>
            Remove
          </button>
          <textarea rows={1} value={st.detail} onChange={(e) => upd(i, { detail: e.target.value })} aria-label="Detail" />
        </div>
      ))}
      <button className="btn btn-sm" onClick={() => setSteps((s) => [...s, { title: 'New step', detail: '', approval: 'coordinator' }])}>
        <Plus size={13} /> Add step
      </button>
      <p className="tiny muted">Changes apply to incidents verified after saving; existing incident checklists keep the steps they were created with.</p>
      <div className="modal-actions">
        <button className="btn" onClick={onClose}>
          Cancel
        </button>
        <button
          className="btn btn-primary"
          onClick={async () => {
            const ok = await run(() => api.patch(`/api/playbooks/${pb.id}`, { trigger, escalation, steps }).then(reload), 'Playbook saved');
            if (ok !== undefined) onClose();
          }}
        >
          Save playbook
        </button>
      </div>
    </Modal>
  );
}

function NewEventButton() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button className="btn btn-primary" onClick={() => setOpen(true)}>
        <Plus size={15} /> New event
      </button>
      {open && <NewEventDialog onClose={() => setOpen(false)} />}
    </>
  );
}

function NewEventDialog({ onClose }: { onClose: () => void }) {
  const { refresh, setEventId } = useSession();
  const run = useAction();
  const now = new Date();
  const [f, setF] = useState({
    name: '',
    eventType: 'Festival',
    state: 'Meghalaya',
    district: '',
    locationLabel: '',
    venueName: '',
    venueIsFictional: false,
    startsAt: toLocal(now.toISOString()),
    endsAt: toLocal(new Date(now.getTime() + 8 * 3600_000).toISOString()),
    expectedAttendance: '',
    venueCapacity: '',
    controlContact: '',
    centerLat: '25.5788',
    centerLng: '91.8933',
    zoom: 16,
    template: 'blank' as 'blank' | 'demo_layout',
  });
  const set = (k: string, v: unknown) => setF((x) => ({ ...x, [k]: v }));
  return (
    <Modal title="Create event" onClose={onClose} wide>
      <div className="form-grid two">
        <label className="field span2">
          <span>Event name</span>
          <input value={f.name} onChange={(e) => set('name', e.target.value)} />
        </label>
        <label className="field">
          <span>Event type</span>
          <select value={f.eventType} onChange={(e) => set('eventType', e.target.value)}>
            {EVENT_TYPES.map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
        </label>
        <label className="field">
          <span>State</span>
          <select value={f.state} onChange={(e) => set('state', e.target.value)}>
            {NE_STATES.map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
        </label>
        <label className="field">
          <span>District</span>
          <input value={f.district} onChange={(e) => set('district', e.target.value)} />
        </label>
        <label className="field">
          <span>Venue name</span>
          <input value={f.venueName} onChange={(e) => set('venueName', e.target.value)} />
        </label>
        <label className="field span2">
          <span>Location label</span>
          <input value={f.locationLabel} onChange={(e) => set('locationLabel', e.target.value)} />
        </label>
        <label className="field">
          <span>Starts</span>
          <input type="datetime-local" value={f.startsAt} onChange={(e) => set('startsAt', e.target.value)} />
        </label>
        <label className="field">
          <span>Ends</span>
          <input type="datetime-local" value={f.endsAt} onChange={(e) => set('endsAt', e.target.value)} />
        </label>
        <label className="field">
          <span>Expected attendance</span>
          <input type="number" value={f.expectedAttendance} onChange={(e) => set('expectedAttendance', e.target.value)} />
        </label>
        <label className="field">
          <span>Venue capacity</span>
          <input type="number" value={f.venueCapacity} onChange={(e) => set('venueCapacity', e.target.value)} />
        </label>
        <label className="field">
          <span>Map centre latitude</span>
          <input value={f.centerLat} onChange={(e) => set('centerLat', e.target.value)} />
        </label>
        <label className="field">
          <span>Map centre longitude</span>
          <input value={f.centerLng} onChange={(e) => set('centerLng', e.target.value)} />
        </label>
        <label className="field span2">
          <span>Starting layout</span>
          <select value={f.template} onChange={(e) => set('template', e.target.value)}>
            <option value="blank">Blank — configure zones, facilities and routes from verified site plans</option>
            <option value="demo_layout">Copy the fictional demo layout, re-centred (for training only)</option>
          </select>
        </label>
        <label className="check span2">
          <input type="checkbox" checked={f.venueIsFictional} onChange={(e) => set('venueIsFictional', e.target.checked)} /> Mark venue layout as fictional / training
        </label>
      </div>
      <div className="modal-actions">
        <button className="btn" onClick={onClose}>
          Cancel
        </button>
        <button
          className="btn btn-primary"
          onClick={async () => {
            const ev = await run(
              () =>
                api.post<{ id: string }>('/api/events', {
                  ...f,
                  venueIsFictional: f.venueIsFictional || f.template === 'demo_layout',
                  startsAt: new Date(f.startsAt).toISOString(),
                  endsAt: new Date(f.endsAt).toISOString(),
                  expectedAttendance: f.expectedAttendance ? Number(f.expectedAttendance) : null,
                  venueCapacity: f.venueCapacity ? Number(f.venueCapacity) : null,
                  centerLat: Number(f.centerLat),
                  centerLng: Number(f.centerLng),
                }),
              'Event created',
            );
            if (ev) {
              await refresh();
              setEventId(ev.id);
              onClose();
            }
          }}
        >
          Create event
        </button>
      </div>
    </Modal>
  );
}
