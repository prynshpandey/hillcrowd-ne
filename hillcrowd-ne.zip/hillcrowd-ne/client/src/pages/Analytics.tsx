import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Download } from 'lucide-react';
import { useLive } from '../lib/live';
import { api } from '../lib/api';
import { CATEGORIES, STATUS_LABEL } from '@shared/constants';
import { Card, Empty, LevelBadge, Notice } from '../components/ui';
import { duration, fmtDateTime, fmtTime } from '../lib/format';
import { Replay } from '../components/Replay';
import type { RiskLevel } from '@shared/types';

interface Analytics {
  dataLabel: string;
  isDemo: boolean;
  generatedAt: string;
  totals: { incidents: number; active: number; resolvedOrClosed: number; rejected: number; reopened: number; urgent: number };
  byCategory: { key: string; n: number; label: string }[];
  byZone: { key: string; n: number }[];
  bySeverity: { key: string; n: number }[];
  byStatus: { key: string; n: number; label: string }[];
  medians: { reportToVerifySec: number | null; reportToAssignSec: number | null; reportToAckSec: number | null; reportToResolveSec: number | null; sampleSize: Record<string, number> };
  contextNote: string;
  perIncident: { stages: { key: string; label: string; durationSec: number | null; targetSec: number; overdue: boolean; state: string }[]; routeM: number | null; routeFound: boolean | null; id: string; ref: string; category: string; zone: string; status: string; severity: string; urgent: boolean; receivedAt: string; syncDelaySec: number | null; toVerifySec: number | null; toAssignSec: number | null; toAckSec: number | null; toResolveSec: number | null; reopenCount: number }[];
  closures: { segment: string; status: string; reason: string; source: string; at: string; liftedAt: string | null }[];
  closureFrequency: { name: string; closed: number; review: number }[];
  riskHistory: { zone: string; from: string | null; to: string; at: string; reasons: string[] }[];
  responderStats: { responder: string; assignments: number; acknowledged: number; declinedOrUnable: number; escalated: number; ackRate: number | null; medianAssignToAckSec: number | null }[];
  dataQuality: { staleActiveIncidents: string[]; queuedOfflineReports: { ref: string; delaySec: number | null }[]; unverifiedActive: number; severityUnconfirmed: number; possibleDuplicatesFlagged: number; mergedReports: number };
  timeline: { at: string; actor: string; role: string | null; action: string; entityType: string; details: Record<string, unknown> }[];
}

function Bars({ data, label }: { data: { key: string; n: number; label?: string }[]; label: string }) {
  const max = Math.max(1, ...data.map((d) => d.n));
  if (!data.length) return <Empty>No data.</Empty>;
  return (
    <div className="bars" role="list" aria-label={label}>
      {data.map((d) => (
        <div key={d.key} className="bar-row" role="listitem">
          <span className="bar-label">{d.label ?? d.key}</span>
          <span className="bar-track">
            <span className="bar-fill" style={{ width: `${(d.n / max) * 100}%` }} />
          </span>
          <span className="bar-n">{d.n}</span>
        </div>
      ))}
    </div>
  );
}



export default function AnalyticsPage() {
  const { snap } = useLive();
  const s = snap!;
  const [filter, setFilter] = useState({ category: '', status: '', from: '', to: '' });
  const [data, setData] = useState<Analytics | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const qs = new URLSearchParams(Object.entries({ ...filter, from: filter.from ? new Date(filter.from).toISOString() : '', to: filter.to ? new Date(filter.to).toISOString() : '' }).filter(([, v]) => v)).toString();

  useEffect(() => {
    api
      .get<Analytics>(`/api/events/${s.event.id}/analytics?${qs}`)
      .then((d) => {
        setData(d);
        setErr(null);
      })
      .catch((e) => setErr(e.message));
  }, [qs, s.event.id, s.serverTime]);

  return (
    <div className="page analytics">
      <div className="page-head">
        <div>
          <h1>Analytics & post-event review</h1>
          <p className="muted">All figures are calculated from timestamps recorded by this application. No real-world performance claims are made.</p>
        </div>
        <a className="btn btn-primary" href={`/api/events/${s.event.id}/analytics.csv?${qs}`} download>
          <Download size={15} /> Download CSV report
        </a>
      </div>
      {data && <Notice tone={data.isDemo ? 'warn' : 'info'}>{data.dataLabel}</Notice>}
      <div className="filters">
        <select value={filter.category} onChange={(e) => setFilter({ ...filter, category: e.target.value })} aria-label="Category">
          <option value="">All categories</option>
          {CATEGORIES.map((c) => (
            <option key={c.key} value={c.key}>
              {c.label}
            </option>
          ))}
        </select>
        <select value={filter.status} onChange={(e) => setFilter({ ...filter, status: e.target.value })} aria-label="Status">
          <option value="">All statuses</option>
          {Object.entries(STATUS_LABEL).map(([k, l]) => (
            <option key={k} value={k}>
              {l}
            </option>
          ))}
        </select>
        <label className="inline">
          From <input type="datetime-local" value={filter.from} onChange={(e) => setFilter({ ...filter, from: e.target.value })} />
        </label>
        <label className="inline">
          To <input type="datetime-local" value={filter.to} onChange={(e) => setFilter({ ...filter, to: e.target.value })} />
        </label>
      </div>
      {err && <Notice tone="danger">{err}</Notice>}
      {!data ? (
        <div className="splash">Loading analytics…</div>
      ) : (
        <>
          <div className="kpis">
            <div className="kpi">
              <span className="kpi-n">{data.totals.incidents}</span>
              <span className="kpi-l">incidents (excl. merged)</span>
            </div>
            <div className="kpi">
              <span className="kpi-n">{data.totals.active}</span>
              <span className="kpi-l">unresolved</span>
            </div>
            <div className="kpi">
              <span className="kpi-n">{data.totals.reopened}</span>
              <span className="kpi-l">reopened</span>
            </div>
            <div className="kpi">
              <span className="kpi-n">{duration(data.medians.reportToAssignSec)}</span>
              <span className="kpi-l">median report → assignment (n={data.medians.sampleSize.assign})</span>
            </div>
            <div className="kpi">
              <span className="kpi-n">{duration(data.medians.reportToAckSec)}</span>
              <span className="kpi-l">median report → acknowledgement (n={data.medians.sampleSize.ack})</span>
            </div>
            <div className="kpi">
              <span className="kpi-n">{duration(data.medians.reportToResolveSec)}</span>
              <span className="kpi-l">median report → resolution (n={data.medians.sampleSize.resolve})</span>
            </div>
          </div>
          <p className="tiny muted">Medians over incidents that reached each stage. With small samples (e.g. one demo incident) these are single observations, not performance benchmarks, and there is no baseline comparison.</p>

          <div className="grid-3">
            <Card title="By category">
              <Bars data={data.byCategory} label="Incidents by category" />
            </Card>
            <Card title="By venue zone">
              <Bars data={data.byZone} label="Incidents by zone" />
            </Card>
            <Card title="By severity (confirmed, else estimate)">
              <Bars data={data.bySeverity} label="Incidents by severity" />
            </Card>
          </div>

          <Card title="Incident timings" subtitle={data.contextNote}>
            {data.perIncident.length === 0 ? (
              <Empty>No incidents match the filters.</Empty>
            ) : (
              <div className="table-wrap">
                <table className="table compact">
                  <thead>
                    <tr>
                      <th>Ref</th>
                      <th>Category</th>
                      <th>Zone</th>
                      <th>Status</th>
                      <th>Received</th>
                      <th>→ Verify</th>
                      <th>→ Assign</th>
                      <th>→ Ack</th>
                      <th>→ Resolve</th>
                      <th>Stages over target</th>
                      <th>Context</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.perIncident.map((p) => (
                      <tr key={p.id}>
                        <td>
                          <Link to={`/incidents/${p.id}`}>{p.ref}</Link>
                        </td>
                        <td>{CATEGORIES.find((c) => c.key === p.category)?.short}</td>
                        <td className="small">{p.zone}</td>
                        <td>{STATUS_LABEL[p.status as keyof typeof STATUS_LABEL]}</td>
                        <td>{fmtTime(p.receivedAt, true)}</td>
                        <td>{duration(p.toVerifySec)}</td>
                        <td>{duration(p.toAssignSec)}</td>
                        <td>{duration(p.toAckSec)}</td>
                        <td>{duration(p.toResolveSec)}</td>
                        <td className="small">{p.stages.filter((x) => x.overdue).map((x) => x.label).join(', ') || <span className="muted">none</span>}</td>
                        <td className="tiny muted">
                          {p.routeFound === false ? 'no approved route at assignment' : p.routeM != null ? `route ${p.routeM} m` : '—'}
                          {p.syncDelaySec && p.syncDelaySec > 60 ? ` · synced ${duration(p.syncDelaySec)} late` : ''}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>

          <div className="grid-2">
            <Card title="Responder acknowledgement">
              <table className="table compact">
                <thead>
                  <tr>
                    <th>Responder</th>
                    <th>Assigned</th>
                    <th>Ack rate</th>
                    <th>Median assign → ack</th>
                    <th>Escalated</th>
                  </tr>
                </thead>
                <tbody>
                  {data.responderStats.map((r) => (
                    <tr key={r.responder}>
                      <td>{r.responder}</td>
                      <td>{r.assignments}</td>
                      <td>{r.ackRate == null ? '—' : `${Math.round(r.ackRate * 100)}%`}</td>
                      <td>{duration(r.medianAssignToAckSec)}</td>
                      <td>{r.escalated}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Card>
            <Card title="Data quality">
              <ul className="plain small dq">
                <li>Unverified active reports: <strong>{data.dataQuality.unverifiedActive}</strong></li>
                <li>Stale active incidents (no update within threshold): <strong>{data.dataQuality.staleActiveIncidents.length}</strong> {data.dataQuality.staleActiveIncidents.join(', ')}</li>
                <li>Reports delivered &gt;1 min after creation (offline queue): <strong>{data.dataQuality.queuedOfflineReports.length}</strong></li>
                <li>Severity not confirmed by control room: <strong>{data.dataQuality.severityUnconfirmed}</strong></li>
                <li>Reports flagged as possible duplicates: <strong>{data.dataQuality.possibleDuplicatesFlagged}</strong>; merged: <strong>{data.dataQuality.mergedReports}</strong></li>
              </ul>
            </Card>
          </div>

          <div className="grid-2">
            <Card title="Route closures & reviews">
              {data.closures.length === 0 ? (
                <Empty>No closures recorded.</Empty>
              ) : (
                <>
                  <Bars data={data.closureFrequency.map((c) => ({ key: c.name, n: c.closed + c.review, label: `${c.name} (${c.closed} closed, ${c.review} review)` }))} label="Closure frequency" />
                  <ul className="plain small closure-list">
                    {data.closures.map((c, i) => (
                      <li key={i}>
                        {fmtTime(c.at, true)} — <strong>{c.segment}</strong> {c.status === 'closed' ? 'closed' : 'under review'}: {c.reason} <span className="muted">({c.source})</span>
                      </li>
                    ))}
                  </ul>
                </>
              )}
            </Card>
            <Card title="Risk-flag history">
              {data.riskHistory.length === 0 ? (
                <Empty>No changes.</Empty>
              ) : (
                <ul className="plain small risk-hist">
                  {data.riskHistory.map((r, i) => (
                    <li key={i}>
                      <span className="muted">{fmtTime(r.at, true)}</span> {r.zone}: {r.from ? <LevelBadge level={r.from as RiskLevel} size="sm" /> : '—'} → <LevelBadge level={r.to as RiskLevel} size="sm" />
                      {r.reasons[0] && <div className="tiny muted">{r.reasons[0]}</div>}
                    </li>
                  ))}
                </ul>
              )}
            </Card>
          </div>

          <Card id="replay" title="Exercise replay — what was reported, verified, decided, acknowledged and resolved" subtitle={`Reconstructed from the audit log · generated ${fmtDateTime(data.generatedAt)}. Press Play or drag the slider; click any entry to jump to it.`}>
            <Replay timeline={data.timeline} />
          </Card>
        </>
      )}
    </div>
  );
}
