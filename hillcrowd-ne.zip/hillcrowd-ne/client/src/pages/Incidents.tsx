import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { AlertTriangle, ArrowLeft, Ban, CheckCheck, ClipboardCheck, GitMerge, Navigation, Plus, Route as RouteIcon, SkipForward, UserPlus } from 'lucide-react';
import { useLive } from '../lib/live';
import { useSession } from '../lib/session';
import { api } from '../lib/api';
import { can } from '@shared/permissions';
import { availableTransitions, ASSIGNMENT_FLOW } from '@shared/workflow';
import { findRoute } from '@shared/routing';
import { haversineM } from '@shared/geo';
import { ASSIGNMENT_LABEL, CATEGORIES, CATEGORY_LABEL, SEVERITIES, STATUS_LABEL } from '@shared/constants';
import type { Assignment, Incident, IncidentAction, IncidentStatus, IncidentUpdate, Responder, RouteResult, Severity } from '@shared/types';
import { Ago, Card, Empty, Notice, ReasonDialog, SeverityTag, StatusChip, useAction, VerifyChip } from '../components/ui';
import { VenueMap } from '../components/VenueMap';
import { FacilityStatusDialog } from '../components/FeatureDetails';
import { priorityScore } from './Overview';
import { StageClock, StageTimeline } from '../components/Stage';
import { ago, duration, fmtDateTime, fmtTime, metres } from '../lib/format';
import type { Snapshot } from '../lib/types';

type Filter = 'active' | 'review' | 'all' | 'closed';

export default function IncidentsPage() {
  const { id } = useParams();
  const { snap } = useLive();
  const nav = useNavigate();
  const [filter, setFilter] = useState<Filter>('active');
  const [cat, setCat] = useState('');
  const [zone, setZone] = useState('');
  const [q, setQ] = useState('');
  const s = snap!;
  const zones = new Map(s.zones.map((z) => [z.id, z.name]));
  const responders = new Map((s.responders ?? []).map((r) => [r.id, r]));
  const asgByInc = useMemo(() => {
    const m = new Map<string, Assignment[]>();
    for (const a of s.assignments ?? []) (m.get(a.incidentId) ?? m.set(a.incidentId, []).get(a.incidentId)!).push(a);
    return m;
  }, [s.assignments]);

  const list = s.incidents
    .filter((i) => {
      const active = ['submitted', 'under_review', 'verified', 'assigned', 'acknowledged', 'in_progress', 'resolved'].includes(i.status) && !i.mergedInto;
      if (filter === 'active' && !active) return false;
      if (filter === 'review' && !['submitted', 'under_review'].includes(i.status)) return false;
      if (filter === 'closed' && active) return false;
      if (cat && i.category !== cat) return false;
      if (zone && i.zoneId !== zone) return false;
      if (q && !`${i.ref} ${i.description} ${i.reporterName}`.toLowerCase().includes(q.toLowerCase())) return false;
      return true;
    })
    .sort((a, b) => (filter === 'active' || filter === 'review' ? priorityScore(b) - priorityScore(a) : b.receivedAt.localeCompare(a.receivedAt)));

  return (
    <div className={`page incidents-page ${id ? 'has-detail' : ''}`}>
      <section className="queue">
        <div className="page-head">
          <h1>Incident management</h1>
          <Link className="btn btn-primary btn-sm" to="/field">
            <Plus size={14} /> New report
          </Link>
        </div>
        <div className="filters">
          <div className="seg" role="tablist">
            {(['active', 'review', 'all', 'closed'] as Filter[]).map((f) => (
              <button key={f} role="tab" aria-selected={filter === f} className={filter === f ? 'on' : ''} onClick={() => setFilter(f)}>
                {f === 'active' ? 'Active' : f === 'review' ? 'Awaiting review' : f === 'all' ? 'All' : 'Closed / rejected'}
              </button>
            ))}
          </div>
          <select value={cat} onChange={(e) => setCat(e.target.value)} aria-label="Category filter">
            <option value="">All categories</option>
            {CATEGORIES.map((c) => (
              <option key={c.key} value={c.key}>
                {c.label}
              </option>
            ))}
          </select>
          <select value={zone} onChange={(e) => setZone(e.target.value)} aria-label="Zone filter">
            <option value="">All zones</option>
            {s.zones.map((z) => (
              <option key={z.id} value={z.id}>
                {z.name}
              </option>
            ))}
          </select>
          <input type="search" placeholder="Search ref, text, reporter" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search incidents" />
        </div>
        {list.length === 0 ? (
          <Empty>No incidents match these filters.</Empty>
        ) : (
          <div className="table-wrap">
            <table className="table queue-table">
              <thead>
                <tr>
                  <th>Ref</th>
                  <th>Severity</th>
                  <th>Category / location</th>
                  <th>Status</th>
                  <th>Reported</th>
                  <th>Stage · who acts next</th>
                  <th>Responder</th>
                </tr>
              </thead>
              <tbody>
                {list.map((i) => {
                  const asg = (asgByInc.get(i.id) ?? []).find((a) => ['assigned', 'acknowledged', 'en_route', 'on_scene'].includes(a.status));
                  const stale = Date.now() - new Date(i.updatedAt).getTime() > s.event.settings.staleMinutes * 60000 && !['closed', 'rejected', 'resolved'].includes(i.status);
                  return (
                    <tr key={i.id} className={`${i.id === id ? 'selected' : ''} ${i.mergedInto ? 'merged' : ''}`} onClick={() => nav(`/incidents/${i.id}`)} tabIndex={0} onKeyDown={(e) => e.key === 'Enter' && nav(`/incidents/${i.id}`)}>
                      <td>
                        <strong>{i.ref}</strong>
                        {i.urgent && <span className="tag tag-critical">URGENT</span>}
                        {i.possibleDuplicateOf.length > 0 && !i.mergedInto && <span className="tag tag-warn">possible duplicate</span>}
                        {i.mergedInto && <span className="tag">merged</span>}
                        {i.isDemo && <span className="tag tag-sample">demo</span>}
                      </td>
                      <td>
                        <SeverityTag severity={i.confirmedSeverity ?? i.severityEstimate} confirmed={!!i.confirmedSeverity} />
                      </td>
                      <td>
                        <div>{CATEGORY_LABEL[i.category]}</div>
                        <div className="muted tiny">{zones.get(i.zoneId ?? '') ?? 'Map location'}</div>
                      </td>
                      <td>
                        <StatusChip status={i.status} />
                        <div>
                          <VerifyChip status={i.status} />
                        </div>
                      </td>
                      <td>
                        {fmtTime(i.receivedAt)}
                        <div className="muted tiny">{ago(i.receivedAt)}</div>
                      </td>
                      <td className={stale ? 'stale-cell' : ''}>
                        <StageClock st={s.stages?.[i.id]} />
                        <div className="tiny muted">
                          updated <Ago iso={i.updatedAt} />
                          {stale && <span className="tag tag-stale">stale</span>}
                        </div>
                      </td>
                      <td>
                        {asg ? (
                          <>
                            {responders.get(asg.responderId)?.name}
                            <div className={`tiny ${asg.status === 'assigned' ? (asg.escalatedAt ? 'text-danger' : 'text-warn') : 'muted'}`}>{asg.escalatedAt ? 'ESCALATED — not acknowledged' : ASSIGNMENT_LABEL[asg.status]}</div>
                          </>
                        ) : (
                          <span className="muted">—</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
      {id && <IncidentDetail id={id} key={id} />}
    </div>
  );
}

interface Detail {
  incident: Incident;
  history: IncidentUpdate[];
  actions: IncidentAction[];
  assignments: Assignment[];
  possibleDuplicates: Incident[];
  mergedChildren: Incident[];
}

function nearestNodeId(snap: Snapshot, lat: number, lng: number) {
  let best: string | null = null;
  let d = Infinity;
  for (const n of snap.nodes) {
    const x = haversineM([lat, lng], [n.lat, n.lng]);
    if (x < d) {
      d = x;
      best = n.id;
    }
  }
  return best;
}

export function previewRoute(snap: Snapshot, r: Responder, inc: Incident): RouteResult | null {
  const origin = r.baseNodeId ?? (r.lat != null ? nearestNodeId(snap, r.lat, r.lng!) : null);
  const dest = inc.lat != null ? nearestNodeId(snap, inc.lat, inc.lng!) : null;
  if (!origin || !dest) return null;
  let last: RouteResult | null = null;
  for (const mode of r.modes) {
    const res = findRoute(snap.nodes, snap.segments, { from: origin, to: dest, mode, access: r.access });
    if (res.found) return res;
    last = res;
  }
  return last;
}

function IncidentDetail({ id }: { id: string }) {
  const { snap, reload } = useLive();
  const { me } = useSession();
  const run = useAction();
  const nav = useNavigate();
  const [d, setD] = useState<Detail | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [dialog, setDialog] = useState<React.ReactNode>(null);
  const [showAssign, setShowAssign] = useState(false);
  const [note, setNote] = useState('');
  const role = me!.user.role;
  const s = snap!;

  const load = useCallback(async () => {
    try {
      setD(await api.get<Detail>(`/api/incidents/${id}`));
      setErr(null);
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Failed to load incident');
    }
  }, [id]);
  useEffect(() => {
    load();
  }, [load, s.serverTime]);

  if (err) return <section className="detail"><Notice tone="danger">{err}</Notice></section>;
  if (!d) return <section className="detail"><div className="splash">Loading incident…</div></section>;

  const i = d.incident;
  const zone = s.zones.find((z) => z.id === i.zoneId);
  const responders = new Map((s.responders ?? []).map((r) => [r.id, r]));
  const close = () => setDialog(null);
  const after = async () => {
    await reload();
    await load();
  };
  const transitions = i.mergedInto ? [] : availableTransitions(i.status, role);
  const activeAsg = d.assignments.filter((a) => ['assigned', 'acknowledged', 'en_route', 'on_scene'].includes(a.status));
  const canAssign = can(role, 'assignment.create') && !i.mergedInto && ['verified', 'assigned', 'acknowledged', 'in_progress'].includes(i.status);
  const unverified = i.status === 'submitted' || i.status === 'under_review';
  const routeHighlights = activeAsg.filter((a) => a.route?.found).map((a) => ({ segmentIds: a.route!.segmentIds, tone: 'primary' as const }));

  const doTransition = (to: IncidentStatus, label: string, requiresNote?: boolean) => {
    if (to === 'verified') {
      setDialog(<VerifyDialog inc={i} onClose={close} onDone={after} />);
      return;
    }
    if (to === 'under_review' && i.status === 'submitted') {
      run(() => api.post(`/api/incidents/${i.id}/transition`, { to, note: '' }).then(after), 'Review started');
      return;
    }
    setDialog(
      <ReasonDialog
        title={`${label}: ${i.ref}`}
        required={!!requiresNote}
        tone={to === 'rejected' ? 'danger' : 'primary'}
        confirmLabel={label}
        placeholder={to === 'rejected' ? 'e.g. Checked by radio — queue moving normally' : to === 'resolved' ? 'What was done and the outcome' : ''}
        onSubmit={(n) => api.post(`/api/incidents/${i.id}/transition`, { to, note: n }).then(after)}
        onClose={close}
      />,
    );
  };

  return (
    <section className="detail" aria-label={`Incident ${i.ref}`}>
      <div className="detail-head">
        <button className="btn btn-ghost btn-sm back" onClick={() => nav('/incidents')}>
          <ArrowLeft size={14} /> Queue
        </button>
        <div>
          <h2>
            {i.ref} · {CATEGORY_LABEL[i.category]}
          </h2>
          <div className="chips">
            <StatusChip status={i.status} />
            <VerifyChip status={i.status} />
            <SeverityTag severity={i.confirmedSeverity ?? i.severityEstimate} confirmed={!!i.confirmedSeverity} />
            {i.urgent && <span className="chip chip-danger">URGENT</span>}
            {i.reopenCount > 0 && <span className="chip chip-warn">Reopened ×{i.reopenCount}</span>}
            {i.isDemo && <span className="tag tag-sample">DEMO RECORD</span>}
          </div>
        </div>
      </div>

      {i.mergedInto && (
        <Notice tone="info">
          This report was merged into <Link to={`/incidents/${i.mergedInto}`}>{s.incidents.find((x) => x.id === i.mergedInto)?.ref ?? 'the primary incident'}</Link>. Its original content and history are retained below.
        </Notice>
      )}
      {unverified && !i.mergedInto && <Notice tone="warn" title="Unverified report.">Treat as unconfirmed until the control room verifies it. A single unverified report never triggers a public instruction.</Notice>}

      {i.status === 'verified' && (() => {
        const f = [...d.history].reverse().find((h) => h.kind === 'feasibility');
        return f ? (
          <Notice tone="warn" title="Returned for reassignment.">
            {f.note} Choose a team with an approved route below.
          </Notice>
        ) : null;
      })()}
      {transitions.length > 0 && (
        <div className="btn-row transitions">
          {transitions.map((t) => (
            <button key={t.to + t.label} className={`btn ${t.to === 'rejected' ? 'btn-danger-ghost' : t.to === 'verified' || t.to === 'closed' ? 'btn-primary' : ''}`} onClick={() => doTransition(t.to, t.label, t.requiresNote)}>
              {t.to === 'verified' ? <CheckCheck size={15} /> : t.to === 'rejected' ? <Ban size={15} /> : null} {t.label}
            </button>
          ))}
          {canAssign && (
            <button className="btn btn-primary" onClick={() => setShowAssign((x) => !x)}>
              <UserPlus size={15} /> Assign responder
            </button>
          )}
          {can(role, 'incident.review') && !unverified && !i.mergedInto && !['closed', 'rejected'].includes(i.status) && (
            <button className="btn btn-ghost" onClick={() => setDialog(<SeverityDialog inc={i} onClose={close} onDone={after} />)}>
              Confirm severity…
            </button>
          )}
        </div>
      )}

      {showAssign && canAssign && <AssignPanel inc={i} onDone={async () => { setShowAssign(false); await after(); }} />}

      {s.stages?.[i.id] && !i.mergedInto && (
        <Card title="Response stages" subtitle={`Targets for ${i.confirmedSeverity ?? i.severityEstimate} ${CATEGORY_LABEL[i.category].toLowerCase()} (configurable in Event Setup)`}>
          <StageTimeline st={s.stages[i.id]} />
        </Card>
      )}

      <div className="detail-grid">
        <Card title="Original report" className="report-card">
          <p className="report-text">{i.description}</p>
          <dl className="kv">
            <dt>Reporter</dt>
            <dd>{i.reporterName}</dd>
            <dt>Location</dt>
            <dd>
              {zone?.name ?? 'No zone'} {i.lat != null && <span className="muted tiny">({i.lat.toFixed(5)}, {i.lng!.toFixed(5)})</span>}
            </dd>
            <dt>Created on device</dt>
            <dd>{fmtDateTime(i.createdLocalAt)}</dd>
            <dt>Received by server</dt>
            <dd>
              {fmtDateTime(i.receivedAt)}
              {new Date(i.receivedAt).getTime() - new Date(i.createdLocalAt).getTime() > 60000 && (
                <span className="tag tag-warn">delivered {duration((new Date(i.receivedAt).getTime() - new Date(i.createdLocalAt).getTime()) / 1000)} after creation (offline queue)</span>
              )}
            </dd>
            <dt>Severity</dt>
            <dd>
              Reporter estimate: {i.severityEstimate}
              {i.confirmedSeverity ? ` · Confirmed: ${i.confirmedSeverity}` : ' · Not yet confirmed'}
            </dd>
            {i.attachmentNote && (
              <>
                <dt>Evidence note</dt>
                <dd>{i.attachmentNote}</dd>
              </>
            )}
            <dt>Timeline</dt>
            <dd className="small">
              Verified {fmtTime(i.verifiedAt)} · Assigned {fmtTime(i.assignedAt)} · Acknowledged {fmtTime(i.acknowledgedAt)} · Resolved {fmtTime(i.resolvedAt)} · Closed {fmtTime(i.closedAt)}
            </dd>
          </dl>
        </Card>
        <div className="mini-map">
          <VenueMap snap={s} height={260} compact showControls={false} showLegend={false} selection={{ type: 'incident', id: i.id }} highlights={routeHighlights} focus={i.lat != null ? [i.lat, i.lng!] : null} initialLayers={{ responders: true }} />
        </div>
      </div>

      {(d.possibleDuplicates.length > 0 || d.mergedChildren.length > 0 || can(role, 'incident.merge')) && !i.mergedInto && (
        <DuplicatesCard d={d} onDone={after} />
      )}

      {d.assignments.length > 0 && (
        <Card title="Assignments" subtitle="Available → Assigned → Acknowledged → En route → On scene → Resolved">
          {d.assignments.map((a) => {
            const r = responders.get(a.responderId);
            const next = ASSIGNMENT_FLOW[a.status];
            return (
              <div key={a.id} className={`asg asg-${a.status}`}>
                <div className="asg-head">
                  <strong>{r?.name ?? a.responderId}</strong>
                  <span className={`chip ${a.status === 'assigned' ? 'chip-warn' : ['declined', 'unable', 'cancelled'].includes(a.status) ? 'chip-muted' : a.status === 'resolved' ? 'chip-ok' : 'chip-info'}`}>{ASSIGNMENT_LABEL[a.status]}</span>
                  {a.escalatedAt && <span className="chip chip-danger">ESCALATED</span>}
                </div>
                {a.escalationReason && <Notice tone="warn">{a.escalationReason}</Notice>}
                <ol className="asg-steps">
                  <li className="done">Assigned {fmtTime(a.assignedAt, true)}</li>
                  <li className={a.acknowledgedAt ? 'done' : ''}>Acknowledged {fmtTime(a.acknowledgedAt, true)}</li>
                  <li className={a.enRouteAt ? 'done' : ''}>En route {fmtTime(a.enRouteAt, true)}</li>
                  <li className={a.onSceneAt ? 'done' : ''}>On scene {fmtTime(a.onSceneAt, true)}</li>
                  <li className={a.resolvedAt ? 'done' : ''}>Resolved {fmtTime(a.resolvedAt, true)}</li>
                </ol>
                {a.note && <p className="small">Instruction: {a.note}</p>}
                {a.closedReason && <p className="small">Note: {a.closedReason}</p>}
                {a.route && <RouteSummary route={a.route} />}
                {can(role, 'assignment.recordOnBehalf') && next.length > 0 && (
                  <div className="btn-row small-btns">
                    <span className="muted tiny">Record on behalf (e.g. radio confirmation):</span>
                    {next.map((to) => (
                      <button
                        key={to}
                        className={`btn btn-sm ${to === 'cancelled' || to === 'unable' || to === 'declined' ? 'btn-danger-ghost' : ''}`}
                        onClick={() =>
                          setDialog(
                            <ReasonDialog
                              title={`${r?.name}: ${ASSIGNMENT_LABEL[to]}`}
                              required
                              label="How was this confirmed? / note"
                              placeholder="e.g. Confirmed by radio, channel 1"
                              onSubmit={(n) => api.post(`/api/assignments/${a.id}/status`, { status: to, note: n }).then(after)}
                              onClose={close}
                            />,
                          )
                        }
                      >
                        {ASSIGNMENT_LABEL[to].replace(' (awaiting acknowledgement)', '')}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </Card>
      )}

      {d.actions.length > 0 && <PlaybookCard inc={i} actions={d.actions} onDone={after} openAssign={() => setShowAssign(true)} setDialog={setDialog} />}

      <Card title="History" subtitle="Append-only. The original report and every change are preserved.">
        <ol className="timeline">
          {d.history.map((h) => (
            <li key={h.id} className={`tl tl-${h.kind}`}>
              <span className="tl-time">{fmtTime(h.createdAt, true)}</span>
              <div>
                <div className="tl-head">
                  <strong>{h.actorName ?? 'System'}</strong> · {h.kind.replace(/_/g, ' ')}
                  {h.fromStatus || h.toStatus ? (
                    <span className="muted">
                      {' '}
                      {h.fromStatus ? STATUS_LABEL[h.fromStatus] : '—'} → {h.toStatus ? STATUS_LABEL[h.toStatus] : '—'}
                    </span>
                  ) : null}
                </div>
                {h.note && <div className="tl-note">{h.note}</div>}
              </div>
            </li>
          ))}
        </ol>
        <form
          className="note-form"
          onSubmit={async (e) => {
            e.preventDefault();
            if (!note.trim()) return;
            await run(() => api.post(`/api/incidents/${i.id}/notes`, { note }).then(after), 'Note added');
            setNote('');
          }}
        >
          <input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Add an update note…" maxLength={1000} aria-label="Add note" />
          <button className="btn" disabled={!note.trim()}>
            Add note
          </button>
        </form>
      </Card>
      {dialog}
    </section>
  );
}

function VerifyDialog({ inc, onClose, onDone }: { inc: Incident; onClose: () => void; onDone: () => Promise<void> }) {
  const [sev, setSev] = useState<Severity>(inc.severityEstimate);
  return (
    <ReasonDialog
      title={`Verify ${inc.ref}`}
      label="How was it verified?"
      placeholder="e.g. Confirmed with steward by radio / second independent report"
      confirmLabel="Verify"
      extra={
        <label className="field">
          <span>Confirmed severity</span>
          <select value={sev} onChange={(e) => setSev(e.target.value as Severity)}>
            {SEVERITIES.map((x) => (
              <option key={x} value={x}>
                {x}
                {x === 'critical' ? ' — designated critical (immediate safety-authority attention)' : ''}
              </option>
            ))}
          </select>
        </label>
      }
      onSubmit={(n) => api.post(`/api/incidents/${inc.id}/transition`, { to: 'verified', note: n, confirmedSeverity: sev }).then(onDone)}
      onClose={onClose}
    />
  );
}

function SeverityDialog({ inc, onClose, onDone }: { inc: Incident; onClose: () => void; onDone: () => Promise<void> }) {
  const [sev, setSev] = useState<Severity>(inc.confirmedSeverity ?? inc.severityEstimate);
  return (
    <ReasonDialog
      title={`Confirmed severity: ${inc.ref}`}
      label="Reason"
      extra={
        <label className="field">
          <span>Severity</span>
          <select value={sev} onChange={(e) => setSev(e.target.value as Severity)}>
            {SEVERITIES.map((x) => (
              <option key={x}>{x}</option>
            ))}
          </select>
        </label>
      }
      onSubmit={(n) => api.post(`/api/incidents/${inc.id}/severity`, { severity: sev, note: n }).then(onDone)}
      onClose={onClose}
    />
  );
}

export function RouteSummary({ route, compact }: { route: RouteResult; compact?: boolean }) {
  const { snap } = useLive();
  const n = (id: string) => snap!.nodes.find((x) => x.id === id)?.name ?? id;
  const seg = (id: string) => snap!.segments.find((x) => x.id === id);
  if (!route.found) {
    return (
      <Notice tone="danger" title="No valid route found.">
        {route.reason}
      </Notice>
    );
  }
  const closedNow = route.segmentIds.filter((id) => seg(id)?.status === 'closed');
  return (
    <div className="route-sum">
      <div className="route-sum-head">
        <Navigation size={14} /> {n(route.from)} → {n(route.to)} · <strong>{metres(route.distanceM)}</strong> ({route.mode}, {route.access} access, configured distance)
      </div>
      {closedNow.length > 0 && <Notice tone="danger">A segment on this route has since been CLOSED ({closedNow.map((id) => seg(id)?.name).join(', ')}). Recompute before use.</Notice>}
      {!compact && (
        <ol className="route-segs">
          {route.segmentIds.map((id) => (
            <li key={id}>
              {seg(id)?.name ?? id} <span className="muted tiny">{seg(id)?.distanceM} m</span>
              {seg(id)?.status === 'under_review' && <span className="tag tag-warn">under review</span>}
            </li>
          ))}
        </ol>
      )}
      {route.warnings.map((w, k) => (
        <Notice key={k} tone="warn">
          {w}
        </Notice>
      ))}
      {route.constraints.length > 0 && (
        <ul className="constraints small">
          {route.constraints.map((c, k) => (
            <li key={k}>{c}</li>
          ))}
        </ul>
      )}
      <div className="tiny muted">
        {route.approvalStatus === 'approved_network' ? 'All segments are in the approved venue network.' : 'Contains unapproved segments.'} Segment status as of {fmtTime(route.oldestStatusAt)} (oldest) · computed {fmtTime(route.computedAt, true)}. A route existing in the network does not
        guarantee it is physically safe.
      </div>
    </div>
  );
}

function AssignPanel({ inc, onDone }: { inc: Incident; onDone: () => Promise<void> }) {
  const { snap } = useLive();
  const run = useAction();
  const [note, setNote] = useState('');
  const [chosen, setChosen] = useState<string | null>(null);
  const s = snap!;
  const options = (s.responders ?? [])
    .map((r) => ({ r, route: r.status === 'available' ? previewRoute(s, r, inc) : null }))
    .sort((a, b) => Number(b.r.status === 'available') - Number(a.r.status === 'available') || Number(!!b.route?.found) - Number(!!a.route?.found) || (a.route?.distanceM ?? 1e9) - (b.route?.distanceM ?? 1e9));
  const suggestedKind = inc.category === 'medical' ? 'medical' : null;
  const pick = options.find((o) => o.r.id === chosen);
  return (
    <Card title="Assign a responder" subtitle="Routes are checked against the approved network, current closures, travel mode and access level. Assignment is a human decision." className="assign-panel">
      <div className="resp-options">
        {options.map(({ r, route }) => (
          <label key={r.id} className={`resp-opt ${r.status !== 'available' ? 'disabled' : ''} ${chosen === r.id ? 'on' : ''}`}>
            <input type="radio" name="resp" disabled={r.status !== 'available'} checked={chosen === r.id} onChange={() => setChosen(r.id)} />
            <div>
              <strong>{r.name}</strong> {suggestedKind && r.kind === suggestedKind && <span className="tag tag-verified">matches category</span>}
              <div className="tiny muted">
                {r.team} · {r.modes.join('+')} · {r.access} access · {r.status === 'available' ? 'Available' : `Busy (${r.status.replace('_', ' ')})`}
              </div>
              {r.status === 'available' && (route ? route.found ? <div className="tiny">Route: {metres(route.distanceM)} via {route.segmentIds.length} segment(s){route.warnings.length ? ' — includes segment under review' : ''}</div> : <div className="tiny text-danger">No valid route in approved network</div> : <div className="tiny muted">Location unknown — route not computed</div>)}
            </div>
          </label>
        ))}
      </div>
      {pick?.route && <RouteSummary route={pick.route} />}
      <label className="field">
        <span>
          Instruction to responder <em className="opt">optional</em>
        </span>
        <input value={note} onChange={(e) => setNote(e.target.value)} maxLength={500} placeholder="e.g. Assess Gate B plaza and report back" />
      </label>
      <button className="btn btn-primary" disabled={!chosen} onClick={() => run(() => api.post(`/api/incidents/${inc.id}/assignments`, { responderId: chosen, note }).then(onDone), 'Assignment sent — awaiting acknowledgement')}>
        <UserPlus size={15} /> Assign {pick ? pick.r.name : ''}
      </button>
      {pick?.route && !pick.route.found && <p className="small text-danger">You can still assign, but the responder has no approved route. Escalate and agree an access plan by radio.</p>}
    </Card>
  );
}

function DuplicatesCard({ d, onDone }: { d: Detail; onDone: () => Promise<void> }) {
  const { snap } = useLive();
  const { me } = useSession();
  const [target, setTarget] = useState('');
  const [dialog, setDialog] = useState<React.ReactNode>(null);
  const i = d.incident;
  const canMerge = can(me!.user.role, 'incident.merge');
  const others = snap!.incidents.filter((x) => x.id !== i.id && !x.mergedInto && !['closed', 'rejected'].includes(x.status));
  const merge = (childId: string, parentId: string, label: string) =>
    setDialog(
      <ReasonDialog
        title={label}
        label="Why are these the same incident?"
        required
        confirmLabel="Merge"
        extra={<p className="small">The merged report is kept with its reporter, timestamps and history. Distinct reporters still count as independent corroboration.</p>}
        onSubmit={(n) => api.post(`/api/incidents/${childId}/merge`, { intoId: parentId, note: n }).then(onDone)}
        onClose={() => setDialog(null)}
      />,
    );
  return (
    <Card title={<><GitMerge size={16} /> Related reports</>} subtitle="Possible duplicates are flagged by category, place and time window. Nothing is merged or deleted automatically.">
      {d.possibleDuplicates.length === 0 && d.mergedChildren.length === 0 && <p className="muted small">No possible duplicates flagged.</p>}
      {d.possibleDuplicates.map((x) => (
        <div key={x.id} className="dupe">
          <AlertTriangle size={14} className="text-warn" />
          <div>
            <Link to={`/incidents/${x.id}`}>{x.ref}</Link> · {CATEGORY_LABEL[x.category]} · by {x.reporterName} · {fmtTime(x.receivedAt)} · <StatusChip status={x.status} />
            <div className="small">{x.description}</div>
          </div>
          {canMerge && !x.mergedInto && (
            <div className="btn-col">
              <button className="btn btn-sm" onClick={() => merge(x.id, i.id, `Merge ${x.ref} into ${i.ref}`)}>
                Merge {x.ref} into this
              </button>
              <button className="btn btn-sm btn-ghost" onClick={() => merge(i.id, x.id, `Merge ${i.ref} into ${x.ref}`)}>
                Merge this into {x.ref}
              </button>
            </div>
          )}
        </div>
      ))}
      {d.mergedChildren.length > 0 && (
        <div className="small">
          <strong>Merged into this incident:</strong>{' '}
          {d.mergedChildren.map((c) => (
            <span key={c.id}>
              <Link to={`/incidents/${c.id}`}>{c.ref}</Link> (by {c.reporterName}){' '}
            </span>
          ))}
        </div>
      )}
      {canMerge && others.length > 0 && (
        <div className="merge-any">
          <select value={target} onChange={(e) => setTarget(e.target.value)} aria-label="Merge into another incident">
            <option value="">Merge this report into…</option>
            {others.map((o) => (
              <option key={o.id} value={o.id}>
                {o.ref} — {CATEGORY_LABEL[o.category]} ({fmtTime(o.receivedAt)})
              </option>
            ))}
          </select>
          <button className="btn btn-sm" disabled={!target} onClick={() => merge(i.id, target, `Merge ${i.ref} into ${others.find((o) => o.id === target)?.ref}`)}>
            Merge…
          </button>
        </div>
      )}
      {dialog}
    </Card>
  );
}

function PlaybookCard({ inc, actions, onDone, openAssign, setDialog }: { inc: Incident; actions: IncidentAction[]; onDone: () => Promise<void>; openAssign: () => void; setDialog: (n: React.ReactNode) => void }) {
  const { snap } = useLive();
  const { me } = useSession();
  const pb = snap!.playbooks?.find((p) => p.id === actions[0]?.playbookId);
  const canEdit = can(me!.user.role, 'incident.playbook');
  const close = () => setDialog(null);
  const zone = snap!.zones.find((z) => z.id === inc.zoneId);

  const mark = (a: IncidentAction, status: IncidentAction['status']) => {
    const needs = status === 'skipped' || status === 'overridden' || (status === 'done' && a.approval === 'safety_authority');
    setDialog(
      <ReasonDialog
        title={`${status === 'done' ? 'Complete' : status === 'skipped' ? 'Skip' : status === 'overridden' ? 'Override' : 'Reopen'}: ${a.title}`}
        required={needs}
        label={a.approval === 'safety_authority' && status === 'done' ? 'Who authorised this decision, and what was decided?' : status === 'overridden' ? 'Override reason (recorded in the audit log)' : 'Note'}
        onSubmit={(n) => api.post(`/api/actions/${a.id}`, { status, note: n }).then(onDone)}
        onClose={close}
      />,
    );
  };

  const shortcut = (a: IncidentAction) => {
    if (a.action === 'assign') return <button className="btn btn-sm btn-ghost" onClick={openAssign}><UserPlus size={13} /> Assign</button>;
    if (a.action === 'review_routes' || a.action === 'compute_route') return <Link className="btn btn-sm btn-ghost" to="/routes"><RouteIcon size={13} /> Routes</Link>;
    if (a.action === 'close_exit' && zone)
      return (
        <span className="btn-row">
          {zone.exitIds.map((id) => {
            const f = snap!.facilities.find((x) => x.id === id);
            return f ? (
              <button key={id} className="btn btn-sm btn-ghost" onClick={() => setDialog(<FacilityStatusDialog facilityId={id} onClose={close} />)}>
                {f.status === 'open' ? 'Mark unavailable:' : 'Reopen:'} {f.name}
              </button>
            ) : null;
          })}
        </span>
      );
    return null;
  };

  return (
    <Card title={<><ClipboardCheck size={16} /> Playbook: {pb?.title ?? 'Response playbook'}</>} subtitle={pb ? `Trigger: ${pb.trigger} Escalation: ${pb.escalation}` : undefined}>
      <p className="small muted">Recommended actions only. Each step needs a human decision; steps marked “safety authority” record who authorised them.</p>
      <ol className="playbook">
        {actions.map((a) => {
          const overdue = a.status === 'pending' && a.dueAt && new Date(a.dueAt).getTime() < Date.now();
          return (
            <li key={a.id} className={`pb-step pb-${a.status} ${overdue ? 'overdue' : ''}`}>
              <div className="pb-main">
                <div className="pb-title">
                  {a.title}
                  {a.approval === 'safety_authority' && <span className="tag tag-critical">safety authority approval</span>}
                  {a.approval === 'coordinator' && <span className="tag">coordinator</span>}
                </div>
                <div className="small muted">{a.detail}</div>
                <div className="tiny">
                  {a.status === 'pending' ? (
                    a.dueAt ? (
                      <span className={overdue ? 'text-danger' : 'muted'}>{overdue ? 'OVERDUE — ' : ''}target {fmtTime(a.dueAt)} (priority from playbook)</span>
                    ) : (
                      <span className="muted">No target time</span>
                    )
                  ) : (
                    <span>
                      <strong>{a.status.toUpperCase()}</strong> {fmtTime(a.completedAt)} {a.note && `— ${a.note}`}
                    </span>
                  )}
                </div>
              </div>
              {canEdit && (
                <div className="pb-actions">
                  {a.status === 'pending' ? (
                    <>
                      {shortcut(a)}
                      <button className="btn btn-sm" onClick={() => mark(a, 'done')}>
                        <CheckCheck size={13} /> Done
                      </button>
                      <button className="btn btn-sm btn-ghost" onClick={() => mark(a, 'skipped')} title="Skip with reason">
                        <SkipForward size={13} />
                      </button>
                      <button className="btn btn-sm btn-ghost" onClick={() => mark(a, 'overridden')}>
                        Override
                      </button>
                    </>
                  ) : (
                    <button className="btn btn-sm btn-ghost" onClick={() => mark(a, 'pending')}>
                      Reopen step
                    </button>
                  )}
                </div>
              )}
            </li>
          );
        })}
      </ol>
    </Card>
  );
}

