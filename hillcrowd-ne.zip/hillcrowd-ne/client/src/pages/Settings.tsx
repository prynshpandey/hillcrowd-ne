import { useEffect, useState } from 'react';
import { useLive } from '../lib/live';
import { useSession } from '../lib/session';
import { api } from '../lib/api';
import { can, ROLE_LABEL } from '@shared/permissions';
import type { Role } from '@shared/types';
import { Card, Modal, Notice, useAction } from '../components/ui';
import { fmtDateTime } from '../lib/format';
import { LOCALES, language, setLanguage } from '../i18n';

interface AuditRow {
  id: number;
  at: string;
  actorName: string | null;
  actorRole: string | null;
  action: string;
  entityType: string;
  entityId: string | null;
  details: Record<string, unknown>;
}

export default function SettingsPage() {
  const { snap } = useLive();
  const { me } = useSession();
  const [rows, setRows] = useState<AuditRow[]>([]);
  const [q, setQ] = useState('');
  const [global, setGlobal] = useState(false);
  const isAdmin = me!.user.role === 'admin';

  useEffect(() => {
    api.get<AuditRow[]>(`/api/events/${snap!.event.id}/audit?limit=500${global ? '&global=1' : ''}`).then(setRows).catch(() => setRows([]));
  }, [snap!.serverTime, global]);

  const shown = rows.filter((r) => !q || `${r.action} ${r.actorName} ${JSON.stringify(r.details)}`.toLowerCase().includes(q.toLowerCase()));

  return (
    <div className="page">
      <div className="page-head">
        <h1>Settings & audit log</h1>
      </div>
      <div className="grid-2">
        <Card title="Language">
          <label className="field">
            <span>Interface language</span>
            <select
              value={language()}
              onChange={(e) => {
                setLanguage(e.target.value);
                window.location.reload();
              }}
            >
              {Object.entries(LOCALES).map(([k, v]) => (
                <option key={k} value={k}>
                  {v.label}
                </option>
              ))}
            </select>
          </label>
          <p className="small muted">
            English is the only bundled language. The interface is built so Khasi, Garo and other languages can be added as translation files (<code>client/src/i18n/&lt;code&gt;.json</code>) without changing application logic. No unverified translations are shipped; each file
            should be reviewed by a competent speaker before use.
          </p>
        </Card>
        <Card title="About this deployment">
          <p className="small">HillCrowd NE is a coordination aid for authorised event personnel. It does not issue evacuation orders, close public roads, dispatch ambulances or contact emergency services, and it does not replace official warning systems.</p>
          {snap!.event.isDemo && <Notice tone="warn">This event is a demonstration scenario using a fictional venue layout and simulated records.</Notice>}
        </Card>
      </div>
      {isAdmin && can(me!.user.role, 'users.manage') && <UsersCard />}
      <Card
        title="Audit log"
        subtitle="Record of operational and administrative actions. The application cannot edit or delete entries (database triggers reject it), but someone with direct access to the database file could still alter it — a production deployment would also ship entries to write-once external storage."
        actions={
          <>
            {isAdmin && (
              <label className="check small">
                <input type="checkbox" checked={global} onChange={(e) => setGlobal(e.target.checked)} /> include system-wide entries
              </label>
            )}
            <input type="search" placeholder="Filter…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Filter audit log" />
          </>
        }
      >
        <div className="table-wrap tall">
          <table className="table compact audit">
            <thead>
              <tr>
                <th>#</th>
                <th>Time</th>
                <th>Actor</th>
                <th>Action</th>
                <th>Entity</th>
                <th>Details</th>
              </tr>
            </thead>
            <tbody>
              {shown.map((r) => (
                <tr key={r.id}>
                  <td className="tiny muted">{r.id}</td>
                  <td className="nowrap small">{fmtDateTime(r.at)}</td>
                  <td className="small">
                    {r.actorName}
                    <div className="tiny muted">{r.actorRole}</div>
                  </td>
                  <td>
                    <code>{r.action}</code>
                  </td>
                  <td className="tiny">
                    {r.entityType} {r.entityId}
                  </td>
                  <td className="tiny audit-details">{JSON.stringify(r.details)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

interface UserRow {
  id: string;
  username: string;
  displayName: string;
  role: Role;
  isDemo: boolean;
  active: boolean;
  events: string[];
}

function UsersCard() {
  const { me } = useSession();
  const { snap } = useLive();
  const run = useAction();
  const [users, setUsers] = useState<UserRow[]>([]);
  const [creating, setCreating] = useState(false);
  const load = () => api.get<UserRow[]>('/api/users').then(setUsers).catch(() => {});
  useEffect(() => {
    load();
  }, []);
  return (
    <Card title="Users & roles" actions={<button className="btn btn-sm btn-primary" onClick={() => setCreating(true)}>Add user</button>}>
      <table className="table compact">
        <thead>
          <tr>
            <th>User</th>
            <th>Role</th>
            <th>Events</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {users.map((u) => (
            <tr key={u.id}>
              <td>
                {u.displayName} <code className="tiny">{u.username}</code> {u.isDemo && <span className="tag tag-sample">demo</span>}
              </td>
              <td>
                <select
                  value={u.role}
                  disabled={u.id === me!.user.id}
                  title={u.id === me!.user.id ? 'You cannot change your own role' : undefined}
                  onChange={(e) => run(() => api.patch(`/api/users/${u.id}`, { role: e.target.value }).then(load), 'Role updated (user must sign in again)')}
                >
                  {(Object.keys(ROLE_LABEL) as Role[]).map((r) => (
                    <option key={r} value={r}>
                      {ROLE_LABEL[r]}
                    </option>
                  ))}
                </select>
              </td>
              <td className="tiny">{u.events.length}</td>
              <td>
                <button className="btn btn-sm btn-ghost" disabled={u.id === me!.user.id} onClick={() => run(() => api.patch(`/api/users/${u.id}`, { active: !u.active }).then(load), u.active ? 'User deactivated' : 'User activated')}>
                  {u.active ? 'Active — deactivate' : 'Inactive — activate'}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {creating && <NewUser eventId={snap!.event.id} onClose={() => setCreating(false)} onDone={load} />}
    </Card>
  );
}

function NewUser({ eventId, onClose, onDone }: { eventId: string; onClose: () => void; onDone: () => void }) {
  const run = useAction();
  const [f, setF] = useState({ username: '', displayName: '', role: 'steward' as Role, password: '' });
  return (
    <Modal title="Add user" onClose={onClose}>
      <div className="form-grid">
        <label className="field">
          <span>Username</span>
          <input value={f.username} onChange={(e) => setF({ ...f, username: e.target.value })} />
        </label>
        <label className="field">
          <span>Display name</span>
          <input value={f.displayName} onChange={(e) => setF({ ...f, displayName: e.target.value })} />
        </label>
        <label className="field">
          <span>Role</span>
          <select value={f.role} onChange={(e) => setF({ ...f, role: e.target.value as Role })}>
            {(Object.keys(ROLE_LABEL) as Role[]).map((r) => (
              <option key={r} value={r}>
                {ROLE_LABEL[r]}
              </option>
            ))}
          </select>
        </label>
        <label className="field">
          <span>Initial password (min 10 characters)</span>
          <input type="password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} autoComplete="new-password" />
        </label>
        <p className="tiny muted">The user is given access to the current event.</p>
      </div>
      <div className="modal-actions">
        <button className="btn" onClick={onClose}>
          Cancel
        </button>
        <button
          className="btn btn-primary"
          onClick={async () => {
            const ok = await run(() => api.post('/api/users', { ...f, eventIds: [eventId] }), 'User created');
            if (ok) {
              onDone();
              onClose();
            }
          }}
        >
          Create user
        </button>
      </div>
    </Modal>
  );
}
