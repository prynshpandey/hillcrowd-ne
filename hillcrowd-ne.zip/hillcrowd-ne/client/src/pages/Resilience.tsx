import { useEffect, useMemo, useRef, useState } from 'react';
import { CloudRain, DoorOpen, FlaskConical, HeartPulse, RadioTower, RotateCcw, Route as RouteIcon, Save, ShieldAlert, ShieldCheck, Truck, Users } from 'lucide-react';
import { useLive } from '../lib/live';
import { useSession } from '../lib/session';
import { api } from '../lib/api';
import { can } from '@shared/permissions';
import type { LinkKind, LinkResult, ResilienceReport, Scenario } from '@shared/resilience';
import { Card, Empty, Notice, useAction } from '../components/ui';
import { VenueMap, type RouteHighlight } from '../components/VenueMap';
import { fmtDateTime, metres } from '../lib/format';
import type { Snapshot } from '../lib/types';

const EMPTY: Scenario = { closedSegments: [], closedFacilities: [], weatherExposedClosed: false, unavailableResponders: [], commsLostZones: [] };

const KIND: Record<LinkKind, { icon: typeof DoorOpen; label: string }> = {
  egress: { icon: DoorOpen, label: 'Walk-out' },
  medical_access: { icon: HeartPulse, label: 'Medical access' },
  vehicle_access: { icon: Truck, label: 'Vehicle access' },
  approved_route: { icon: RouteIcon, label: 'Approved route' },
};

function isEmpty(sc: Scenario) {
  return !sc.closedSegments.length && !sc.closedFacilities.length && !sc.weatherExposedClosed && !(sc.unavailableResponders ?? []).length && !(sc.commsLostZones ?? []).length;
}

/** Display copy of the snapshot with simulated failures applied, so the map shows the scenario. */
function simulatedSnap(snap: Snapshot, sc: Scenario): Snapshot {
  const segs = new Set(sc.closedSegments);
  const facs = new Set(sc.closedFacilities);
  return {
    ...snap,
    segments: snap.segments.map((s) => (segs.has(s.id) || (sc.weatherExposedClosed && s.weatherExposed) ? { ...s, status: 'closed', statusReason: 'Simulated' } : s)),
    facilities: snap.facilities.map((f) => (facs.has(f.id) ? { ...f, status: 'closed', statusReason: 'Simulated' } : f)),
    incidents: [],
  };
}

export default function ResiliencePage() {
  const { snap } = useLive();
  const { me } = useSession();
  const run = useAction();
  const s = snap!;
  const [sc, setSc] = useState<Scenario>(EMPTY);
  const [report, setReport] = useState<ResilienceReport | null>(s.access ?? null);
  const [busy, setBusy] = useState(false);
  const [selected, setSelected] = useState<string | null>(null);
  const [name, setName] = useState('');
  const seq = useRef(0);

  const presets = useMemo(() => {
    const seg = (re: RegExp) => s.segments.find((x) => re.test(x.name))?.id;
    const fac = (re: RegExp) => s.facilities.find((x) => re.test(x.name))?.id;
    const lower = seg(/^Lower service road/);
    const ringNE = seg(/ring road, north–east/);
    const exitD = fac(/^Exit D/);
    const med1 = s.responders?.find((r) => /^Medical Team 1/.test(r.name))?.id;
    const zoneC = s.zones.find((z) => /Zone C/.test(z.name))?.id;
    const list: { label: string; icon: typeof CloudRain; sc: Scenario; hint: string }[] = [];
    if (lower) list.push({ label: 'Lower service road closed', icon: RouteIcon, sc: { ...EMPTY, closedSegments: [lower] }, hint: 'Single failure: does an approved detour exist?' });
    if (lower && ringNE) list.push({ label: '…and the ring-road detour fails', icon: ShieldAlert, sc: { ...EMPTY, closedSegments: [lower, ringNE] }, hint: 'Second failure: exposes the remaining access problem.' });
    if (s.segments.some((x) => x.weatherExposed)) list.push({ label: 'Monsoon downpour', icon: CloudRain, sc: { ...EMPTY, weatherExposedClosed: true }, hint: 'All sections marked rain-exposed become unusable.' });
    if (exitD) list.push({ label: 'Exit D unusable', icon: DoorOpen, sc: { ...EMPTY, closedFacilities: [exitD] }, hint: 'A required exit fails.' });
    if (med1) list.push({ label: 'Medical Team 1 unavailable', icon: Users, sc: { ...EMPTY, unavailableResponders: [med1] }, hint: 'Is every zone still covered?' });
    if (zoneC) list.push({ label: 'Mobile data lost in Zone C', icon: RadioTower, sc: { ...EMPTY, commsLostZones: [zoneC] }, hint: 'Is a communication fallback recorded?' });
    return list;
  }, [s.segments, s.facilities, s.responders, s.zones]);

  useEffect(() => {
    const id = ++seq.current;
    setBusy(true);
    const t = setTimeout(async () => {
      try {
        const r = await api.post<ResilienceReport>(`/api/events/${s.event.id}/resilience/simulate`, { scenario: sc });
        if (id === seq.current) setReport(r);
      } catch {
        /* keep previous report */
      } finally {
        if (id === seq.current) setBusy(false);
      }
    }, 200);
    return () => clearTimeout(t);
  }, [sc, s.event.id, s.serverTime]);

  const toggle = (k: 'closedSegments' | 'closedFacilities' | 'unavailableResponders' | 'commsLostZones', id: string) =>
    setSc((x) => {
      const cur = (x[k] as string[] | undefined) ?? [];
      return { ...x, [k]: cur.includes(id) ? cur.filter((y) => y !== id) : [...cur, id] };
    });

  const displaySnap = useMemo(() => simulatedSnap(s, sc), [s, sc]);
  const highlights: RouteHighlight[] = useMemo(() => {
    if (!report) return [];
    const h: RouteHighlight[] = [];
    const focus = report.links.filter((l) => (selected ? l.link.id === selected : l.status !== 'ok'));
    for (const l of focus) {
      if (l.status === 'lost' && l.plan) h.push({ segmentIds: l.plan.segmentIds, tone: 'blocked' });
      if (l.status === 'detour' && l.scenario) h.push({ segmentIds: l.scenario.segmentIds, tone: 'alternative' });
      if (l.status === 'ok' && l.scenario && selected) h.push({ segmentIds: l.scenario.segmentIds, tone: 'primary' });
    }
    return h;
  }, [report, selected]);

  const live = s.access;
  const simulated = !isEmpty(sc);

  return (
    <div className="page resilience">
      <div className="page-head">
        <div>
          <h1>
            <FlaskConical size={22} className="h-ico" /> Resilience Lab
          </h1>
          <p className="muted">Test how the venue's approved route network holds up when roads, exits, teams or mobile data fail — before attendees arrive and during the event. Simulations never change live data, and no route is ever invented.</p>
        </div>
      </div>

      {live && (
        <div className="kpis kpis-4">
          <div className="kpi">
            <span className="kpi-n">{live.summary.links}</span>
            <span className="kpi-l">critical access links checked</span>
          </div>
          <div className={`kpi ${live.singlePointRanking.length ? 'kpi-warn' : ''}`}>
            <span className="kpi-n">{live.singlePointRanking.length}</span>
            <span className="kpi-l">single points of failure in the plan</span>
          </div>
          <div className={`kpi ${live.links.some((l) => l.redundancy === 1) ? 'kpi-warn' : ''}`}>
            <span className="kpi-n">{live.links.filter((l) => l.redundancy === 1).length}</span>
            <span className="kpi-l">links with only one approved route</span>
          </div>
          <div className={`kpi ${live.summary.lost ? 'kpi-alert' : ''}`}>
            <span className="kpi-n">{live.summary.lost}</span>
            <span className="kpi-l">live access gaps right now</span>
          </div>
        </div>
      )}

      <div className="lab-layout">
        <div className="stack">
          <Card title="Failure scenario" subtitle="Pick a preset or build your own. Results update instantly.">
            <div className="preset-grid">
              {presets.map((p) => (
                <button key={p.label} className={`preset ${JSON.stringify(sc) === JSON.stringify(p.sc) ? 'on' : ''}`} onClick={() => { setSc(p.sc); setSelected(null); }} title={p.hint}>
                  <p.icon size={16} />
                  <span>
                    <strong>{p.label}</strong>
                    <em>{p.hint}</em>
                  </span>
                </button>
              ))}
            </div>
            <details className="custom-sc">
              <summary>Custom scenario</summary>
              <fieldset className="pick">
                <legend>Route segments that fail</legend>
                <div className="pick-grid">
                  {s.segments.map((x) => (
                    <label key={x.id} className="check">
                      <input type="checkbox" checked={sc.closedSegments.includes(x.id)} onChange={() => toggle('closedSegments', x.id)} /> {x.name}
                      {x.weatherExposed && <span className="tag tag-rain">rain-exposed</span>}
                    </label>
                  ))}
                </div>
              </fieldset>
              <label className="check">
                <input type="checkbox" checked={!!sc.weatherExposedClosed} onChange={(e) => setSc((x) => ({ ...x, weatherExposedClosed: e.target.checked }))} /> Heavy rain: every rain-exposed section unusable
              </label>
              <fieldset className="pick">
                <legend>Facilities that become unusable</legend>
                <div className="pick-grid">
                  {s.facilities
                    .filter((f) => ['gate', 'exit', 'medical', 'assembly', 'handover'].includes(f.kind))
                    .map((f) => (
                      <label key={f.id} className="check">
                        <input type="checkbox" checked={sc.closedFacilities.includes(f.id)} onChange={() => toggle('closedFacilities', f.id)} /> {f.name}
                      </label>
                    ))}
                </div>
              </fieldset>
              <fieldset className="pick">
                <legend>Teams unavailable</legend>
                {(s.responders ?? []).map((r) => (
                  <label key={r.id} className="check">
                    <input type="checkbox" checked={(sc.unavailableResponders ?? []).includes(r.id)} onChange={() => toggle('unavailableResponders', r.id)} /> {r.name}
                  </label>
                ))}
              </fieldset>
              <fieldset className="pick">
                <legend>Mobile data lost in</legend>
                {s.zones.map((z) => (
                  <label key={z.id} className="check">
                    <input type="checkbox" checked={(sc.commsLostZones ?? []).includes(z.id)} onChange={() => toggle('commsLostZones', z.id)} /> {z.name}
                  </label>
                ))}
              </fieldset>
            </details>
            <div className="btn-row">
              <button className="btn btn-ghost" onClick={() => { setSc(EMPTY); setSelected(null); }} disabled={!simulated}>
                <RotateCcw size={14} /> Back to live network
              </button>
            </div>
            {can(me!.user.role, 'checklist.update') && simulated && (
              <div className="save-test">
                <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Name this stress test, e.g. 'Monsoon + Exit D'" maxLength={160} aria-label="Stress test name" />
                <button
                  className="btn btn-primary"
                  disabled={name.trim().length < 3}
                  onClick={() => run(() => api.post(`/api/events/${s.event.id}/stress-tests`, { name, scenario: sc }).then(() => setName('')), 'Stress test recorded in the readiness log')}
                >
                  <Save size={14} /> Record
                </button>
              </div>
            )}
          </Card>

          {report && <Verdict report={report} simulated={simulated} busy={busy} />}
        </div>

        <div className="lab-map">
          <VenueMap snap={displaySnap} highlights={highlights} initialLayers={{ incidents: false, responders: false }} />
          <div className={`lab-badge ${simulated ? 'sim' : ''}`}>{simulated ? 'SIMULATION — live data unchanged' : 'Live network'}</div>
        </div>
      </div>

      {report && (
        <Card title="Critical access links" subtitle="Plan = all approved segments open. Scenario = live status plus simulated failures. Click a row to show it on the map.">
          <div className="table-wrap">
            <table className="table link-table">
              <thead>
                <tr>
                  <th>Link</th>
                  <th>Resilience in the plan</th>
                  <th>{simulated ? 'Under this scenario' : 'Right now'}</th>
                </tr>
              </thead>
              <tbody>
                {[...report.links]
                  .sort((a, b) => ['lost', 'detour', 'ok'].indexOf(a.status) - ['lost', 'detour', 'ok'].indexOf(b.status) || a.redundancy - b.redundancy)
                  .map((l) => (
                    <LinkRow key={l.link.id} l={l} on={selected === l.link.id} onClick={() => setSelected(selected === l.link.id ? null : l.link.id)} />
                  ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {report && (
        <div className="grid-3">
          <Card title="Single points of failure" subtitle="Segments whose loss alone cuts a critical link (planned network).">
            {report.singlePointRanking.length === 0 ? (
              <Empty>No single segment can cut a critical link.</Empty>
            ) : (
              <ul className="plain spof">
                {report.singlePointRanking.map((r) => (
                  <li key={r.id}>
                    <strong>{r.name}</strong> <span className="tag tag-warn">{r.links.length} link{r.links.length > 1 ? 's' : ''}</span>
                    <div className="tiny muted">{r.links.join(' · ')}</div>
                  </li>
                ))}
              </ul>
            )}
          </Card>
          <Card title="Second-failure exposure" subtitle="Links that survive any one failure but not these pairs.">
            {report.links.every((l) => !l.secondFailures.length) ? (
              <Empty>No two-segment combinations found that cut a redundant link.</Empty>
            ) : (
              <ul className="plain spof">
                {report.links
                  .filter((l) => l.secondFailures.length)
                  .map((l) => (
                    <li key={l.link.id}>
                      <strong>{l.link.label}</strong>
                      {l.secondFailures.slice(0, 3).map((p, i) => (
                        <div key={i} className="tiny">
                          ✕ {p.a.name} + {p.b.name}
                        </div>
                      ))}
                    </li>
                  ))}
              </ul>
            )}
          </Card>
          <Card title="Team coverage & communications">
            {report.coverage.length === 0 ? (
              <Empty>No responders configured.</Empty>
            ) : (
              <table className="table compact">
                <thead>
                  <tr>
                    <th>Zone</th>
                    <th>Medical</th>
                    <th>Stewards</th>
                  </tr>
                </thead>
                <tbody>
                  {report.coverage.map((c) => (
                    <tr key={c.zoneId}>
                      <td className="small">{c.zoneName}</td>
                      <td className={`small ${c.medical.length ? '' : 'text-danger'}`}>{c.medical.length ? c.medical.join(', ') : 'None reachable'}</td>
                      <td className={`small ${c.stewards.length ? '' : 'text-danger'}`}>{c.stewards.length ? c.stewards.join(', ') : 'None reachable'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
            {report.comms.map((c) => (
              <Notice key={c.zoneId} tone={c.gap ? 'danger' : 'ok'}>
                {c.zoneName}: {c.gap ? 'no communication fallback recorded' : `fallback — ${c.fallback}`}
              </Notice>
            ))}
          </Card>
        </div>
      )}

      <Card title="Stress-test log" subtitle="Recorded scenarios and what they found. Feeds the event-readiness review.">
        {(s.stressTests ?? []).length === 0 ? (
          <Empty>No stress tests recorded yet. Run a scenario above and press Record.</Empty>
        ) : (
          <table className="table compact">
            <thead>
              <tr>
                <th>When</th>
                <th>Scenario</th>
                <th>Result</th>
                <th>By</th>
              </tr>
            </thead>
            <tbody>
              {s.stressTests!.map((t) => (
                <tr key={t.id}>
                  <td className="nowrap small">{fmtDateTime(t.runAt)}</td>
                  <td>
                    <strong>{t.name}</strong>
                    {t.gaps.slice(0, 3).map((g, i) => (
                      <div key={i} className="tiny muted">
                        {g.area}: {g.message}
                      </div>
                    ))}
                  </td>
                  <td>{t.summary.gaps ? <span className="chip chip-danger">{t.summary.gaps} gap(s)</span> : <span className="chip chip-ok">No gaps found</span>}</td>
                  <td className="small">{t.runBy}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
    </div>
  );
}

function Verdict({ report, simulated, busy }: { report: ResilienceReport; simulated: boolean; busy: boolean }) {
  const crit = report.gaps.filter((g) => g.severity === 'critical').length;
  return (
    <div className={`verdict ${report.gaps.length ? (crit ? 'v-crit' : 'v-warn') : 'v-ok'} ${busy ? 'busy' : ''}`} role="status">
      <div className="verdict-head">
        {report.gaps.length ? <ShieldAlert size={22} /> : <ShieldCheck size={22} />}
        <div>
          <strong>{report.gaps.length ? `${report.gaps.length} gap${report.gaps.length > 1 ? 's' : ''} found` : simulated ? 'No gaps for this scenario' : 'No live access gaps'}</strong>
          <div className="small">
            {report.summary.ok} links unchanged · {report.summary.detour} need a detour · {report.summary.lost} with no approved route
          </div>
        </div>
      </div>
      {report.gaps.length > 0 && (
        <ul className="gap-list">
          {report.gaps.map((g, i) => (
            <li key={i} className={`gap gap-${g.severity}`}>
              <span className="gap-sev">{g.severity}</span>
              <div>
                <strong>{g.area}</strong>
                <div className="small">{g.message}</div>
              </div>
            </li>
          ))}
        </ul>
      )}
      <p className="tiny">{report.statement}</p>
    </div>
  );
}

function LinkRow({ l, on, onClick }: { l: LinkResult; on: boolean; onClick: () => void }) {
  const K = KIND[l.link.kind];
  return (
    <tr className={`link-row lr-${l.status} ${on ? 'selected' : ''}`} onClick={onClick} tabIndex={0} onKeyDown={(e) => e.key === 'Enter' && onClick()}>
      <td>
        <div className="link-name">
          <K.icon size={15} aria-hidden /> <strong>{l.link.label}</strong>
        </div>
        <div className="tiny muted">
          {K.label} · {l.link.mode} · {l.link.access} access
        </div>
      </td>
      <td className="small">
        {!l.plan ? (
          <span className="text-danger">No approved route in the plan</span>
        ) : l.singlePoints.length ? (
          <>
            <span className="chip chip-warn">1 route</span> single point of failure: <strong>{l.singlePoints.map((p) => p.name).join(', ')}</strong>
          </>
        ) : (
          <>
            <span className="chip chip-ok">{l.redundancy >= 3 ? '3+' : l.redundancy} independent routes</span>
            {l.secondFailures.length > 0 && <div className="tiny muted">Fails if {l.secondFailures[0].a.name} + {l.secondFailures[0].b.name} both close</div>}
          </>
        )}
      </td>
      <td className="small">
        {l.status === 'ok' && <span className="chip chip-ok">Planned route available</span>}
        {l.status === 'lost' && (
          <>
            <span className="chip chip-danger">No approved route available</span>
            <div className="tiny">The venue plan has no valid alternative. Do not improvise — a plan decision is needed.</div>
          </>
        )}
        {l.status === 'detour' && l.detour && (
          <>
            <span className="chip chip-active">Detour {l.detour.extraDistanceM != null && l.detour.extraDistanceM > 0 ? `+${metres(l.detour.extraDistanceM)}` : ''}</span>
            <div className="tiny">
              Avoids: {l.detour.removedSegments.map((r) => r.name).join(', ')}
            </div>
            <div className="tiny">
              Via:{' '}
              {l.detour.addedSegments.map((a, i) => (
                <span key={a.id}>
                  {i ? ' → ' : ''}
                  <strong>{a.name}</strong> ({a.modes.join('+')}, {a.access}
                  {a.status === 'under_review' ? ', UNDER REVIEW' : ''}){a.constraint ? ` — ${a.constraint}` : ''}
                  {a.terrain ? ` — ${a.terrain}` : ''}
                </span>
              ))}
            </div>
          </>
        )}
      </td>
    </tr>
  );
}
