import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useLive } from '../lib/live';
import { VenueMap, type MapSelection } from '../components/VenueMap';
import { FeatureDetails } from '../components/FeatureDetails';
import { polygonCentroid } from '@shared/geo';

export default function MapPage() {
  const { snap } = useLive();
  const [params] = useSearchParams();
  const [selection, setSelection] = useState<MapSelection>(null);
  const [focus, setFocus] = useState<[number, number] | null>(null);

  useEffect(() => {
    const zone = params.get('zone');
    const inc = params.get('incident');
    if (zone) {
      setSelection({ type: 'zone', id: zone });
      const z = snap!.zones.find((x) => x.id === zone);
      if (z) setFocus(polygonCentroid(z.polygon));
    } else if (inc) {
      setSelection({ type: 'incident', id: inc });
      const i = snap!.incidents.find((x) => x.id === inc);
      if (i?.lat != null) setFocus([i.lat, i.lng!]);
    }
  }, [params]);

  return (
    <div className="page map-page">
      <div className="map-wrap">
        <VenueMap snap={snap!} selection={selection} onSelect={setSelection} focus={focus} legendOpen />
        {!selection && <div className="map-hint">Select a zone, exit, route segment, incident or responder for details.</div>}
      </div>
      {selection && <FeatureDetails selection={selection} onClose={() => setSelection(null)} />}
    </div>
  );
}
