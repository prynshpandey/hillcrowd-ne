import { useMemo, useState } from 'react';
import { CheckCircle2, Navigation, XCircle } from 'lucide-react';
import { useLive } from '../lib/live';
import { useSession } from '../lib/session';
import { api } from '../lib/api';
import { can } from '@shared/permissions';
import type { AccessLevel, RouteResult, TravelMode } from '@shared/types';
import { Ago, Card, Empty, Notice, useAction } from '../components/ui';
import { VenueMap, type MapSelection, type RouteHighlight } from '../components/VenueMap';
import { FacilityStatusDialog, FeatureDetails, SegmentStatusDialog } from '../components/FeatureDetails';
import { RouteSummary } from './Incidents';
import { fmtDateTime, metres } from '../lib/format';

export default function RoutesPage() {
  const { snap } = useLive();
  const { me } = useSession();
  const run = useAction();
  const s = snap!;
  const role = me!.user.role;
  const [from, setFrom] = useState(s.nodes.find((n) => n.name.startsWith('Medical'))?.id ?? s.nodes[0]?.id ?? '');
  const [to, setTo] = useState(s.nodes.find((n) => n.name.includes('Handover'))?.id ?? s.nodes[1]?.id ?? '');
  const [mode, setMode] = useState<TravelMode>('vehicle');
  const [access, setAccess] = useState<AccessLevel>('emergency');
  const [avoidReview, setAvoidReview] = useState(false);
  const [result, setResult] = useState<RouteResult | null>(null);
  const [selected, setSelected] = useState<{ routeId: string; show: 'primary' | 'alt' } | null>(null);
  const [mapSel, setMapSel] = useState<MapSelection>(null);
  const [dialog, setDialog] = useState<React.ReactNode>(null);

  const highlights: RouteHighlight[] = useMemo(() => {
    const h: RouteHighlight[] = [];
    if (result?.found) h.push({ segmentIds: result.segmentIds, tone: 'primary' });
    if (selected) {
      const r = s.namedRoutes?.find((x) => x.id === selected.routeId);
      const v = s.routeValidity?.find((x) => x.routeId === selected.routeId);
      if (r) h.push({ segmentIds: r.segmentIds, tone: v?.valid ? 'primary' : 'blocked' });
      if (v?.alternative?.found) h.push({ segmentIds: v.alternative.segmentIds, tone: 'alternative' });
    }
    return h;
  }, [result, selected, s.namedRoutes, s.routeValidity]);

  const compute = () =>
    run(async () => {
      const r = await api.post<RouteResult>(`/api/events/${s.event.id}/routes/compute`, { from, to, mode, access, avoidUnderReview: avoidReview });
      setResult(r);
      setSelected(null);
    });

  const close = () => setDialog(null);
  const nonOpen = s.segments.filter((x) => x.status !== 'open');

  return (
    <div className="page routes-page">
      <div className="page-head">
        <div>
          <h1>Route planning & access validation</h1>
          <p className="muted">Manually curated, approved venue route network. The shortest route is not assumed to be the most suitable; closures, travel mode and access restrictions are applied, and no route is ever invented.</p>
        </div>
      </div>
      <div className="routes-layout">
        <div className="routes-side">
          <Card title="Route planner">
            <form
              className="form-grid"
              onSubmit={(e) => {
                e.preventDefault();
                compute();
              }}
            >
              <label className="field">
                <span>Origin</span>
                <select value={from} onChange={(e) => setFrom(e.target.value)}>
                  {s.nodes.map((n) => (
                    <option key={n.id} value={n.id}>
                      {n.name}
                    </option>
                  ))}
                </select>
              </label>
              <label className="field">
                <span>Destination</span>
                <select value={to} onChange={(e) => setTo(e.target.value)}>
                  {s.nodes.map((n) => (
                    <option key={n.id} value={n.id}>
                      {n.name}
                    </option>
                  ))}
                </select>
              </label>
              <label className="field">
                <span>Travel mode</span>
                <select value={mode} onChange={(e) => setMode(e.target.value as TravelMode)}>
                  <option value="foot">On foot</option>
                  <option value="vehicle">Vehicle</option>
                </select>
              </label>
              <label className="field">
                <span>Access level of traveller</span>
                <select value={access} onChange={(e) => setAccess(e.target.value as AccessLevel)}>
                  <option value="public">Public</option>
                  <option value="staff">Staff / steward</option>
                  <option value="emergency">Emergency responder</option>
                </select>
              </label>
              <label className="check">
                <input type="checkbox" checked={avoidReview} onChange={(e) => setAvoidReview(e.target.checked)} /> Avoid segments under review
              </label>
              <button className="btn btn-primary">
                <Navigation size={15} /> Find route
              </button>
            </form>
            {result && (
              <div className="route-result">
                <RouteSummary route={result} />
                {result.excludedSegments.length > 0 && (
                  <details>
                    <summary className="small">{result.excludedSegments.length} segment(s) excluded for this request</summary>
                    <ul className="plain tiny">
                      {result.excludedSegments.map((x) => (
                        <li key={x.id}>
                          {x.name}: {x.reason}
                        </li>
                      ))}
                    </ul>
                  </details>
                )}
                <p className="tiny muted">{result.reason}</p>
              </div>
            )}
          </Card>

          <Card title="Approved operational routes" subtitle="Routes in the venue safety plan. A closure invalidates every route that depends on the segment.">
            {(s.namedRoutes ?? []).map((r) => {
              const v = s.routeValidity?.find((x) => x.routeId === r.id);
              return (
                <button key={r.id} className={`named-route ${v?.valid ? 'ok' : 'bad'} ${selected?.routeId === r.id ? 'on' : ''}`} onClick={() => { setSelected({ routeId: r.id, show: 'primary' }); setResult(null); }}>
                  <div className="nr-head">
                    {v?.valid ? <CheckCircle2 size={16} className="text-ok" /> : <XCircle size={16} className="text-danger" />}
                    <strong>{r.name}</strong>
                  </div>
                  <div className="tiny muted">
                    {r.purpose} · {r.mode} · {r.access} access · approved by {r.approvedBy}
                  </div>
                  {v && !v.valid && (
                    <div className="small">
                      <span className="text-danger">INVALID</span> — blocked: {v.blockedSegments.map((b) => `${b.name}${b.reason ? ` (${b.reason})` : ''}`).join('; ')}
                      <div>
                        {v.alternative?.found ? (
                          <span>
                            Alternative found within approved network: <strong>{metres(v.alternative.distanceM)}</strong> via {v.alternative.segmentIds.length} segments. <em>Coordinator review required before use.</em>
                          </span>
                        ) : (
                          <strong className="text-danger">No valid alternative route found. Escalate to the coordinator.</strong>
                        )}
                      </div>
                    </div>
                  )}
                  {v && v.valid && v.reviewSegments.length > 0 && <div className="small text-warn">Valid, but uses segment(s) under review: {v.reviewSegments.map((x) => x.name).join(', ')}</div>}
                </button>
              );
            })}
            {selected &&
              (() => {
                const v = s.routeValidity?.find((x) => x.routeId === selected.routeId);
                return v?.alternative ? (
                  <div className="alt-detail">
                    <h4>Alternative for {s.namedRoutes?.find((x) => x.id === selected.routeId)?.name}</h4>
                    <RouteSummary route={v.alternative} />
                  </div>
                ) : null;
              })()}
          </Card>
        </div>

        <div className="routes-map">
          <VenueMap snap={s} highlights={highlights} selection={mapSel} onSelect={setMapSel} initialLayers={{ incidents: false, responders: false }} />
          {mapSel && (
            <div className="routes-map-details">
              <FeatureDetails selection={mapSel} onClose={() => setMapSel(null)} />
            </div>
          )}
        </div>
      </div>

      <div className="grid-routes">
        <Card title="Route segment status" subtitle={`${nonOpen.length} of ${s.segments.length} segments closed or under review`}>
          <div className="table-wrap">
            <table className="table compact">
              <thead>
                <tr>
                  <th>Segment</th>
                  <th>Travel / access</th>
                  <th>Status</th>
                  <th>Updated</th>
                  {can(role, 'route.setStatus') && <th />}
                </tr>
              </thead>
              <tbody>
                {[...s.segments]
                  .sort((a, b) => Number(a.status === 'open') - Number(b.status === 'open') || a.name.localeCompare(b.name))
                  .map((x) => (
                    <tr key={x.id}>
                      <td>
                        <button className="link" onClick={() => setMapSel({ type: 'segment', id: x.id })}>
                          {x.name}
                        </button>
                        {(x.constraintNote || x.terrainNote) && <div className="tiny muted">{[x.constraintNote, x.terrainNote].filter(Boolean).join(' · ')}</div>}
                      </td>
                      <td className="small">
                        {x.modes.join('+')} · {x.access}
                        <div className="tiny muted">{metres(x.distanceM)}</div>
                      </td>
                      <td>
                        <span className={`chip ${x.status === 'open' ? 'chip-ok' : x.status === 'closed' ? 'chip-danger' : 'chip-warn'}`}>{x.status === 'open' ? 'Open' : x.status === 'closed' ? 'Closed' : 'Under review'}</span>
                        {x.statusReason && <div className="tiny">{x.statusReason}</div>}
                      </td>
                      <td className="small">
                        <Ago iso={x.statusUpdatedAt} />
                        <div className="tiny muted">{x.statusSource}</div>
                      </td>
                      {can(role, 'route.setStatus') && (
                        <td className="nowrap">
                          {x.status !== 'closed' && (
                            <button className="btn btn-sm btn-danger-ghost" onClick={() => setDialog(<SegmentStatusDialog segmentId={x.id} to="closed" onClose={close} />)}>
                              Close
                            </button>
                          )}
                          {x.status === 'open' && (
                            <button className="btn btn-sm btn-ghost" onClick={() => setDialog(<SegmentStatusDialog segmentId={x.id} to="under_review" onClose={close} />)}>
                              Review
                            </button>
                          )}
                          {x.status !== 'open' && (
                            <button className="btn btn-sm" onClick={() => setDialog(<SegmentStatusDialog segmentId={x.id} to="open" onClose={close} />)}>
                              Reopen
                            </button>
                          )}
                        </td>
                      )}
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </Card>
        <div className="stack">
          <Card title="Gates, exits & assembly points">
            <table className="table compact">
              <tbody>
                {s.facilities
                  .filter((f) => ['gate', 'exit', 'assembly', 'medical'].includes(f.kind))
                  .map((f) => (
                    <tr key={f.id}>
                      <td>
                        {f.name}
                        <div className="tiny muted">{f.kind}</div>
                      </td>
                      <td>
                        {f.status === 'open' ? <span className="chip chip-ok">Available</span> : <span className="chip chip-danger">Unavailable</span>}
                        {f.statusReason && <div className="tiny">{f.statusReason}</div>}
                      </td>
                      {can(role, 'facility.setStatus') && (
                        <td>
                          <button className="btn btn-sm btn-ghost" onClick={() => setDialog(<FacilityStatusDialog facilityId={f.id} onClose={close} />)}>
                            {f.status === 'open' ? 'Mark unavailable' : 'Mark available'}
                          </button>
                        </td>
                      )}
                    </tr>
                  ))}
              </tbody>
            </table>
          </Card>
          <Card title="Closure & review history">
            {(s.closures ?? []).length === 0 ? (
              <Empty>No closures recorded.</Empty>
            ) : (
              <ul className="plain small closure-list">
                {s.closures!.map((c) => (
                  <li key={c.id}>
                    <span className={`chip ${c.status === 'closed' ? 'chip-danger' : 'chip-warn'}`}>{c.status === 'closed' ? 'Closed' : 'Review'}</span> <strong>{c.segment_name}</strong> — {c.reason}
                    <div className="tiny muted">
                      {fmtDateTime(c.created_at)} · source: {c.source}
                      {c.lifted_at ? ` · lifted ${fmtDateTime(c.lifted_at)}` : ' · ACTIVE'}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      </div>
      {dialog}
      <Notice tone="info">Distances are configured from the venue plan, not measured. A route appearing in the network does not mean it is physically safe at this moment — confirm with field teams.</Notice>
    </div>
  );
}
