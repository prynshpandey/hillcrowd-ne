import { useState } from 'react';
import { Link } from 'react-router-dom';
import { MapPin } from 'lucide-react';
import { useLive } from '../lib/live';
import { useSession } from '../lib/session';
import { api } from '../lib/api';
import { can } from '@shared/permissions';
import { ASSIGNMENT_LABEL, CATEGORY_LABEL } from '@shared/constants';
import { Ago, Card, Empty, Modal, Notice, ReasonDialog, useAction } from '../components/ui';
import { fmtTime } from '../lib/format';

export default function RespondersPage() {
  const { snap, reload } = useLive();
  const { me } = useSession();
  const run = useAction();
  const s = snap!;
  const [locFor, setLocFor] = useState<string | null>(null);
  const [node, setNode] = useState('');
  const [duty, setDuty] = useState<{ id: string; available: boolean; name: string } | null>(null);
  const incidents = new Map(s.incidents.map((i) => [i.id, i]));
  const assignments = s.assignments ?? [];
  const unacked = assignments.filter((a) => a.status === 'assigned');

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h1>Responders</h1>
          <p className="muted">Availability, current assignment and acknowledgement. Positions are base posts or manually entered — this prototype has no live GPS tracking.</p>
        </div>
      </div>
      {unacked.length > 0 && (
        <Notice tone={unacked.some((a) => a.escalatedAt) ? 'danger' : 'warn'} title={`${unacked.length} assignment(s) awaiting acknowledgement.`}>
          An assignment escalates when acceptance overruns its target, set by severity and incident type in Event Setup.
        </Notice>
      )}
      <div className="resp-grid">
        {(s.responders ?? []).map((r) => {
          const mine = assignments.filter((a) => a.responderId === r.id);
          const active = mine.find((a) => ['assigned', 'acknowledged', 'en_route', 'on_scene'].includes(a.status));
          const inc = active && incidents.get(active.incidentId);
          return (
            <Card key={r.id} className={`resp-card st-${r.status}`} title={r.name} subtitle={`${r.team} · ${r.modes.join(' + ')} · ${r.access} access${r.userId ? ' · has app account' : ' · no app account (radio updates recorded by control room)'}`}>
              <div className="resp-status">
                <span className={`chip ${r.status === 'available' ? 'chip-ok' : r.status === 'off_duty' ? 'chip-muted' : 'chip-info'}`}>{r.status === 'available' ? 'Available' : r.status === 'off_duty' ? 'Unavailable (off duty)' : r.status.replace('_', ' ')}</span>
              </div>
              {active && inc ? (
                <div className="resp-task">
                  <Link to={`/incidents/${inc.id}`}>
                    <strong>{inc.ref}</strong> — {CATEGORY_LABEL[inc.category]}
                  </Link>
                  <div className={`small ${active.status === 'assigned' ? (active.escalatedAt ? 'text-danger' : 'text-warn') : ''}`}>
                    {ASSIGNMENT_LABEL[active.status]} · assigned <Ago iso={active.assignedAt} />
                  </div>
                  {active.escalationReason && <div className="small text-danger">{active.escalationReason}</div>}
                  {active.route && !active.route.found && <div className="small text-danger">No valid route at assignment time.</div>}
                </div>
              ) : (
                <p className="muted small">No active assignment.</p>
              )}
              <div className="tiny muted">
                <MapPin size={12} /> {r.locationSource ?? 'Position unknown'} {r.locationUpdatedAt && `· ${fmtTime(r.locationUpdatedAt)}`}
              </div>
              <div className="tiny muted">
                Assignments this event: {mine.length} · acknowledged {mine.filter((a) => a.acknowledgedAt).length}
              </div>
              {can(me!.user.role, 'assignment.create') && (
                <div className="btn-row">
                  <button className="btn btn-sm btn-ghost" onClick={() => setLocFor(r.id)}>
                    Set position manually…
                  </button>
                  {r.status === 'available' && (
                    <button className="btn btn-sm btn-danger-ghost" onClick={() => setDuty({ id: r.id, available: false, name: r.name })}>
                      Mark unavailable…
                    </button>
                  )}
                  {r.status === 'off_duty' && (
                    <button className="btn btn-sm" onClick={() => setDuty({ id: r.id, available: true, name: r.name })}>
                      Back on duty…
                    </button>
                  )}
                </div>
              )}
            </Card>
          );
        })}
      </div>
      {(s.responders ?? []).length === 0 && <Empty>No responders configured for this event.</Empty>}
      {duty && (
        <ReasonDialog
          title={duty.available ? `${duty.name}: back on duty` : `${duty.name}: mark unavailable`}
          required
          tone={duty.available ? 'primary' : 'danger'}
          placeholder={duty.available ? 'e.g. Team returned from break' : 'e.g. Team escorting patient off-site'}
          onSubmit={(n) => api.post(`/api/responders/${duty.id}/availability`, { available: duty.available, reason: n }).then(reload)}
          onClose={() => setDuty(null)}
        />
      )}
      {locFor && (
        <Modal title="Set responder position (manual)" onClose={() => setLocFor(null)}>
          <p className="small">Choose the nearest known location. The position is labelled as manually entered and is used for route suggestions only.</p>
          <label className="field">
            <span>Location</span>
            <select value={node} onChange={(e) => setNode(e.target.value)}>
              <option value="">Select…</option>
              {s.nodes.map((n) => (
                <option key={n.id} value={n.id}>
                  {n.name}
                </option>
              ))}
            </select>
          </label>
          <div className="modal-actions">
            <button className="btn" onClick={() => setLocFor(null)}>
              Cancel
            </button>
            <button
              className="btn btn-primary"
              disabled={!node}
              onClick={async () => {
                const n = s.nodes.find((x) => x.id === node)!;
                await run(() => api.patch(`/api/responders/${locFor}/location`, { lat: n.lat, lng: n.lng }).then(reload), 'Position recorded (manual)');
                setLocFor(null);
              }}
            >
              Save position
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}
