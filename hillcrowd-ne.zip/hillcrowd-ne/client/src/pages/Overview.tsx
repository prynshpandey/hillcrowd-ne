import { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Clock, ShieldAlert } from 'lucide-react';
import { useLive } from '../lib/live';
import { useSession } from '../lib/session';
import { can } from '@shared/permissions';
import { CATEGORY_LABEL, RISK_ORDER, SEVERITY_ORDER } from '@shared/constants';
import type { Incident, RiskLevel } from '@shared/types';
import { VenueMap } from '../components/VenueMap';
import { Ago, Card, DemoBadge, Empty, LevelBadge, Notice, SeverityTag, StatusChip, VerifyChip } from '../components/ui';
import { OccupancyBar, RiskConditions } from '../components/RiskExplain';
import { DemoPanel } from '../components/DemoPanel';
import { fmtDateTime, fmtTime, metres } from '../lib/format';

export function priorityScore(i: Incident) {
  const statusWeight: Record<string, number> = { submitted: 30, under_review: 28, verified: 40, assigned: 20, acknowledged: 12, in_progress: 10, resolved: 5 };
  return (i.urgent ? 50 : 0) + SEVERITY_ORDER[i.confirmedSeverity ?? i.severityEstimate] * 15 + (statusWeight[i.status] ?? 0) + Math.min(30, (Date.now() - new Date(i.receivedAt).getTime()) / 60000);
}

export default function OverviewPage() {
  const { snap, fetchedAt, stale, fromCache } = useLive();
  const { me } = useSession();
  const s = snap!;
  const zones = new Map(s.zones.map((z) => [z.id, z]));
  const responders = new Map((s.responders ?? []).map((r) => [r.id, r]));

  const risks = useMemo(() => [...(s.risks ?? [])].sort((a, b) => RISK_ORDER[b.level] - RISK_ORDER[a.level] || b.attentionPoints - a.attentionPoints), [s.risks]);
  const active = s.incidents.filter((i) => !i.mergedInto && ['submitted', 'under_review', 'verified', 'assigned', 'acknowledged', 'in_progress', 'resolved'].includes(i.status)).sort((a, b) => priorityScore(b) - priorityScore(a));
  const unacked = (s.assignments ?? []).filter((a) => a.status === 'assigned');
  const closedSegs = s.segments.filter((x) => x.status !== 'open');
  const invalidRoutes = (s.routeValidity ?? []).filter((v) => !v.valid);
  const activeAdvisories = s.advisories.filter((a) => a.verification !== 'rejected' && (!a.expiresAt || new Date(a.expiresAt) > new Date()));
  const availableResponders = (s.responders ?? []).filter((r) => r.status === 'available').length;
  const staleZones = (s.risks ?? []).filter((r) => r.occupancy.stale || r.occupancy.value == null);
  const accessLost = (s.access?.links ?? []).filter((l) => l.status === 'lost');
  const overall = (s.risks ?? []).reduce<RiskLevel>((m, r) => (RISK_ORDER[r.level] > RISK_ORDER[m] ? r.level : m), 'normal');
  const zonesAttention = (s.risks ?? []).filter((r) => r.level !== 'normal').length;
  const overdueStages = Object.values(s.stages ?? {}).filter((x) => x.overdue).length;
  const reviewCount = active.filter((i) => ['submitted', 'under_review'].includes(i.status)).length;
  const summary =
    overall === 'normal' && !active.length && !accessLost.length
      ? 'All zones within configured limits, no active incidents, all approved routes available. Continue routine monitoring.'
      : [
          zonesAttention ? `${risks.filter((r) => r.level !== 'normal').map((r) => `${zones.get(r.zoneId)!.name.split(' – ')[0]} ${r.level}`).join(', ')}.` : 'All zones Normal.',
          reviewCount ? `${reviewCount} report${reviewCount > 1 ? 's' : ''} awaiting review.` : '',
          unacked.length ? `${unacked.length} assignment${unacked.length > 1 ? 's' : ''} not yet acknowledged.` : '',
          accessLost.length ? `${accessLost.length} critical access link${accessLost.length > 1 ? 's have' : ' has'} no approved route.` : '',
        ]
          .filter(Boolean)
          .join(' ');

  return (
    <div className="page overview">
      <div className="page-head">
        <div>
          <h1>{s.event.name}</h1>
          <p className="muted">
            {s.event.venueName} · {s.event.locationLabel} · {s.event.district}, {s.event.state} · {fmtDateTime(s.event.startsAt)} – {fmtTime(s.event.endsAt)}
          </p>
        </div>
        <div className="freshness">
          {s.event.isDemo && <DemoBadge label="DEMO SCENARIO — simulated records" />}
          <span className={`fresh ${stale ? 'fresh-stale' : ''}`}>
            <Clock size={14} /> {fromCache ? 'Showing cached copy — ' : ''}Updated {fetchedAt ? fmtTime(new Date(fetchedAt).toISOString(), true) : '—'}
          </span>
        </div>
      </div>

      {stale && <Notice tone="warn" title="Information may be out of date.">The last successful update is older than 45 seconds or came from this device's cache. Check the connection before relying on it.</Notice>}

      {accessLost.length > 0 && (
        <Link to="/resilience" className="access-banner" role="alert">
          <ShieldAlert size={26} aria-hidden />
          <div>
            <strong>ACCESS GAP — no approved route available</strong>
            <div>{accessLost.map((l) => l.link.label).join(' · ')}</div>
            <div className="small">The venue plan has no valid alternative with current closures. Review the plan in the Resilience Lab — the system will not improvise a route.</div>
          </div>
          <ArrowRight size={20} aria-hidden />
        </Link>
      )}

      <div className="hero">
        <div className={`hero-status hs-${overall}`}>
          <div className="hero-label">Situation now</div>
          <LevelBadge level={overall} size="lg" suffix="highest zone level" />
          <p className="hero-summary">{summary}</p>
          <div className="hero-chips">
            <span>
              <b>{zonesAttention}</b> of {s.zones.length} zones need attention
            </span>
            <span>
              <b>{active.length}</b> active incident{active.length === 1 ? '' : 's'}
            </span>
            <span>
              <b>{accessLost.length}</b> access gap{accessLost.length === 1 ? '' : 's'}
            </span>
            <span>
              <b>{availableResponders}</b> team{availableResponders === 1 ? '' : 's'} available
            </span>
            {overdueStages > 0 && (
              <span className="hc-late">
                <b>{overdueStages}</b> response stage{overdueStages === 1 ? '' : 's'} overdue
              </span>
            )}
          </div>
          <div className="hero-links">
            <Link to="/incidents" className="btn btn-primary btn-sm">
              Incident queue
            </Link>
            <Link to="/resilience" className="btn btn-sm">
              Resilience Lab
            </Link>
          </div>
        </div>
        <Link to="/map" className="hero-map" aria-label="Open the live map">
          <VenueMap snap={s} height="100%" compact showControls={false} showLegend={false} initialLayers={{ responders: true }} highlights={accessLost.flatMap((l) => (l.plan ? [{ segmentIds: l.plan.segmentIds, tone: 'blocked' as const }] : []))} />
          <span className="hero-map-cta">Open live map →</span>
        </Link>
      </div>

      <div className="kpis">
        <Link to="/incidents" className="kpi">
          <span className="kpi-n">{active.filter((i) => ['submitted', 'under_review'].includes(i.status)).length}</span>
          <span className="kpi-l">reports awaiting review</span>
        </Link>
        <Link to="/incidents" className="kpi">
          <span className="kpi-n">{active.filter((i) => i.status === 'verified').length}</span>
          <span className="kpi-l">verified, not yet assigned</span>
        </Link>
        <Link to="/responders" className={`kpi ${unacked.some((a) => a.escalatedAt) ? 'kpi-alert' : ''}`}>
          <span className="kpi-n">{unacked.length}</span>
          <span className="kpi-l">assignments not acknowledged</span>
        </Link>
        <Link to="/routes" className={`kpi ${invalidRoutes.length ? 'kpi-alert' : ''}`}>
          <span className="kpi-n">{closedSegs.length}</span>
          <span className="kpi-l">route segments closed / under review</span>
        </Link>
        <Link to="/responders" className="kpi">
          <span className="kpi-n">
            {availableResponders}/{(s.responders ?? []).length}
          </span>
          <span className="kpi-l">responders available</span>
        </Link>
        <Link to="/map" className={`kpi ${staleZones.length ? 'kpi-warn' : ''}`}>
          <span className="kpi-n">{staleZones.length}</span>
          <span className="kpi-l">zones with stale/missing occupancy</span>
        </Link>
      </div>

      <div className="grid-2">
        <Card title="Needs action now" subtitle="Ordered by risk level, then time" className="needs-action">
          {(s.notifications ?? []).length === 0 ? (
            <Empty>Nothing requires action right now. Continue routine monitoring.</Empty>
          ) : (
            <ul className="action-list">
              {(s.notifications ?? []).slice(0, 10).map((n) => (
                <li key={n.id}>
                  <Link to={n.link} className="action-item">
                    <LevelBadge level={n.level} size="sm" />
                    <div>
                      <div className="action-title">{n.title}</div>
                      <div className="action-detail">{n.detail}</div>
                    </div>
                    <ArrowRight size={16} className="action-go" />
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card title="Incident queue" actions={<Link to="/incidents" className="btn btn-ghost btn-sm">All incidents</Link>}>
          {active.length === 0 ? (
            <Empty>No active incidents.</Empty>
          ) : (
            <table className="table compact">
              <thead>
                <tr>
                  <th>Ref</th>
                  <th>Incident</th>
                  <th>Status</th>
                  <th>Owner</th>
                  <th>Age</th>
                </tr>
              </thead>
              <tbody>
                {active.slice(0, 7).map((i) => (
                  <tr key={i.id}>
                    <td>
                      <Link to={`/incidents/${i.id}`}>{i.ref}</Link>
                      {i.urgent && <span className="tag tag-critical">URGENT</span>}
                    </td>
                    <td>
                      <div>{CATEGORY_LABEL[i.category]}</div>
                      <div className="muted tiny">{zones.get(i.zoneId ?? '')?.name ?? 'Map location'}</div>
                      <SeverityTag severity={i.confirmedSeverity ?? i.severityEstimate} confirmed={!!i.confirmedSeverity} />
                    </td>
                    <td>
                      <StatusChip status={i.status} />
                      <div>
                        <VerifyChip status={i.status} />
                      </div>
                    </td>
                    <td>{i.ownerId ? responders.get(i.ownerId)?.name ?? '—' : <span className="muted">Unassigned</span>}</td>
                    <td>
                      <Ago iso={i.receivedAt} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>
      </div>

      <h2 className="section-title">Zones</h2>
      <div className="zone-grid">
        {risks.map((r) => {
          const z = zones.get(r.zoneId)!;
          return (
            <Link to={`/map?zone=${z.id}`} key={r.zoneId} className={`zone-card zc-${r.level}`}>
              <div className="zone-card-head">
                <h3>{z.name}</h3>
                <LevelBadge level={r.level} />
              </div>
              <OccupancyBar risk={r} zone={z} />
              <RiskConditions risk={r} max={2} />
              <div className="next-step small">
                <strong>Next:</strong> {r.recommendedNextStep}
              </div>
            </Link>
          );
        })}
      </div>

      <div className="grid-3">
        <Card title="Routes & access" actions={<Link to="/routes" className="btn btn-ghost btn-sm">Route planning</Link>}>
          {invalidRoutes.length === 0 && closedSegs.length === 0 && <Empty>All approved routes are available. No closures recorded.</Empty>}
          {invalidRoutes.map((v) => {
            const r = s.namedRoutes!.find((x) => x.id === v.routeId)!;
            return (
              <div key={v.routeId} className="route-alert">
                <LevelBadge level={v.alternative?.found ? 'watch' : 'elevated'} size="sm" />
                <div>
                  <strong>{r.name}</strong> is unavailable (blocked: {v.blockedSegments.map((b) => b.name).join(', ')}).
                  <div className="small">{v.alternative?.found ? `Alternative in approved network: ${metres(v.alternative.distanceM)} — coordinator review required.` : 'NO valid alternative found in the approved network. Escalate.'}</div>
                </div>
              </div>
            );
          })}
          {closedSegs.length > 0 && (
            <ul className="plain small">
              {closedSegs.map((x) => (
                <li key={x.id}>
                  <span className={`chip ${x.status === 'closed' ? 'chip-danger' : 'chip-warn'}`}>{x.status === 'closed' ? 'Closed' : 'Review'}</span> {x.name} — <Ago iso={x.statusUpdatedAt} />
                </li>
              ))}
            </ul>
          )}
        </Card>
        <Card title="Advisories" actions={<Link to="/advisories" className="btn btn-ghost btn-sm">Advisory panel</Link>}>
          {activeAdvisories.length === 0 ? (
            <Empty>No active advisories entered. No live official feed is connected in this prototype.</Empty>
          ) : (
            activeAdvisories.map((a) => (
              <div key={a.id} className="adv-mini">
                {a.isSample && <span className="tag tag-sample">SAMPLE</span>}
                <span className={`chip ${a.verification === 'verified' ? 'chip-verified' : 'chip-unverified'}`}>{a.verification}</span>
                <div>
                  <strong>{a.title}</strong>
                </div>
                <div className="tiny muted">
                  {a.issuer} · issued {fmtTime(a.issuedAt)} · {a.expiresAt ? `until ${fmtTime(a.expiresAt)}` : 'validity unknown'}
                </div>
              </div>
            ))
          )}
        </Card>
        <Card title="Event readiness" actions={<Link to="/setup" className="btn btn-ghost btn-sm">Event setup</Link>}>
          {s.readiness && (
            <>
              <div className="readiness-bar" aria-label="Checklist status">
                {(
                  [
                    ['mitigationVerified', 'Mitigation verified', 'ok'],
                    ['noIssue', 'No issue', 'ok2'],
                    ['mitigationPlanned', 'Mitigation planned', 'warn'],
                    ['issuesIdentified', 'Issue identified', 'danger'],
                    ['notAssessed', 'Not assessed', 'muted'],
                  ] as const
                ).map(([k, label, tone]) =>
                  s.readiness![k] ? (
                    <span key={k} className={`rb rb-${tone}`} style={{ flex: s.readiness![k] }} title={`${label}: ${s.readiness![k]}`}>
                      {s.readiness![k]}
                    </span>
                  ) : null,
                )}
              </div>
              <p className="small">{s.readiness.statement}</p>
              <p className="small">
                {s.stressTests?.length ? (
                  <>
                    Last stress test: <strong>{s.stressTests[0].name}</strong> — {s.stressTests[0].summary.gaps ? <span className="text-danger">{s.stressTests[0].summary.gaps} gap(s)</span> : 'no gaps found'} ({fmtDateTime(s.stressTests[0].runAt)}).
                  </>
                ) : (
                  <span className="text-warn">No failure scenarios have been stress-tested yet.</span>
                )}{' '}
                <Link to="/resilience">Open Resilience Lab</Link>
              </p>
              <ul className="plain small">
                {s.readiness.outstanding.slice(0, 4).map((o) => (
                  <li key={o.id}>
                    <span className={`chip ${o.status === 'issue_identified' ? 'chip-danger' : o.status === 'mitigation_planned' ? 'chip-warn' : 'chip-muted'}`}>{o.status.replace(/_/g, ' ')}</span> {o.label}
                  </li>
                ))}
              </ul>
            </>
          )}
        </Card>
      </div>

      {s.demoMode && can(me?.user.role, 'demo.control') && <DemoPanel />}
    </div>
  );
}
