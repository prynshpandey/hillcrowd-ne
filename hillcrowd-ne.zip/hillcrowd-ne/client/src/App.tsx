import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { BrowserRouter, Link, Navigate, NavLink, Route, Routes, useLocation, useNavigate } from 'react-router-dom';
import { Activity, BarChart3, Bell, ClipboardList, CloudRain, FlaskConical, LayoutDashboard, LogOut, Map as MapIcon, Menu, Route as RouteIcon, Settings, Siren, Users, Wifi, WifiOff, X } from 'lucide-react';
import { SessionProvider, useSession } from './lib/session';
import { LiveProvider, useLive } from './lib/live';
import { can, ROLE_LABEL, type Permission } from '@shared/permissions';
import { RISK_ORDER } from '@shared/constants';
import type { RiskLevel } from '@shared/types';
import { DemoBadge, LevelBadge, ToastProvider } from './components/ui';
import { t } from './i18n';
import { ago } from './lib/format';
import LoginPage from './pages/Login';
import OverviewPage from './pages/Overview';
import MapPage from './pages/LiveMap';
import IncidentsPage from './pages/Incidents';
import RoutesPage from './pages/RoutePlanning';
import ResiliencePage from './pages/Resilience';
import RespondersPage from './pages/Responders';
import AdvisoriesPage from './pages/Advisories';
import SetupPage from './pages/Setup';
import AnalyticsPage from './pages/Analytics';
import SettingsPage from './pages/Settings';
import FieldApp from './field/FieldApp';
import { ExerciseDrawer } from './components/ExerciseDrawer';
import ResponderApp from './field/ResponderApp';

const NAV: { to: string; key: string; icon: typeof MapIcon; perm: Permission }[] = [
  { to: '/overview', key: 'nav.overview', icon: LayoutDashboard, perm: 'event.viewOps' },
  { to: '/map', key: 'nav.map', icon: MapIcon, perm: 'event.viewOps' },
  { to: '/incidents', key: 'nav.incidents', icon: Siren, perm: 'incident.viewAll' },
  { to: '/resilience', key: 'nav.resilience', icon: FlaskConical, perm: 'event.viewOps' },
  { to: '/routes', key: 'nav.routes', icon: RouteIcon, perm: 'event.viewOps' },
  { to: '/responders', key: 'nav.responders', icon: Users, perm: 'event.viewOps' },
  { to: '/advisories', key: 'nav.advisories', icon: CloudRain, perm: 'event.viewOps' },
  { to: '/setup', key: 'nav.setup', icon: ClipboardList, perm: 'event.viewOps' },
  { to: '/analytics', key: 'nav.analytics', icon: BarChart3, perm: 'analytics.view' },
  { to: '/settings', key: 'nav.settings', icon: Settings, perm: 'audit.view' },
];

function homeFor(role: string) {
  return role === 'steward' ? '/field' : role === 'responder' ? '/respond' : '/overview';
}

function Gate() {
  const { me, loading, eventId } = useSession();
  const loc = useLocation();
  if (loading) return <div className="splash">Loading HillCrowd NE…</div>;
  if (!me) return <Navigate to="/login" replace state={{ from: loc.pathname }} />;
  if (!eventId)
    return (
      <div className="splash">
        No event is assigned to your account. Ask an administrator for access.
        <SignOutButton />
      </div>
    );
  return (
    <LiveProvider eventId={eventId} userId={me.user.id} key={`${me.user.id}-${eventId}`}>
      <Routes>
        <Route path="/field/*" element={me.user.role === 'steward' || me.user.role === 'coordinator' || me.user.role === 'admin' ? <FieldApp /> : <Navigate to={homeFor(me.user.role)} replace />} />
        <Route path="/respond/*" element={me.user.role === 'responder' ? <ResponderApp /> : <Navigate to={homeFor(me.user.role)} replace />} />
        <Route path="/*" element={can(me.user.role, 'event.viewOps') ? <Shell /> : <Navigate to={homeFor(me.user.role)} replace />} />
      </Routes>
    </LiveProvider>
  );
}

function SignOutButton() {
  const { logout } = useSession();
  const nav = useNavigate();
  return (
    <button
      className="btn btn-ghost"
      onClick={async () => {
        await logout();
        nav('/login');
      }}
    >
      <LogOut size={16} /> {t('common.signOut')}
    </button>
  );
}

export function ConnectionPill() {
  const { conn, stale, fetchedAt, fromCache } = useLive();
  const Icon = conn === 'offline' ? WifiOff : Wifi;
  const label = conn === 'live' ? (stale ? t('conn.stale') : t('conn.live')) : conn === 'offline' ? t('conn.offline') : t('conn.reconnecting');
  return (
    <span className={`conn conn-${conn}${stale ? ' conn-stale' : ''}`} title={fetchedAt ? `Last successful update ${ago(new Date(fetchedAt).toISOString())}` : 'No successful update yet'}>
      <Icon size={14} aria-hidden /> {label}
      {fromCache && <em> · cached copy</em>}
    </span>
  );
}

function Shell() {
  const { me, eventId, setEventId } = useSession();
  const { snap, error } = useLive();
  const [navOpen, setNavOpen] = useState(false);
  const loc = useLocation();
  useEffect(() => setNavOpen(false), [loc.pathname]);
  const role = me!.user.role;
  const overall: RiskLevel = useMemo(() => (snap?.risks ?? []).reduce<RiskLevel>((m, r) => (RISK_ORDER[r.level] > RISK_ORDER[m] ? r.level : m), 'normal'), [snap?.risks]);

  return (
    <div className={`shell ${navOpen ? 'nav-open' : ''}`}>
      <aside className="sidebar" aria-label="Main navigation">
        <div className="brand">
          <svg viewBox="0 0 64 64" width="30" height="30" aria-hidden>
            <path d="M4 50 L22 24 L31 36 L41 18 L60 50 Z" fill="#2f6b52" />
            <path d="M4 50 L22 24 L31 36 L41 18 L60 50" fill="none" stroke="#e8efe9" strokeWidth="3.5" strokeLinejoin="round" />
            <circle cx="41" cy="18" r="4.5" fill="#f2b84b" />
          </svg>
          <div>
            <div className="brand-name">{t('app.name')}</div>
            <div className="brand-tag">{t('app.tagline')}</div>
          </div>
          <button className="icon-btn nav-close" onClick={() => setNavOpen(false)} aria-label="Close menu">
            <X size={18} />
          </button>
        </div>
        <nav>
          {NAV.filter((n) => can(role, n.perm)).map((n) => (
            <NavLink key={n.to} to={n.to} className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
              <n.icon size={18} aria-hidden /> {t(n.key)}
              {n.to === '/incidents' && snap ? <IncidentCount /> : null}
            </NavLink>
          ))}
          <div className="nav-sep" />
          <NavLink to="/field" className="nav-item">
            <Activity size={18} aria-hidden /> Field reporting view
          </NavLink>
        </nav>
        <div className="sidebar-foot">
          <p>{t('app.disclaimer')}</p>
        </div>
      </aside>
      <div className="main">
        <header className="topbar">
          <button className="icon-btn nav-toggle" onClick={() => setNavOpen(true)} aria-label="Open menu">
            <Menu size={20} />
          </button>
          <div className="event-select">
            <label className="sr-only" htmlFor="event-select">
              Event
            </label>
            <select id="event-select" value={eventId ?? ''} onChange={(e) => setEventId(e.target.value)}>
              {me!.events.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.name}
                </option>
              ))}
            </select>
            {snap && (
              <span className="event-meta">
                {snap.event.venueName} · {snap.event.district}, {snap.event.state}
              </span>
            )}
          </div>
          <div className="topbar-right">
            {snap?.event.isDemo && <DemoBadge />}
            {snap?.risks && <LevelBadge level={overall} suffix="highest zone" />}
            <ConnectionPill />
            <Notifications />
            <div className="user-pill" title={me!.user.username}>
              <span className="user-name">{me!.user.displayName}</span>
              <span className="user-role">{ROLE_LABEL[role]}</span>
            </div>
            <SignOutButton />
          </div>
        </header>
        {error && !snap && <div className="page-error">Could not load event data: {error}</div>}
        <main className="content" id="main">
          {!snap ? (
            <div className="splash">Loading event…</div>
          ) : (
            <Routes>
              <Route path="/overview" element={<OverviewPage />} />
              <Route path="/map" element={<MapPage />} />
              <Route path="/incidents" element={<IncidentsPage />} />
              <Route path="/incidents/:id" element={<IncidentsPage />} />
              <Route path="/resilience" element={<ResiliencePage />} />
              <Route path="/routes" element={<RoutesPage />} />
              <Route path="/responders" element={<RespondersPage />} />
              <Route path="/advisories" element={<AdvisoriesPage />} />
              <Route path="/setup" element={<SetupPage />} />
              <Route path="/analytics" element={<RequirePerm perm="analytics.view"><AnalyticsPage /></RequirePerm>} />
              <Route path="/settings" element={<RequirePerm perm="audit.view"><SettingsPage /></RequirePerm>} />
              <Route path="*" element={<Navigate to="/overview" replace />} />
            </Routes>
          )}
        </main>
      </div>
      {navOpen && <div className="nav-backdrop" onClick={() => setNavOpen(false)} />}
      {snap?.demoMode && can(role, 'demo.control') && <ExerciseDrawer />}
    </div>
  );
}

function RequirePerm({ perm, children }: { perm: Permission; children: ReactNode }) {
  const { me } = useSession();
  return can(me?.user.role, perm) ? <>{children}</> : <div className="page-error">Your role does not have access to this page.</div>;
}

function IncidentCount() {
  const { snap } = useLive();
  const n = (snap?.incidents ?? []).filter((i) => !i.mergedInto && ['submitted', 'under_review', 'verified', 'assigned', 'acknowledged', 'in_progress', 'resolved'].includes(i.status)).length;
  return n ? <span className="nav-count">{n}</span> : null;
}

function Notifications() {
  const { snap } = useLive();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const list = snap?.notifications ?? [];
  const urgent = list.filter((n) => n.level === 'critical' || n.level === 'elevated').length;
  useEffect(() => {
    const h = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && setOpen(false);
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);
  return (
    <div className="notif" ref={ref}>
      <button className={`icon-btn notif-btn ${urgent ? 'has-urgent' : ''}`} onClick={() => setOpen((o) => !o)} aria-label={`${list.length} notifications, ${urgent} urgent`} aria-expanded={open}>
        <Bell size={18} />
        {list.length > 0 && <span className="notif-count">{list.length}</span>}
      </button>
      {open && (
        <div className="notif-panel" role="menu">
          <div className="notif-head">Needs attention ({list.length})</div>
          {list.length === 0 && <div className="empty">Nothing needs attention right now.</div>}
          {list.map((n) => (
            <Link key={n.id} to={n.link} className="notif-item" onClick={() => setOpen(false)}>
              <LevelBadge level={n.level} size="sm" />
              <div>
                <div className="notif-title">{n.title}</div>
                <div className="notif-detail">{n.detail}</div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

function LoginRoute() {
  const { me, loading } = useSession();
  if (loading) return <div className="splash">Loading…</div>;
  if (me) return <Navigate to={homeFor(me.user.role)} replace />;
  return <LoginPage />;
}

export default function App() {
  return (
    <BrowserRouter>
      <ToastProvider>
        <SessionProvider>
          <Routes>
            <Route path="/login" element={<LoginRoute />} />
            <Route path="/" element={<RootRedirect />} />
            <Route path="/*" element={<Gate />} />
          </Routes>
        </SessionProvider>
      </ToastProvider>
    </BrowserRouter>
  );
}

function RootRedirect() {
  const { me, loading } = useSession();
  if (loading) return <div className="splash">Loading…</div>;
  return <Navigate to={me ? homeFor(me.user.role) : '/login'} replace />;
}
