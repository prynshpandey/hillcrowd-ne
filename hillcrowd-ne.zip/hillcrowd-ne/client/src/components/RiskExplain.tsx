import type { OccupancyTrend, ZoneRisk, Zone } from '@shared/types';
import { ArrowDownRight, ArrowRight, ArrowUpRight, HelpCircle } from 'lucide-react';
import { LevelBadge } from './ui';
import { ago, fmtTime } from '../lib/format';

export function Sparkline({ trend, capacity, level }: { trend: OccupancyTrend; capacity: number | null; level: string }) {
  const pts = trend.readings;
  if (pts.length < 2) return null;
  const W = 96;
  const H = 26;
  const t0 = Date.parse(pts[0].observedAt);
  const t1 = Date.parse(pts[pts.length - 1].observedAt) || t0 + 1;
  const vals = pts.map((p) => p.value);
  const lo = Math.min(...vals) * 0.95;
  const hi = Math.max(...vals, capacity ? Math.min(capacity, Math.max(...vals) * 1.05) : 0) * 1.02;
  const x = (t: number) => ((t - t0) / Math.max(1, t1 - t0)) * (W - 4) + 2;
  const y = (v: number) => H - 3 - ((v - lo) / Math.max(1, hi - lo)) * (H - 6);
  const d = pts.map((p, i) => `${i ? 'L' : 'M'}${x(Date.parse(p.observedAt)).toFixed(1)},${y(p.value).toFixed(1)}`).join(' ');
  const last = pts[pts.length - 1];
  return (
    <svg className={`spark spark-${level}`} width={W} height={H} viewBox={`0 0 ${W} ${H}`} role="img" aria-label={`Recent estimates: ${vals.join(', ')}`}>
      <path d={d} fill="none" strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
      {pts.map((p, i) => (
        <circle key={i} cx={x(Date.parse(p.observedAt))} cy={y(p.value)} r={p === last ? 2.8 : 1.6} />
      ))}
    </svg>
  );
}

export function TrendTag({ trend }: { trend: OccupancyTrend }) {
  const map = {
    rising: { Icon: ArrowUpRight, label: 'Rising', cls: 'tr-up' },
    falling: { Icon: ArrowDownRight, label: 'Falling', cls: 'tr-down' },
    stable: { Icon: ArrowRight, label: 'Stable', cls: 'tr-flat' },
    unknown: { Icon: HelpCircle, label: 'Trend unknown', cls: 'tr-unknown' },
  }[trend.direction];
  return (
    <span className={`trend ${map.cls}`} title={trend.ratePerMin != null ? `${trend.ratePerMin} people/min over ${trend.spanMin} min (${trend.readings.length} estimates)` : 'Fewer than two recent estimates'}>
      <map.Icon size={13} aria-hidden /> {map.label}
      {trend.ratePerMin != null && trend.direction !== 'stable' && (
        <em>
          {trend.ratePerMin > 0 ? '+' : ''}
          {Math.round(trend.ratePerMin)}/min
        </em>
      )}
    </span>
  );
}

export function OccupancyBar({ risk, zone }: { risk: ZoneRisk; zone: Zone }) {
  const o = risk.occupancy;
  if (o.value == null) {
    return (
      <div className="occ occ-missing">
        <div className="occ-label">
          <strong>Occupancy unknown</strong> — no estimate recorded; not assumed empty
        </div>
      </div>
    );
  }
  const pct = o.pct ?? 0;
  const marks = [zone.watchPct, zone.elevatedPct, zone.criticalPct].filter((x): x is number => x != null);
  const scale = Math.max(120, ...marks.map((m) => m + 5), pct + 5);
  return (
    <div className={`occ ${o.stale ? 'occ-stale' : ''}`}>
      <div className="occ-track" role="meter" aria-valuemin={0} aria-valuemax={zone.capacity ?? undefined} aria-valuenow={o.value} aria-label="Estimated occupancy">
        <div className={`occ-fill lvl-${risk.level}`} style={{ width: `${Math.min(100, (pct / scale) * 100)}%` }} />
        {marks.map((m, i) => (
          <span key={i} className="occ-mark" style={{ left: `${(m / scale) * 100}%` }} title={`${['Watch', 'Elevated', 'Critical'][i]} threshold ${m}%`} />
        ))}
      </div>
      <div className="occ-label">
        <strong>
          {o.value.toLocaleString('en-IN')} / {o.capacity?.toLocaleString('en-IN') ?? '?'}
        </strong>{' '}
        ({o.pct ?? '?'}%) · est. {fmtTime(o.observedAt)} ({ago(o.observedAt)}){o.stale && <span className="tag tag-stale">STALE</span>}
        <div className="occ-trend">
          <TrendTag trend={o.trend} />
          <Sparkline trend={o.trend} capacity={o.capacity} level={risk.level} />
        </div>
        <div className="occ-src">{o.source}</div>
      </div>
    </div>
  );
}

export function RiskConditions({ risk, max }: { risk: ZoneRisk; max?: number }) {
  const list = max ? risk.conditions.slice(0, max) : risk.conditions;
  if (!risk.conditions.length) return <p className="muted small">No active configured threshold or unresolved condition.</p>;
  return (
    <ul className="conds">
      {list.map((c, i) => (
        <li key={i} className={`cond cond-${c.level}`}>
          <LevelBadge level={c.level} size="sm" />
          <div>
            <div className="cond-msg">
              {c.critical && <span className="tag tag-critical">DESIGNATED CRITICAL CONDITION</span>}
              {c.message}
            </div>
            <div className="cond-meta">
              Source: {c.source}
              {c.observedAt && ` · ${fmtTime(c.observedAt)} (${ago(c.observedAt)})`}
              {c.verified === false && <span className="tag tag-unverified">unverified</span>}
              {c.verified === true && <span className="tag tag-verified">verified</span>}
              {c.stale && <span className="tag tag-stale">stale</span>}
              <span className="cond-code">{c.code}</span>
            </div>
          </div>
        </li>
      ))}
      {max && risk.conditions.length > max && <li className="muted small">+{risk.conditions.length - max} more condition(s)</li>}
    </ul>
  );
}

export function RiskExplain({ risk, zone }: { risk: ZoneRisk; zone: Zone }) {
  return (
    <div className="risk-explain">
      <div className="risk-head">
        <LevelBadge level={risk.level} size="lg" />
        <span className="muted small">Computed {fmtTime(risk.computedAt, true)} from current records</span>
      </div>
      <OccupancyBar risk={risk} zone={zone} />
      {risk.occupancy.trend.readings.length > 0 && (
        <details className="readings">
          <summary>Recent estimates ({risk.occupancy.trend.readings.length})</summary>
          <table className="table compact">
            <tbody>
              {[...risk.occupancy.trend.readings].reverse().map((r, i) => (
                <tr key={i}>
                  <td className="nowrap">{fmtTime(r.observedAt)}</td>
                  <td className="nowrap">{r.ageMin} min ago</td>
                  <td>
                    <strong>{r.value.toLocaleString('en-IN')}</strong>
                  </td>
                  <td className="tiny muted">{r.source}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="tiny muted">Manual, timestamped estimates. The trend is a straight-line fit over recent readings, not a forecast or a measured crowd density.</p>
        </details>
      )}
      <h4>Why this level</h4>
      <RiskConditions risk={risk} />
      {risk.missingInputs.length > 0 && (
        <p className="missing">
          <strong>Missing inputs:</strong> {risk.missingInputs.join(', ')} — treated as unknown, never as safe.
        </p>
      )}
      <div className="next-step">
        <strong>Recommended next step:</strong> {risk.recommendedNextStep}
      </div>
      <p className="muted tiny">
        Rules-based assessment with configured thresholds (watch {zone.watchPct}%, elevated {zone.elevatedPct}%, critical {zone.criticalPct ?? '—'}%). The level is the highest individual condition — never an average — and is not a probability. It supports, and does not replace, the judgement of
        the designated safety officer.
      </p>
    </div>
  );
}
