import { useState } from 'react';
import { Link } from 'react-router-dom';
import { X } from 'lucide-react';
import { useLive } from '../lib/live';
import { useSession } from '../lib/session';
import { api } from '../lib/api';
import { can } from '@shared/permissions';
import { CATEGORY_LABEL } from '@shared/constants';
import type { MapSelection } from './VenueMap';
import { RiskExplain } from './RiskExplain';
import { Ago, ReasonDialog, SeverityTag, StatusChip, useAction, VerifyChip } from './ui';
import { fmtTime, metres } from '../lib/format';

export function SegmentStatusDialog({ segmentId, to, onClose }: { segmentId: string; to: 'open' | 'under_review' | 'closed'; onClose: () => void }) {
  const { reload, snap } = useLive();
  const [source, setSource] = useState('Control-room decision');
  const seg = snap!.segments.find((s) => s.id === segmentId)!;
  return (
    <ReasonDialog
      title={`${to === 'closed' ? 'Close' : to === 'under_review' ? 'Mark for review' : 'Reopen'}: ${seg.name}`}
      required={to !== 'open'}
      tone={to === 'closed' ? 'danger' : 'primary'}
      confirmLabel={to === 'closed' ? 'Close segment' : to === 'under_review' ? 'Mark under review' : 'Reopen segment'}
      placeholder={to === 'closed' ? 'e.g. Debris on the road reported by inspection team' : ''}
      extra={
        <>
          <label className="field">
            <span>Source of information</span>
            <input value={source} onChange={(e) => setSource(e.target.value)} maxLength={200} />
          </label>
          <p className="muted small">
            This changes the status in the approved venue route network only. It does not close public roads or redirect traffic — that is decided by the authorised body.
          </p>
        </>
      }
      onSubmit={async (note) => {
        await api.post(`/api/segments/${segmentId}/status`, { status: to, reason: note, source });
        await reload();
      }}
      onClose={onClose}
    />
  );
}

export function FacilityStatusDialog({ facilityId, onClose }: { facilityId: string; onClose: () => void }) {
  const { reload, snap } = useLive();
  const f = snap!.facilities.find((x) => x.id === facilityId)!;
  const to = f.status === 'open' ? 'closed' : 'open';
  return (
    <ReasonDialog
      title={to === 'closed' ? `Mark ${f.name} unavailable` : `Mark ${f.name} available`}
      required={to === 'closed'}
      tone={to === 'closed' ? 'danger' : 'primary'}
      confirmLabel={to === 'closed' ? 'Mark unavailable' : 'Mark available'}
      onSubmit={async (note) => {
        await api.post(`/api/facilities/${facilityId}/status`, { status: to, reason: note });
        await reload();
      }}
      onClose={onClose}
    />
  );
}

export function FeatureDetails({ selection, onClose }: { selection: MapSelection; onClose: () => void }) {
  const { snap } = useLive();
  const { me } = useSession();
  const [dialog, setDialog] = useState<null | { kind: 'segment'; to: 'open' | 'under_review' | 'closed' } | { kind: 'facility' }>(null);
  if (!selection || !snap) return null;
  const role = me!.user.role;

  let body: React.ReactNode = null;
  let title = '';
  if (selection.type === 'zone') {
    const z = snap.zones.find((x) => x.id === selection.id);
    const r = snap.risks?.find((x) => x.zoneId === selection.id);
    if (!z) return null;
    title = z.name;
    body = (
      <>
        {r ? <RiskExplain risk={r} zone={z} /> : <p className="muted">Risk details are visible to the control room.</p>}
        <dl className="kv">
          <dt>Exits</dt>
          <dd>
            {z.exitIds.map((id) => {
              const f = snap.facilities.find((x) => x.id === id);
              return (
                <div key={id}>
                  {f?.name ?? id} {z.requiredExitIds.includes(id) && <span className="tag">required by plan</span>} {f?.status === 'closed' && <span className="tag tag-critical">UNAVAILABLE</span>}
                </div>
              );
            })}
          </dd>
          {z.notes && (
            <>
              <dt>Notes</dt>
              <dd>{z.notes}</dd>
            </>
          )}
        </dl>
      </>
    );
  } else if (selection.type === 'facility') {
    const f = snap.facilities.find((x) => x.id === selection.id);
    if (!f) return null;
    title = f.name;
    body = (
      <>
        <dl className="kv">
          <dt>Type</dt>
          <dd>{f.kind}</dd>
          <dt>Status</dt>
          <dd>
            {f.status === 'open' ? <span className="chip chip-ok">Available</span> : <span className="chip chip-danger">UNAVAILABLE</span>}
            {f.statusReason && <div className="small">{f.statusReason}</div>}
            <div className="muted small">
              Updated {fmtTime(f.statusUpdatedAt)} (<Ago iso={f.statusUpdatedAt} />)
            </div>
          </dd>
          {f.capacityPerMin != null && (
            <>
              <dt>Configured throughput</dt>
              <dd>{f.capacityPerMin} people/min (configured, not measured)</dd>
            </>
          )}
          {f.notes && (
            <>
              <dt>Notes</dt>
              <dd>{f.notes}</dd>
            </>
          )}
        </dl>
        {can(role, 'facility.setStatus') && ['gate', 'exit', 'assembly', 'medical'].includes(f.kind) && (
          <button className={`btn ${f.status === 'open' ? 'btn-danger' : 'btn-primary'}`} onClick={() => setDialog({ kind: 'facility' })}>
            {f.status === 'open' ? 'Mark unavailable…' : 'Mark available…'}
          </button>
        )}
      </>
    );
  } else if (selection.type === 'segment') {
    const s = snap.segments.find((x) => x.id === selection.id);
    if (!s) return null;
    const n = (id: string) => snap.nodes.find((x) => x.id === id)?.name ?? id;
    const dependents = (snap.namedRoutes ?? []).filter((r) => r.segmentIds.includes(s.id));
    title = s.name;
    body = (
      <>
        <dl className="kv">
          <dt>Connects</dt>
          <dd>
            {n(s.fromNode)} ↔ {n(s.toNode)}
          </dd>
          <dt>Status</dt>
          <dd>
            <span className={`chip ${s.status === 'open' ? 'chip-ok' : s.status === 'closed' ? 'chip-danger' : 'chip-warn'}`}>{s.status === 'open' ? 'Open' : s.status === 'closed' ? 'CLOSED' : 'UNDER REVIEW'}</span>
            {s.statusReason && <div className="small">{s.statusReason}</div>}
            <div className="muted small">
              Source: {s.statusSource ?? '—'} · {fmtTime(s.statusUpdatedAt)} (<Ago iso={s.statusUpdatedAt} />)
            </div>
          </dd>
          <dt>Travel</dt>
          <dd>
            {s.modes.join(' + ')} · {s.access} access · {metres(s.distanceM)} (configured)
          </dd>
          <dt>Approved</dt>
          <dd>{s.approved ? 'Yes — in the approved venue route network' : 'No — excluded from recommendations'}</dd>
          {s.constraintNote && (
            <>
              <dt>Constraint</dt>
              <dd>{s.constraintNote}</dd>
            </>
          )}
          {s.terrainNote && (
            <>
              <dt>Terrain note</dt>
              <dd>{s.terrainNote}</dd>
            </>
          )}
          <dt>Approved routes using it</dt>
          <dd>{dependents.length ? dependents.map((r) => <div key={r.id}>{r.name}</div>) : '—'}</dd>
        </dl>
        {can(role, 'route.setStatus') && (
          <div className="btn-row">
            {s.status !== 'closed' && (
              <button className="btn btn-danger" onClick={() => setDialog({ kind: 'segment', to: 'closed' })}>
                Close…
              </button>
            )}
            {s.status === 'open' && (
              <button className="btn" onClick={() => setDialog({ kind: 'segment', to: 'under_review' })}>
                Mark for review…
              </button>
            )}
            {s.status !== 'open' && (
              <button className="btn btn-primary" onClick={() => setDialog({ kind: 'segment', to: 'open' })}>
                Reopen…
              </button>
            )}
          </div>
        )}
      </>
    );
  } else if (selection.type === 'incident') {
    const i = snap.incidents.find((x) => x.id === selection.id);
    if (!i) return null;
    const z = snap.zones.find((x) => x.id === i.zoneId);
    title = `${i.ref} · ${CATEGORY_LABEL[i.category]}`;
    body = (
      <>
        <div className="chips">
          <StatusChip status={i.status} />
          <VerifyChip status={i.status} />
          <SeverityTag severity={i.confirmedSeverity ?? i.severityEstimate} confirmed={!!i.confirmedSeverity} />
          {i.urgent && <span className="chip chip-danger">URGENT</span>}
        </div>
        <p>{i.description}</p>
        <dl className="kv">
          <dt>Zone</dt>
          <dd>{z?.name ?? '—'}</dd>
          <dt>Reported</dt>
          <dd>
            {fmtTime(i.receivedAt)} by {i.reporterName} (<Ago iso={i.receivedAt} />)
          </dd>
          <dt>Last update</dt>
          <dd>
            <Ago iso={i.updatedAt} />
          </dd>
        </dl>
        {can(role, 'incident.viewAll') && (
          <Link className="btn btn-primary" to={`/incidents/${i.id}`}>
            Open incident
          </Link>
        )}
      </>
    );
  } else if (selection.type === 'responder') {
    const r = snap.responders?.find((x) => x.id === selection.id);
    if (!r) return null;
    const active = (snap.assignments ?? []).find((a) => a.responderId === r.id && ['assigned', 'acknowledged', 'en_route', 'on_scene'].includes(a.status));
    const inc = active && snap.incidents.find((i) => i.id === active.incidentId);
    title = r.name;
    body = (
      <dl className="kv">
        <dt>Status</dt>
        <dd>{r.status.replace('_', ' ')}</dd>
        <dt>Team</dt>
        <dd>
          {r.team} · {r.modes.join(' + ')} · {r.access} access
        </dd>
        <dt>Position</dt>
        <dd>
          {r.locationSource}
          <div className="muted small">Updated {fmtTime(r.locationUpdatedAt)} — positions are not live GPS.</div>
        </dd>
        {inc && (
          <>
            <dt>Current task</dt>
            <dd>
              <Link to={`/incidents/${inc.id}`}>{inc.ref}</Link> — {active!.status.replace('_', ' ')}
            </dd>
          </>
        )}
      </dl>
    );
  }

  return (
    <aside className="details-panel" aria-label="Selected map feature">
      <header>
        <h3>{title}</h3>
        <button className="icon-btn" onClick={onClose} aria-label="Close details">
          <X size={18} />
        </button>
      </header>
      <div className="details-body">{body}</div>
      {dialog?.kind === 'segment' && <SegmentStatusDialog segmentId={selection.id} to={dialog.to} onClose={() => setDialog(null)} />}
      {dialog?.kind === 'facility' && <FacilityStatusDialog facilityId={selection.id} onClose={() => setDialog(null)} />}
    </aside>
  );
}

export { useAction };
