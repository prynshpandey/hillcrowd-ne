import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2, Circle, Play, RotateCcw } from 'lucide-react';
import { api } from '../lib/api';
import { useLive } from '../lib/live';
import { Card, Modal, Notice, useToast } from './ui';

interface Step {
  key: string;
  n: number;
  title: string;
  actor: string;
  description: string;
  shows: string;
  done: boolean;
}
interface State {
  steps: Step[];
  incidentId: string | null;
  next: string | null;
}

export function DemoPanel() {
  const { reload, snap } = useLive();
  const toast = useToast();
  const [state, setState] = useState<State | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [confirmReset, setConfirmReset] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setState(await api.get<State>('/api/demo/scenario'));
      setErr(null);
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Failed to load scenario');
    }
  }, []);
  // Re-read scenario progress whenever the live snapshot changes (steps can also be done manually in the UI).
  useEffect(() => {
    load();
  }, [load, snap?.serverTime]);

  const run = async (key: string) => {
    setBusy(key);
    try {
      setState(await api.post<State>(`/api/demo/scenario/${key}`));
      await reload();
      toast('ok', 'Scenario step completed');
    } catch (e) {
      toast('danger', e instanceof Error ? e.message : 'Step failed');
    } finally {
      setBusy(null);
    }
  };

  const reset = async () => {
    setBusy('reset');
    try {
      setState(await api.post<State>('/api/demo/reset'));
      await reload();
      toast('ok', 'Demo scenario reset to its initial state');
    } catch (e) {
      toast('danger', e instanceof Error ? e.message : 'Reset failed');
    } finally {
      setBusy(null);
      setConfirmReset(false);
    }
  };

  if (!snap?.event.isDemo) return null;
  return (
    <Card
      className="demo-panel"
      title={
        <>
          <span className="demo-badge">DEMO</span> Scenario: escalating congestion during adverse weather
        </>
      }
      subtitle="Each step runs through the normal workflow as the named demo user and is recorded in the audit log. You can also perform any step manually in the UI."
      actions={
        <button className="btn btn-ghost" onClick={() => setConfirmReset(true)} disabled={!!busy}>
          <RotateCcw size={15} /> Reset demo scenario
        </button>
      }
    >
      {err && <Notice tone="danger">{err}</Notice>}
      <ol className="demo-steps">
        {state?.steps.map((s) => (
          <li key={s.key} className={`demo-step ${s.done ? 'done' : ''} ${state.next === s.key ? 'next' : ''}`}>
            <span className="demo-step-icon">{s.done ? <CheckCircle2 size={18} /> : <Circle size={18} />}</span>
            <div className="demo-step-body">
              <div className="demo-step-title">
                {s.n}. {s.title} <span className="muted small">— {s.actor}</span>
              </div>
              <div className="small">{s.description}</div>
              <div className="tiny muted">Demonstrates: {s.shows}</div>
            </div>
            {!s.done && state.next === s.key && (
              <button className="btn btn-primary btn-sm" onClick={() => run(s.key)} disabled={!!busy}>
                <Play size={14} /> {busy === s.key ? 'Running…' : 'Run step'}
              </button>
            )}
          </li>
        ))}
        {state && !state.next && (
          <li className="demo-step done">
            <span className="demo-step-icon">
              <CheckCircle2 size={18} />
            </span>
            <div className="demo-step-body">
              <div className="demo-step-title">10. Review the event</div>
              <div className="small">
                Open <Link to="/analytics">Analytics</Link> to see recorded times, the closure and response sequence, and the decision timeline.
              </div>
            </div>
          </li>
        )}
      </ol>
      {state?.incidentId && (
        <p className="small">
          Scenario incident: <Link to={`/incidents/${state.incidentId}`}>open incident record</Link>
        </p>
      )}
      {confirmReset && (
        <Modal title="Reset demo scenario?" onClose={() => setConfirmReset(false)}>
          <p>This deletes and re-seeds only the demonstration event (incidents, assignments, advisories, closures, demo audit entries). Other events and users are not touched. A permanent audit entry records the reset.</p>
          <div className="modal-actions">
            <button className="btn" onClick={() => setConfirmReset(false)}>
              Cancel
            </button>
            <button className="btn btn-danger" onClick={reset} disabled={busy === 'reset'}>
              {busy === 'reset' ? 'Resetting…' : 'Reset demo'}
            </button>
          </div>
        </Modal>
      )}
    </Card>
  );
}
