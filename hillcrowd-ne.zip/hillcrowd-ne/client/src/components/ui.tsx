import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import { AlertOctagon, AlertTriangle, CheckCircle2, Eye, Info, X } from 'lucide-react';
import { RISK_LABEL, STATUS_LABEL } from '@shared/constants';
import type { IncidentStatus, RiskLevel, Severity } from '@shared/types';
import { ago } from '../lib/format';

const LEVEL_ICON = { normal: CheckCircle2, watch: Eye, elevated: AlertTriangle, critical: AlertOctagon } as const;

export function LevelBadge({ level, size = 'md', suffix }: { level: RiskLevel; size?: 'sm' | 'md' | 'lg'; suffix?: string }) {
  const Icon = LEVEL_ICON[level];
  return (
    <span className={`level level-${level} level-${size}`} title={`Risk level: ${RISK_LABEL[level]}`}>
      <Icon aria-hidden size={size === 'lg' ? 18 : size === 'sm' ? 12 : 14} strokeWidth={2.4} />
      {RISK_LABEL[level]}
      {suffix ? <span className="level-suffix">{suffix}</span> : null}
    </span>
  );
}

const STATUS_TONE: Record<IncidentStatus, string> = {
  submitted: 'warn',
  under_review: 'warn',
  verified: 'info',
  rejected: 'muted',
  assigned: 'info',
  acknowledged: 'info',
  in_progress: 'active',
  resolved: 'ok',
  closed: 'muted',
};

export function StatusChip({ status }: { status: IncidentStatus }) {
  return <span className={`chip chip-${STATUS_TONE[status]}`}>{STATUS_LABEL[status]}</span>;
}

export function VerifyChip({ status }: { status: IncidentStatus }) {
  if (status === 'submitted' || status === 'under_review') return <span className="chip chip-unverified">UNVERIFIED</span>;
  if (status === 'rejected' || status === 'verified') return null; // already stated by the status chip
  return <span className="chip chip-verified">Verified</span>;
}

export function SeverityTag({ severity, confirmed }: { severity: Severity; confirmed: boolean }) {
  return (
    <span className={`sev sev-${severity}`} title={confirmed ? 'Severity confirmed by control room' : 'Reporter estimate, not yet confirmed'}>
      <span className="sev-bars" aria-hidden>
        {[0, 1, 2, 3].map((i) => (
          <i key={i} className={i <= ['low', 'moderate', 'high', 'critical'].indexOf(severity) ? 'on' : ''} />
        ))}
      </span>
      {severity[0].toUpperCase() + severity.slice(1)}
      {!confirmed && <em className="sev-est">est.</em>}
    </span>
  );
}

export function DemoBadge({ label = 'DEMO DATA' }: { label?: string }) {
  return <span className="demo-badge">{label}</span>;
}

export function Ago({ iso, prefix }: { iso: string | null | undefined; prefix?: string }) {
  const [, t] = useState(0);
  useEffect(() => {
    const i = setInterval(() => t((x) => x + 1), 10_000);
    return () => clearInterval(i);
  }, []);
  return (
    <time dateTime={iso ?? undefined} title={iso ? new Date(iso).toLocaleString('en-IN') : undefined}>
      {prefix}
      {ago(iso)}
    </time>
  );
}

export function Card({ title, actions, children, className = '', id, subtitle }: { title?: ReactNode; subtitle?: ReactNode; actions?: ReactNode; children: ReactNode; className?: string; id?: string }) {
  return (
    <section className={`card ${className}`} id={id}>
      {(title || actions) && (
        <header className="card-head">
          <div>
            {title && <h2 className="card-title">{title}</h2>}
            {subtitle && <div className="card-sub">{subtitle}</div>}
          </div>
          {actions && <div className="card-actions">{actions}</div>}
        </header>
      )}
      <div className="card-body">{children}</div>
    </section>
  );
}

export function Empty({ children }: { children: ReactNode }) {
  return <div className="empty">{children}</div>;
}

export function Notice({ tone = 'info', children, title }: { tone?: 'info' | 'warn' | 'danger' | 'ok'; children: ReactNode; title?: string }) {
  const Icon = tone === 'danger' ? AlertOctagon : tone === 'warn' ? AlertTriangle : tone === 'ok' ? CheckCircle2 : Info;
  return (
    <div className={`notice notice-${tone}`} role={tone === 'danger' ? 'alert' : 'status'}>
      <Icon size={16} aria-hidden />
      <div>
        {title && <strong>{title} </strong>}
        {children}
      </div>
    </div>
  );
}

export function Modal({ title, onClose, children, wide }: { title: string; onClose: () => void; children: ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', k);
    ref.current?.querySelector<HTMLElement>('input,textarea,select,button')?.focus();
    return () => window.removeEventListener('keydown', k);
  }, [onClose]);
  return (
    <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`modal ${wide ? 'modal-wide' : ''}`} role="dialog" aria-modal="true" aria-label={title} ref={ref}>
        <header className="modal-head">
          <h2>{title}</h2>
          <button className="icon-btn" onClick={onClose} aria-label="Close">
            <X size={18} />
          </button>
        </header>
        <div className="modal-body">{children}</div>
      </div>
    </div>
  );
}

/** Prompt for a reason/note before an action; required notes block submission until filled. */
export function ReasonDialog({
  title,
  label = 'Reason / note',
  required,
  confirmLabel = 'Confirm',
  tone = 'primary',
  extra,
  onSubmit,
  onClose,
  placeholder,
}: {
  title: string;
  label?: string;
  required?: boolean;
  confirmLabel?: string;
  tone?: 'primary' | 'danger';
  extra?: ReactNode;
  placeholder?: string;
  onSubmit: (note: string) => Promise<unknown>;
  onClose: () => void;
}) {
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  return (
    <Modal title={title} onClose={onClose}>
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          if (required && !note.trim()) return setErr('This action requires a reason.');
          setBusy(true);
          try {
            await onSubmit(note.trim());
            onClose();
          } catch (ex) {
            setErr(ex instanceof Error ? ex.message : 'Failed');
          } finally {
            setBusy(false);
          }
        }}
      >
        {extra}
        <label className="field">
          <span>
            {label} {required ? <em className="req">required</em> : <em className="opt">optional</em>}
          </span>
          <textarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} placeholder={placeholder} maxLength={1000} />
        </label>
        {err && <Notice tone="danger">{err}</Notice>}
        <div className="modal-actions">
          <button type="button" className="btn" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className={`btn ${tone === 'danger' ? 'btn-danger' : 'btn-primary'}`} disabled={busy}>
            {busy ? 'Working…' : confirmLabel}
          </button>
        </div>
      </form>
    </Modal>
  );
}

// ---------------- toasts ----------------
interface Toast {
  id: number;
  tone: 'ok' | 'danger' | 'info';
  text: string;
}
const ToastCtx = createContext<(tone: Toast['tone'], text: string) => void>(() => {});

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const push = useCallback((tone: Toast['tone'], text: string) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t.slice(-3), { id, tone, text }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), tone === 'danger' ? 7000 : 4000);
  }, []);
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="toasts" aria-live="polite">
        {toasts.map((t) => (
          <div key={t.id} className={`toast toast-${t.tone}`}>
            {t.text}
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}
export const useToast = () => useContext(ToastCtx);

/** Run an async action with toast feedback. */
export function useAction() {
  const toast = useToast();
  return useCallback(
    async <T,>(fn: () => Promise<T>, ok?: string): Promise<T | undefined> => {
      try {
        const out = await fn();
        if (ok) toast('ok', ok);
        return out;
      } catch (e) {
        toast('danger', e instanceof Error ? e.message : 'Action failed');
        return undefined;
      }
    },
    [toast],
  );
}
