import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Activity, Zap, X } from 'lucide-react';
import { api } from '../lib/api';
import { useLive } from '../lib/live';
import { useToast } from './ui';

interface Injection {
  key: string;
  title: string;
  detail: string;
  group: string;
}

/**
 * Exercise controls for demonstrations: inject clearly labelled simulated events at any time.
 * Each inject runs through the normal services and is recorded as simulated in the audit log.
 */
export function ExerciseDrawer() {
  const { snap, reload } = useLive();
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<Injection[]>([]);
  const [busy, setBusy] = useState<string | null>(null);
  const [done, setDone] = useState<string[]>([]);

  useEffect(() => {
    if (open && !items.length) api.get<Injection[]>('/api/demo/injections').then(setItems).catch(() => setItems([]));
  }, [open, items.length]);

  if (!snap?.event.isDemo) return null;
  const groups = [...new Set(items.map((i) => i.group))];

  const inject = async (key: string) => {
    setBusy(key);
    try {
      const r = await api.post<{ injected: string }>(`/api/demo/inject/${key}`);
      setDone((d) => [...d, key]);
      await reload();
      toast('ok', `Simulated: ${r.injected}`);
    } catch (e) {
      toast('danger', e instanceof Error ? e.message : 'Inject failed');
    } finally {
      setBusy(null);
    }
  };

  return (
    <>
      <button className={`exercise-fab ${open ? 'on' : ''}`} onClick={() => setOpen((o) => !o)} aria-expanded={open}>
        <Zap size={16} /> Exercise
      </button>
      {open && (
        <aside className="exercise-panel" aria-label="Exercise controls">
          <header>
            <div>
              <strong>Live exercise</strong>
              <div className="tiny">Trigger simulated events and watch the system respond. Every event is labelled SIMULATED.</div>
            </div>
            <button className="icon-btn" onClick={() => setOpen(false)} aria-label="Close exercise controls">
              <X size={18} />
            </button>
          </header>
          <div className="exercise-body">
            {groups.map((g) => (
              <div key={g} className="ex-group">
                <div className="ex-group-title">{g}</div>
                {items
                  .filter((i) => i.group === g)
                  .map((i) => (
                    <button key={i.key} className={`ex-item ${done.includes(i.key) ? 'done' : ''}`} onClick={() => inject(i.key)} disabled={!!busy}>
                      <Activity size={14} aria-hidden />
                      <span>
                        <strong>{busy === i.key ? 'Injecting…' : i.title}</strong>
                        <em>{i.detail}</em>
                      </span>
                    </button>
                  ))}
              </div>
            ))}
            <p className="tiny muted">
              Try: <em>Lower service road closed</em> → <em>Upper ring road closed</em>, then open the <Link to="/resilience">Resilience Lab</Link>. Undo closures from Route Planning, or reset the demo from the Overview. Review everything afterwards in <Link to="/analytics">Analytics → Replay</Link>.
            </p>
          </div>
        </aside>
      )}
    </>
  );
}
