import { useEffect, useMemo, useRef, useState } from 'react';
import { MapContainer, Marker, Polygon, Polyline, TileLayer, Tooltip, useMap, useMapEvents } from 'react-leaflet';
import L, { type LatLngBoundsExpression, type LatLngExpression } from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { RISK_LABEL } from '@shared/constants';
import { polygonCentroid } from '@shared/geo';
import type { Facility, Incident, Responder, RiskLevel, RouteSegment } from '@shared/types';
import type { Snapshot } from '../lib/types';
import { safeStorage } from '../lib/storage';
import { useLiveOptional } from '../lib/live';
import { fmtTime } from '../lib/format';
import { Layers } from 'lucide-react';

export type MapSelection = { type: 'zone' | 'facility' | 'segment' | 'incident' | 'responder'; id: string } | null;

export interface RouteHighlight {
  segmentIds: string[];
  tone: 'primary' | 'alternative' | 'blocked';
  label?: string;
}

export interface LayerState {
  zones: boolean;
  routes: boolean;
  facilities: boolean;
  incidents: boolean;
  responders: boolean;
  advisories: boolean;
  closedIncidents: boolean;
}

const DEFAULT_LAYERS: LayerState = { zones: true, routes: true, facilities: true, incidents: true, responders: true, advisories: true, closedIncidents: false };

type Basemap = 'osm' | 'topo' | 'schematic';
const BASEMAPS: Record<Exclude<Basemap, 'schematic'>, { url: string; attribution: string; maxZoom: number; label: string }> = {
  osm: { url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors', maxZoom: 19, label: 'Street map (OSM)' },
  topo: {
    url: 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
    attribution: 'Map data &copy; OpenStreetMap contributors, SRTM | Style &copy; <a href="https://opentopomap.org">OpenTopoMap</a> (CC-BY-SA)',
    maxZoom: 17,
    label: 'Terrain context (OpenTopoMap contours)',
  },
};

export const LEVEL_COLOR: Record<RiskLevel, string> = { normal: '#2f7d4f', watch: '#a16207', elevated: '#c2410c', critical: '#b91c1c' };

const FAC_GLYPH: Record<Facility['kind'], string> = { gate: 'G', exit: 'EX', medical: '+', assembly: 'AP', control: 'CR', handover: 'H' };

function facilityIcon(f: Facility, selected: boolean) {
  const closed = f.status === 'closed';
  return L.divIcon({
    className: '',
    html: `<div class="mk mk-${f.kind}${closed ? ' mk-closed' : ''}${selected ? ' mk-sel' : ''}" role="img" aria-label="${f.name}${closed ? ' (unavailable)' : ''}"><span>${FAC_GLYPH[f.kind]}</span>${closed ? '<b class="mk-x" aria-hidden="true">✕</b>' : ''}</div>`,
    iconSize: [30, 30],
    iconAnchor: [15, 15],
  });
}

function incidentIcon(i: Incident, selected: boolean) {
  const unverified = i.status === 'submitted' || i.status === 'under_review';
  const sev = i.confirmedSeverity ?? i.severityEstimate;
  const done = ['resolved', 'closed', 'rejected'].includes(i.status);
  return L.divIcon({
    className: '',
    html: `<div class="mk-inc sev-${sev}${unverified ? ' unverified' : ''}${done ? ' done' : ''}${selected ? ' mk-sel' : ''}"><span class="mk-inc-glyph">${unverified ? '?' : '!'}</span><span class="mk-inc-ref">${i.ref}${i.urgent && !done ? ' ⚑' : ''}</span></div>`,
    iconSize: [74, 26],
    iconAnchor: [13, 13],
  });
}

function responderIcon(r: Responder, selected: boolean) {
  const initials = r.name
    .split(/\s+/)
    .filter((w) => /^[A-Za-z]/.test(w))
    .slice(0, 2)
    .map((w) => w[0])
    .join('')
    .toUpperCase();
  return L.divIcon({
    className: '',
    html: `<div class="mk-resp st-${r.status}${selected ? ' mk-sel' : ''}" title="${r.name}"><span>${initials}</span></div>`,
    iconSize: [26, 26],
    iconAnchor: [13, 13],
  });
}

function segmentStyle(s: RouteSegment) {
  if (s.status === 'closed') return { color: '#b91c1c', weight: 5, dashArray: '2 9', opacity: 0.95, lineCap: 'round' as const };
  if (s.status === 'under_review') return { color: '#a16207', weight: 5, dashArray: '10 7', opacity: 0.95 };
  if (!s.approved) return { color: '#64748b', weight: 3, dashArray: '4 6', opacity: 0.8 };
  const vehicle = s.modes.includes('vehicle');
  return { color: vehicle ? '#1f4e79' : '#2c5e4b', weight: vehicle ? 4.5 : 3.5, opacity: 0.85 };
}

function FitOnce({ bounds, keyId, tight }: { bounds: LatLngBoundsExpression | null; keyId: string; tight?: boolean }) {
  const map = useMap();
  const done = useRef<string | null>(null);
  useEffect(() => {
    if (bounds && done.current !== keyId) {
      map.fitBounds(bounds, { padding: [tight ? 6 : 24, tight ? 6 : 24], maxZoom: 18 });
      done.current = keyId;
    }
  }, [bounds, keyId, map]);
  return null;
}

function ClickCatcher({ onClick }: { onClick?: (lat: number, lng: number) => void }) {
  useMapEvents({ click: (e) => onClick?.(Number(e.latlng.lat.toFixed(6)), Number(e.latlng.lng.toFixed(6))) });
  return null;
}

function FlyTo({ target }: { target: [number, number] | null }) {
  const map = useMap();
  useEffect(() => {
    if (target) map.flyTo(target, Math.max(map.getZoom(), 17), { duration: 0.5 });
  }, [target, map]);
  return null;
}

export function VenueMap({
  snap,
  height = '100%',
  selection,
  onSelect,
  onMapClick,
  clickMarker,
  highlights = [],
  showControls = true,
  showLegend = true,
  initialLayers,
  focus,
  compact,
  legendOpen = false,
}: {
  snap: Snapshot;
  height?: number | string;
  selection?: MapSelection;
  onSelect?: (s: MapSelection) => void;
  onMapClick?: (lat: number, lng: number) => void;
  clickMarker?: [number, number] | null;
  highlights?: RouteHighlight[];
  showControls?: boolean;
  showLegend?: boolean;
  initialLayers?: Partial<LayerState>;
  focus?: [number, number] | null;
  compact?: boolean;
  legendOpen?: boolean;
}) {
  const [layers, setLayers] = useState<LayerState>({ ...DEFAULT_LAYERS, ...initialLayers });
  const [basemap, setBasemap] = useState<Basemap>(() => (safeStorage.get('hc.basemap') as Basemap) || 'osm');
  const [tileStats, setTileStats] = useState({ ok: 0, err: 0 });
  const [panelOpen, setPanelOpen] = useState(false);
  const tilesFailed = basemap !== 'schematic' && tileStats.err >= 4 && tileStats.ok === 0;
  const live = useLiveOptional();
  const effective: Basemap = tilesFailed ? 'schematic' : basemap;

  useEffect(() => setTileStats({ ok: 0, err: 0 }), [basemap]);

  const riskByZone = useMemo(() => new Map((snap.risks ?? []).map((r) => [r.zoneId, r])), [snap.risks]);
  const nodesById = useMemo(() => new Map(snap.nodes.map((n) => [n.id, n])), [snap.nodes]);
  const segById = useMemo(() => new Map(snap.segments.map((s) => [s.id, s])), [snap.segments]);

  const bounds = useMemo<LatLngBoundsExpression | null>(() => {
    const pts: [number, number][] = [...snap.event.boundary, ...snap.zones.flatMap((z) => z.polygon), ...snap.nodes.map((n) => [n.lat, n.lng] as [number, number])];
    if (!pts.length) return null;
    return L.latLngBounds(pts.map((p) => L.latLng(p[0], p[1])));
  }, [snap.event.id, snap.nodes.length, snap.zones.length]);

  const advisoryZones = useMemo(() => {
    const m = new Map<string, { title: string; verified: boolean; sample: boolean }[]>();
    const now = Date.now();
    for (const a of snap.advisories) {
      if (a.verification === 'rejected' || (a.expiresAt && new Date(a.expiresAt).getTime() < now)) continue;
      for (const z of a.affectedZoneIds) (m.get(z) ?? m.set(z, []).get(z)!).push({ title: a.title, verified: a.verification === 'verified', sample: a.isSample });
    }
    return m;
  }, [snap.advisories]);

  const visibleIncidents = snap.incidents.filter((i) => i.lat != null && !i.mergedInto && (layers.closedIncidents || !['closed', 'rejected'].includes(i.status)));
  const sel = (type: NonNullable<MapSelection>['type'], id: string) => selection?.type === type && selection.id === id;
  const pick = (type: NonNullable<MapSelection>['type'], id: string) => (e: L.LeafletMouseEvent) => {
    L.DomEvent.stopPropagation(e);
    onSelect?.({ type, id });
  };

  const center: LatLngExpression = [snap.event.centerLat, snap.event.centerLng];

  return (
    <div className={`venue-map ${compact ? 'compact' : ''} ${effective === 'schematic' ? 'schematic' : ''}`} style={{ height }}>
      <MapContainer center={center} zoom={snap.event.zoom} minZoom={12} maxZoom={19} scrollWheelZoom={!compact} style={{ height: '100%', width: '100%' }} attributionControl>
        {effective !== 'schematic' && (
          <TileLayer
            key={effective}
            url={BASEMAPS[effective].url}
            attribution={BASEMAPS[effective].attribution}
            maxZoom={19}
            maxNativeZoom={BASEMAPS[effective].maxZoom}
            eventHandlers={{
              tileload: () => setTileStats((s) => (s.ok > 0 ? s : { ...s, ok: s.ok + 1 })),
              tileerror: () => setTileStats((s) => ({ ...s, err: s.err + 1 })),
            }}
          />
        )}
        <FitOnce bounds={bounds} keyId={snap.event.id} tight={compact} />
        <FlyTo target={focus ?? null} />
        <ClickCatcher onClick={onMapClick ? onMapClick : onSelect ? () => onSelect(null) : undefined} />

        {snap.event.boundary.length > 2 && <Polygon positions={snap.event.boundary} pathOptions={{ color: '#0f2a22', weight: 2, dashArray: '6 6', fill: false }} interactive={false} />}

        {layers.zones &&
          snap.zones.map((z) => {
            const r = riskByZone.get(z.id);
            const level = r?.level ?? 'normal';
            const color = r ? LEVEL_COLOR[level] : '#475569';
            return (
              <Polygon
                key={z.id}
                positions={z.polygon}
                pathOptions={{ color, weight: sel('zone', z.id) ? 4 : 2, fillColor: color, fillOpacity: level === 'normal' ? 0.1 : level === 'watch' ? 0.18 : 0.26, dashArray: r?.occupancy.stale || r?.missingInputs.length ? '5 5' : undefined }}
                eventHandlers={{ click: pick('zone', z.id) }}
              >
                <Tooltip permanent={!compact} direction="center" className="zone-label" interactive={false}>
                  <span>{z.name.replace(/^Zone ([A-Z]) – /, '$1 · ')}</span>
                  {r && (
                    <b className={`zl-${level}`}>
                      {RISK_LABEL[level]}
                      {r.occupancy.pct != null ? ` · ${r.occupancy.pct}%` : ' · occ. unknown'}
                    </b>
                  )}
                </Tooltip>
              </Polygon>
            );
          })}

        {layers.advisories &&
          snap.zones
            .filter((z) => advisoryZones.has(z.id))
            .map((z) => (
              <Polygon key={`adv-${z.id}`} positions={z.polygon} pathOptions={{ color: '#1d4ed8', weight: 2, dashArray: '2 6', fill: false }} interactive={false}>
                <Tooltip sticky>
                  {advisoryZones.get(z.id)!.map((a, i) => (
                    <div key={i}>
                      {a.sample ? '[SAMPLE] ' : ''}
                      {a.verified ? 'Verified' : 'UNVERIFIED'} advisory: {a.title}
                    </div>
                  ))}
                </Tooltip>
              </Polygon>
            ))}

        {layers.routes &&
          snap.segments.map((s) => (
            <Polyline key={s.id} positions={s.path.length > 1 ? s.path : [[nodesById.get(s.fromNode)!.lat, nodesById.get(s.fromNode)!.lng], [nodesById.get(s.toNode)!.lat, nodesById.get(s.toNode)!.lng]]} pathOptions={{ ...segmentStyle(s), weight: segmentStyle(s).weight + (sel('segment', s.id) ? 3 : 0) }} eventHandlers={{ click: pick('segment', s.id) }}>
              <Tooltip sticky>
                <strong>{s.name}</strong>
                <br />
                {s.status === 'open' ? 'Open' : s.status === 'closed' ? 'CLOSED' : 'UNDER REVIEW'} · {s.modes.join(' + ')} · {s.access} access · {s.distanceM} m
              </Tooltip>
            </Polyline>
          ))}

        {layers.routes &&
          snap.segments
            .filter((s) => s.status === 'closed')
            .map((s) => {
              const mid = s.path[Math.floor(s.path.length / 2)] ?? s.path[0];
              const a = s.path[0];
              const b = s.path[s.path.length - 1];
              const pos: [number, number] = s.path.length === 2 ? [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2] : mid;
              return <Marker key={`x-${s.id}`} position={pos} icon={L.divIcon({ className: '', html: '<div class="mk-closure">✕ CLOSED</div>', iconSize: [70, 20], iconAnchor: [35, 10] })} eventHandlers={{ click: pick('segment', s.id) }} />;
            })}

        {layers.routes &&
          snap.segments
            .filter((s) => s.weatherExposed && s.status !== 'closed')
            .map((s) => (
              <Polyline key={`rain-${s.id}`} positions={s.path} interactive={false} pathOptions={{ color: '#0369a1', weight: 11, opacity: 0.18, lineCap: 'round' }} />
            ))}

        {highlights.map((h, idx) =>
          h.segmentIds.map((id) => {
            const s = segById.get(id);
            if (!s) return null;
            return (
              <Polyline
                key={`hl-${idx}-${id}`}
                positions={s.path}
                interactive={false}
                pathOptions={
                  h.tone === 'primary'
                    ? { color: '#0b7fab', weight: 9, opacity: 0.75, lineCap: 'round' }
                    : h.tone === 'alternative'
                      ? { color: '#6d28d9', weight: 8, opacity: 0.7, dashArray: '12 8', lineCap: 'round' }
                      : { color: '#b91c1c', weight: 10, opacity: 0.35 }
                }
              />
            );
          }),
        )}

        {layers.facilities &&
          snap.facilities.map((f) => (
            <Marker key={f.id} position={[f.lat, f.lng]} icon={facilityIcon(f, sel('facility', f.id))} eventHandlers={{ click: pick('facility', f.id) }} keyboard>
              <Tooltip direction="top" offset={[0, -14]}>
                {f.name}
                {f.status === 'closed' ? ' — UNAVAILABLE' : ''}
              </Tooltip>
            </Marker>
          ))}

        {layers.responders &&
          (snap.responders ?? [])
            .filter((r) => r.lat != null)
            .map((r) => (
              <Marker key={r.id} position={[r.lat!, r.lng!]} icon={responderIcon(r, sel('responder', r.id))} eventHandlers={{ click: pick('responder', r.id) }}>
                <Tooltip direction="top" offset={[0, -12]}>
                  {r.name} — {r.status.replace('_', ' ')}
                  <br />
                  <em>{r.locationSource}</em>
                </Tooltip>
              </Marker>
            ))}

        {layers.incidents &&
          visibleIncidents.map((i) => (
            <Marker key={i.id} position={[i.lat!, i.lng!]} icon={incidentIcon(i, sel('incident', i.id))} eventHandlers={{ click: pick('incident', i.id) }} zIndexOffset={1000} />
          ))}

        {clickMarker && <Marker position={clickMarker} icon={L.divIcon({ className: '', html: '<div class="mk-pick" aria-label="Selected location"></div>', iconSize: [22, 22], iconAnchor: [11, 22] })} />}
      </MapContainer>

      {tilesFailed && (
        <div className={`map-banner ${compact ? 'map-banner-sm' : ''}`} role="status">
          {compact ? 'Schematic view (tiles unavailable)' : 'Map tiles unavailable (offline or blocked). Showing the configured venue layout on a schematic background — all operational layers still work.'}
        </div>
      )}
      {!compact && (
        <div className="map-status" role="status">
          <span className={`ms-dot ${effective === 'schematic' ? 'ms-warn' : tileStats.ok > 0 ? 'ms-ok' : 'ms-wait'}`} />
          {effective === 'schematic' ? (tilesFailed ? 'Fallback grid — map tiles unavailable' : 'Schematic view (no tiles)') : tileStats.ok > 0 ? `${effective === 'topo' ? 'Terrain' : 'Street'} tiles loaded (may be cached)` : 'Loading map tiles…'}
          {live && (
            <>
              <span className="ms-sep">·</span>
              {live.fromCache ? <span className="ms-cached">Venue data: CACHED copy</span> : <span>Venue data {live.stale ? 'may be stale' : 'live'}{live.fetchedAt ? ` · ${fmtTime(new Date(live.fetchedAt).toISOString(), true)}` : ''}</span>}
            </>
          )}
        </div>
      )}
      {snap.event.venueIsFictional && !compact && <div className="map-fiction">Fictional demonstration layout — illustrative placement, not a real venue plan</div>}

      {showControls && (
        <div className="map-controls">
          <button className="map-ctl-btn" onClick={() => setPanelOpen((o) => !o)} aria-expanded={panelOpen} aria-label="Map layers and basemap">
            <Layers size={16} /> Layers
          </button>
          {panelOpen && (
            <div className="map-ctl-panel">
              <fieldset>
                <legend>Basemap</legend>
                {(['osm', 'topo', 'schematic'] as Basemap[]).map((b) => (
                  <label key={b}>
                    <input
                      type="radio"
                      name="basemap"
                      checked={basemap === b}
                      onChange={() => {
                        setBasemap(b);
                        safeStorage.set('hc.basemap', b);
                      }}
                    />
                    {b === 'schematic' ? 'Schematic (no tiles / offline)' : BASEMAPS[b].label}
                  </label>
                ))}
                {basemap === 'topo' && <p className="hint">Contours come from OpenTopoMap (SRTM). Context only — not used for routing or safety decisions.</p>}
              </fieldset>
              <fieldset>
                <legend>Layers</legend>
                {(
                  [
                    ['zones', 'Crowd zones & risk'],
                    ['routes', 'Route network & closures'],
                    ['facilities', 'Gates, exits, medical, assembly'],
                    ['incidents', 'Active incidents'],
                    ['closedIncidents', 'Include closed incidents'],
                    ['responders', 'Responders (configured/manual positions)'],
                    ['advisories', 'Advisory areas'],
                  ] as [keyof LayerState, string][]
                ).map(([k, label]) => (
                  <label key={k}>
                    <input type="checkbox" checked={layers[k]} onChange={(e) => setLayers((l) => ({ ...l, [k]: e.target.checked }))} />
                    {label}
                  </label>
                ))}
              </fieldset>
            </div>
          )}
        </div>
      )}
      {showLegend && <Legend hasRisk={!!snap.risks} defaultOpen={legendOpen} />}
    </div>
  );
}

function Legend({ hasRisk, defaultOpen }: { hasRisk: boolean; defaultOpen: boolean }) {
  const [open, setOpen] = useState(() => defaultOpen && (typeof window === 'undefined' || window.innerWidth > 900));
  return (
    <div className={`map-legend ${open ? 'open' : ''}`}>
      <button className="map-legend-toggle" onClick={() => setOpen((o) => !o)} aria-expanded={open}>
        Legend
      </button>
      {open && (
        <div className="map-legend-body">
          {hasRisk && (
            <div className="lg-group">
              {(['normal', 'watch', 'elevated', 'critical'] as RiskLevel[]).map((l) => (
                <div key={l} className="lg-row">
                  <i className="lg-zone" style={{ background: LEVEL_COLOR[l] }} /> Zone: {RISK_LABEL[l]}
                </div>
              ))}
              <div className="lg-row">
                <i className="lg-zone dashed" /> Dashed outline: data missing or stale
              </div>
            </div>
          )}
          <div className="lg-group">
            <div className="lg-row">
              <i className="lg-line" style={{ borderColor: '#2c5e4b' }} /> Walking path (open)
            </div>
            <div className="lg-row">
              <i className="lg-line thick" style={{ borderColor: '#1f4e79' }} /> Vehicle-capable (open)
            </div>
            <div className="lg-row">
              <i className="lg-line dashed" style={{ borderColor: '#a16207' }} /> Under review
            </div>
            <div className="lg-row">
              <i className="lg-line dotted" style={{ borderColor: '#b91c1c' }} /> Closed
            </div>
            <div className="lg-row">
              <i className="lg-line rain" /> Rain-exposed section (configured)
            </div>
            <div className="lg-row">
              <i className="lg-line thick" style={{ borderColor: '#0b7fab' }} /> Selected route
            </div>
            <div className="lg-row">
              <i className="lg-line dashed thick" style={{ borderColor: '#6d28d9' }} /> Alternative route
            </div>
          </div>
          <div className="lg-group lg-icons">
            <div className="lg-row"><span className="mk mk-gate mini"><span>G</span></span> Gate</div>
            <div className="lg-row"><span className="mk mk-exit mini"><span>EX</span></span> Exit</div>
            <div className="lg-row"><span className="mk mk-medical mini"><span>+</span></span> Medical post</div>
            <div className="lg-row"><span className="mk mk-assembly mini"><span>AP</span></span> Assembly point</div>
            <div className="lg-row"><span className="mk mk-control mini"><span>CR</span></span> Control room</div>
            <div className="lg-row"><span className="mk mk-handover mini"><span>H</span></span> Handover point</div>
            <div className="lg-row"><span className="mk-inc mini unverified"><span className="mk-inc-glyph">?</span></span> Unverified report</div>
            <div className="lg-row"><span className="mk-inc mini sev-high"><span className="mk-inc-glyph">!</span></span> Verified incident</div>
            <div className="lg-row"><span className="mk-resp mini"><span>RT</span></span> Responder (not live GPS)</div>
          </div>
        </div>
      )}
    </div>
  );
}

export function centroidOf(poly: [number, number][]) {
  return polygonCentroid(poly);
}
