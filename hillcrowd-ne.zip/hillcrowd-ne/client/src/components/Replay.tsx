import { useEffect, useMemo, useRef, useState } from 'react';
import { Pause, Play, RotateCcw } from 'lucide-react';
import { fmtTime } from '../lib/format';

export interface TimelineEntry {
  at: string;
  actor: string;
  role: string | null;
  action: string;
  entityType: string;
  details: Record<string, unknown>;
}

type Lane = 'report' | 'verify' | 'decision' | 'response' | 'alert';

const LANES: { key: Lane; label: string }[] = [
  { key: 'report', label: 'Reported' },
  { key: 'verify', label: 'Verified' },
  { key: 'decision', label: 'Decisions' },
  { key: 'response', label: 'Acknowledged & response' },
  { key: 'alert', label: 'Risk & escalation' },
];

const SKIP = new Set(['incident.assigned', 'incident.acknowledged', 'incident.in_progress', 'demo.seeded', 'incident.note']);

function laneOf(action: string): Lane | null {
  if (SKIP.has(action)) return null;
  if (action === 'incident.created' || action === 'exercise.inject') return 'report';
  if (['incident.under_review', 'incident.verified', 'incident.rejected', 'incident.merged', 'advisory.verified', 'advisory.rejected', 'incident.severity'].includes(action)) return 'verify';
  if (action.startsWith('assignment.') && action !== 'assignment.created' && action !== 'assignment.escalated') return 'response';
  if (action === 'incident.resolved') return 'response';
  if (action === 'risk.level_changed' || action.endsWith('.escalated')) return 'alert';
  return 'decision';
}

const LABEL: Record<string, string> = {
  'incident.created': 'Report received',
  'exercise.inject': 'Simulated event injected',
  'incident.under_review': 'Review started',
  'incident.verified': 'Verified',
  'incident.rejected': 'Rejected',
  'incident.merged': 'Reports merged',
  'incident.severity': 'Severity confirmed',
  'incident.closed': 'Closed by control room',
  'incident.reopened': 'Reopened',
  'incident.resolved': 'Marked resolved',
  'incident.escalated': 'Stage overdue — escalated',
  'assignment.created': 'Responder assigned',
  'assignment.acknowledged': 'Assignment acknowledged',
  'assignment.en_route': 'Responder en route',
  'assignment.on_scene': 'Responder on scene',
  'assignment.resolved': 'Responder resolved task',
  'assignment.declined': 'Assignment declined',
  'assignment.unable': 'Responder unable to respond',
  'assignment.escalated': 'Assignment escalated',
  'segment.closed': 'Route segment closed',
  'segment.under_review': 'Segment marked for review',
  'segment.open': 'Segment reopened',
  'facility.closed': 'Exit/facility unavailable',
  'facility.open': 'Exit/facility available',
  'advisory.created': 'Advisory entered',
  'risk.level_changed': 'Zone risk level changed',
  'playbook.step': 'Playbook step',
  'playbook.override': 'Playbook override',
  'stress_test.run': 'Stress test recorded',
  'responder.unavailable': 'Team marked unavailable',
  'responder.available': 'Team back on duty',
};

function describe(e: TimelineEntry): string {
  const d = e.details;
  const pick = (k: string) => (d[k] != null && typeof d[k] !== 'object' ? String(d[k]) : '');
  return [pick('ref') || pick('incident'), pick('title'), pick('name'), pick('responder'), d.to && d.from !== undefined ? `${pick('from') || '—'} → ${pick('to')}` : '', pick('reason') || pick('note')].filter(Boolean).join(' · ');
}

export function Replay({ timeline }: { timeline: TimelineEntry[] }) {
  const events = useMemo(
    () => timeline.map((e) => ({ ...e, lane: laneOf(e.action), t: Date.parse(e.at), simulated: e.details.simulated === true || /SIMULATED|demo|sample/i.test(JSON.stringify(e.details)) })).filter((e): e is typeof e & { lane: Lane } => e.lane !== null),
    [timeline],
  );
  const t0 = events[0]?.t ?? 0;
  const t1 = events.at(-1)?.t ?? t0;
  const span = Math.max(1000, t1 - t0);
  const [cursor, setCursor] = useState(1);
  const [playing, setPlaying] = useState(false);
  const raf = useRef<number | null>(null);
  const listRef = useRef<HTMLOListElement>(null);

  useEffect(() => {
    if (!playing) return;
    let last = performance.now();
    const step = (now: number) => {
      const dt = now - last;
      last = now;
      setCursor((c) => {
        const n = c + dt / 12000; // full replay ≈ 12 s regardless of real duration
        if (n >= 1) {
          setPlaying(false);
          return 1;
        }
        return n;
      });
      raf.current = requestAnimationFrame(step);
    };
    raf.current = requestAnimationFrame(step);
    return () => {
      if (raf.current) cancelAnimationFrame(raf.current);
    };
  }, [playing]);

  const cutoff = t0 + cursor * span;
  const shown = events.filter((e) => e.t <= cutoff);
  const current = shown.at(-1);

  useEffect(() => {
    listRef.current?.querySelector('.rp-current')?.scrollIntoView({ block: 'nearest' });
  }, [current?.at, current?.action]);

  if (!events.length) return <p className="muted">Nothing recorded yet.</p>;
  const pos = (t: number) => `${((t - t0) / span) * 100}%`;

  return (
    <div className="replay">
      <div className="rp-controls">
        <button
          className="btn btn-primary btn-sm"
          onClick={() => {
            if (cursor >= 1) setCursor(0);
            setPlaying((p) => !p);
          }}
        >
          {playing ? <Pause size={14} /> : <Play size={14} />} {playing ? 'Pause' : cursor >= 1 ? 'Replay from start' : 'Play'}
        </button>
        <button className="btn btn-sm btn-ghost" onClick={() => { setPlaying(false); setCursor(0); }}>
          <RotateCcw size={14} /> Start
        </button>
        <input type="range" min={0} max={1000} value={Math.round(cursor * 1000)} onChange={(e) => { setPlaying(false); setCursor(Number(e.target.value) / 1000); }} aria-label="Replay position" />
        <span className="rp-clock">{fmtTime(new Date(cutoff).toISOString(), true)}</span>
      </div>
      <div className="rp-lanes">
        {LANES.map((l) => (
          <div key={l.key} className="rp-lane">
            <div className="rp-lane-label">{l.label}</div>
            <div className="rp-track">
              {events
                .filter((e) => e.lane === l.key)
                .map((e, i) => (
                  <span key={i} className={`rp-dot rp-${l.key} ${e.t <= cutoff ? 'on' : ''} ${current === e ? 'cur' : ''}`} style={{ left: pos(e.t) }} title={`${fmtTime(e.at, true)} ${LABEL[e.action] ?? e.action}`} />
                ))}
              <span className="rp-cursor" style={{ left: `${cursor * 100}%` }} />
            </div>
          </div>
        ))}
      </div>
      {current && (
        <div className={`rp-now rp-${current.lane}`}>
          <span className="rp-now-time">{fmtTime(current.at, true)}</span>
          <strong>{LABEL[current.action] ?? current.action}</strong> — {current.actor}
          {current.role ? ` (${current.role})` : ''}
          {current.simulated && <span className="tag tag-sample">simulated</span>}
          <div className="small">{describe(current)}</div>
        </div>
      )}
      <ol className="rp-list" ref={listRef}>
        {events.map((e, i) => (
          <li key={i} className={`${e.t <= cutoff ? 'on' : ''} ${current === e ? 'rp-current' : ''}`} onClick={() => { setPlaying(false); setCursor((e.t - t0) / span); }}>
            <span className={`rp-chip rp-${e.lane}`} />
            <span className="tl-time">{fmtTime(e.at, true)}</span>
            <span>
              <strong>{LABEL[e.action] ?? e.action}</strong> · {e.actor} <span className="muted small">{describe(e)}</span>
            </span>
          </li>
        ))}
      </ol>
    </div>
  );
}
