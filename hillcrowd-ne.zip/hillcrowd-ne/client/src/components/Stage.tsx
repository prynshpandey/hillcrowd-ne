import type { StageStatus } from '@shared/accountability';
import { STAGE_LABEL } from '@shared/constants';
import { duration } from '../lib/format';

const short = (sec: number | null) => {
  if (sec == null) return '—';
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${String(s).padStart(2, '0')}`;
};

/** Compact clock for queues: current stage, time vs target, and who acts next. */
export function StageClock({ st }: { st: StageStatus | undefined }) {
  if (!st) return <span className="muted">—</span>;
  if (!st.current) return <span className="muted small">No open stage</span>;
  const pct = Math.min(100, (st.progress ?? 0) * 100);
  return (
    <div className={`stage-clock ${st.overdue ? 'late' : (st.progress ?? 0) > 0.75 ? 'near' : ''}`}>
      <div className="sc-top">
        <span className="sc-label">{STAGE_LABEL[st.current]}</span>
        <span className="sc-time">
          {short(st.elapsedSec)} / {short(st.targetSec)}
        </span>
      </div>
      <div className="sc-bar" aria-hidden>
        <i style={{ width: `${pct}%` }} />
      </div>
      <div className="sc-next">
        {st.overdue ? 'OVERDUE · ' : ''}Next: {st.nextActor}
      </div>
    </div>
  );
}

/** Full stage timeline for the incident detail. */
export function StageTimeline({ st }: { st: StageStatus }) {
  return (
    <div className="stage-timeline">
      <ol>
        {st.stages.map((x) => (
          <li key={x.key} className={`stl stl-${x.state} ${x.overdue ? 'late' : ''}`}>
            <div className="stl-dot" aria-hidden />
            <div className="stl-label">{x.label}</div>
            <div className="stl-time">
              {x.state === 'skipped' ? 'not reached' : x.durationSec != null ? duration(x.durationSec) : 'waiting'}
              <span className="stl-target"> / target {Math.round(x.targetSec / 60)} min</span>
            </div>
            {x.overdue && <div className="stl-flag">{x.state === 'current' ? 'overdue now' : 'over target'}</div>}
          </li>
        ))}
      </ol>
      {st.current && (
        <div className={`stl-next ${st.overdue ? 'late' : ''}`}>
          <strong>Waiting on {st.nextActor}:</strong> {st.nextAction}
        </div>
      )}
      <p className="tiny muted">Stage times show where time is being spent. A long stage can reflect terrain, a closed or restricted route, distance or a harder incident — review the context before drawing conclusions.</p>
    </div>
  );
}
