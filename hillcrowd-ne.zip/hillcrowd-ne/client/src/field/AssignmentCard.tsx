import { useState } from 'react';
import { MapPin } from 'lucide-react';
import { api } from '../lib/api';
import { useLive } from '../lib/live';
import { ASSIGNMENT_FLOW } from '@shared/workflow';
import { ASSIGNMENT_LABEL, CATEGORY_LABEL } from '@shared/constants';
import type { Assignment, AssignmentStatus } from '@shared/types';
import { Ago, ReasonDialog, SeverityTag, useAction } from '../components/ui';
import { VenueMap } from '../components/VenueMap';
import { metres } from '../lib/format';
import { t } from '../i18n';

const BUTTON: Partial<Record<AssignmentStatus, { label: string; tone: string; note: boolean }>> = {
  acknowledged: { label: t('responder.acknowledge'), tone: 'btn-primary btn-xl', note: false },
  declined: { label: t('responder.decline'), tone: 'btn-danger-ghost', note: true },
  en_route: { label: t('responder.enRoute'), tone: 'btn-primary btn-xl', note: false },
  on_scene: { label: t('responder.onScene'), tone: 'btn-primary btn-xl', note: false },
  unable: { label: t('responder.unable'), tone: 'btn-danger-ghost', note: true },
  resolved: { label: t('responder.resolved'), tone: 'btn-primary btn-xl', note: true },
};

export function AssignmentCard({ a }: { a: Assignment }) {
  const { snap, reload } = useLive();
  const run = useAction();
  const [dialog, setDialog] = useState<AssignmentStatus | null>(null);
  const [showMap, setShowMap] = useState(a.status === 'assigned' || a.status === 'acknowledged' || a.status === 'en_route');
  const inc = snap!.incidents.find((i) => i.id === a.incidentId);
  const zone = snap!.zones.find((z) => z.id === inc?.zoneId);
  const segName = (id: string) => snap!.segments.find((s) => s.id === id)?.name ?? id;
  const next = ASSIGNMENT_FLOW[a.status].filter((s) => s !== 'cancelled');
  const active = next.length > 0;
  const closedOnRoute = a.route?.found ? a.route.segmentIds.filter((id) => snap!.segments.find((s) => s.id === id)?.status === 'closed') : [];

  const go = (to: AssignmentStatus, note = '') => run(() => api.post(`/api/assignments/${a.id}/status`, { status: to, note }).then(reload), ASSIGNMENT_LABEL[to]);

  return (
    <article className={`task ${active ? 'task-active' : 'task-done'} task-${a.status}`}>
      <header className="task-head">
        <div>
          <div className="task-ref">
            {inc?.ref} · {inc ? CATEGORY_LABEL[inc.category] : 'Incident'}
          </div>
          <div className="task-status">
            {ASSIGNMENT_LABEL[a.status]} · assigned <Ago iso={a.assignedAt} />
          </div>
        </div>
        {inc && <SeverityTag severity={inc.confirmedSeverity ?? inc.severityEstimate} confirmed={!!inc.confirmedSeverity} />}
      </header>
      {a.escalatedAt && a.status === 'assigned' && <div className="task-warn">Control room is waiting for your acknowledgement.</div>}
      {inc && (
        <p className="task-desc">
          <MapPin size={14} /> <strong>{zone?.name ?? 'Location on map'}</strong> — {inc.description}
        </p>
      )}
      {a.note && <p className="task-instr">Instruction: {a.note}</p>}
      {a.route &&
        (a.route.found ? (
          <div className="task-route">
            <strong>Approved route:</strong> {metres(a.route.distanceM)} ({a.route.mode})
            <ol>
              {a.route.segmentIds.map((id) => (
                <li key={id}>{segName(id)}</li>
              ))}
            </ol>
            {closedOnRoute.length > 0 && <div className="task-warn">A segment on this route is now CLOSED: {closedOnRoute.map(segName).join(', ')}. Ask the control room for an alternative.</div>}
            {a.route.warnings.map((w, i) => (
              <div key={i} className="task-warn">
                {w}
              </div>
            ))}
          </div>
        ) : (
          <div className="task-warn">No approved route was found when this was assigned. Confirm access with the control room.</div>
        ))}
      {active && inc && (
        <>
          <button className="btn btn-ghost btn-sm" onClick={() => setShowMap((x) => !x)}>
            {showMap ? 'Hide map' : 'Show map'}
          </button>
          {showMap && (
            <div className="task-map">
              <VenueMap snap={snap!} height={220} compact showControls={false} showLegend={false} selection={{ type: 'incident', id: inc.id }} highlights={a.route?.found ? [{ segmentIds: a.route.segmentIds, tone: 'primary' }] : []} />
            </div>
          )}
        </>
      )}
      {active && (
        <div className="task-actions">
          {next.map((to) => {
            const b = BUTTON[to];
            if (!b) return null;
            return (
              <button key={to} className={`btn ${b.tone}`} onClick={() => (b.note ? setDialog(to) : go(to))}>
                {b.label}
              </button>
            );
          })}
        </div>
      )}
      {dialog && (
        <ReasonDialog
          title={BUTTON[dialog]!.label}
          required
          label={dialog === 'resolved' ? 'What was done? Outcome?' : 'Reason'}
          onSubmit={(n) => api.post(`/api/assignments/${a.id}/status`, { status: dialog, note: n }).then(reload)}
          onClose={() => setDialog(null)}
        />
      )}
    </article>
  );
}
