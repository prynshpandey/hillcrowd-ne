import { useEffect, useMemo, useState, useSyncExternalStore } from 'react';
import { AlertTriangle, CheckCircle2, Clock, CloudOff, CloudRain, Construction, DoorClosed, HeartPulse, MoreHorizontal, RadioTower, Search, Send, UploadCloud, Users, Wrench, XCircle } from 'lucide-react';
import { useSession } from '../lib/session';
import { useLive } from '../lib/live';
import { CATEGORIES, CATEGORY_LABEL, SEVERITIES, STATUS_LABEL } from '@shared/constants';
import { pointInPolygon } from '@shared/geo';
import type { IncidentCategory, Severity } from '@shared/types';
import { displayState, type OutboxItem } from '../lib/outbox';
import { outboxFor } from './outboxClient';
import { FieldShell } from './FieldShell';
import { AssignmentCard } from './AssignmentCard';
import { VenueMap } from '../components/VenueMap';
import { Notice, VerifyChip } from '../components/ui';
import { ago, fmtTime } from '../lib/format';
import { t } from '../i18n';

const QUICK: Partial<Record<IncidentCategory, string[]>> = {
  crowd_congestion: ['Queue backing up', 'Crowd pressure at barrier', 'People pushing', 'Bottleneck forming'],
  exit_blockage: ['Exit gate locked', 'Exit blocked by vehicles', 'Exit blocked by crowd', 'Gate jammed'],
  medical: ['Person collapsed', 'Injury — needs first aid', 'Breathing difficulty', 'Person fainted'],
  missing_person: ['Child separated from family', 'Adult reported missing'],
  infrastructure: ['Barrier damaged', 'Lighting failure', 'Power failure', 'Structure unstable'],
  route_obstruction: ['Debris on path', 'Vehicle blocking route', 'Water-logging on path', 'Path slippery'],
  weather: ['Heavy rain starting', 'Strong wind', 'Lightning nearby', 'Water collecting'],
  communication: ['Radio not working', 'No mobile signal', 'PA system down'],
  other: ['Needs control-room attention'],
};

const CAT_ICON: Record<IncidentCategory, typeof Users> = {
  crowd_congestion: Users,
  exit_blockage: DoorClosed,
  medical: HeartPulse,
  missing_person: Search,
  infrastructure: Wrench,
  route_obstruction: Construction,
  weather: CloudRain,
  communication: RadioTower,
  other: MoreHorizontal,
};

type Tab = 'report' | 'mine' | 'occupancy' | 'tasks';

function useOutbox(userId: string) {
  const box = outboxFor(userId);
  const items = useSyncExternalStore(
    (cb) => box.subscribe(cb),
    () => JSON.stringify(box.list()),
  );
  return { box, items: JSON.parse(items) as OutboxItem[] };
}

export default function FieldApp() {
  const { me, eventId } = useSession();
  const { snap, reload } = useLive();
  const { box, items } = useOutbox(me!.user.id);
  const [tab, setTab] = useState<Tab>('report');
  const [online, setOnline] = useState(typeof navigator === 'undefined' ? true : navigator.onLine);
  const myTasks = (snap?.assignments ?? []).filter((a) => ['assigned', 'acknowledged', 'en_route', 'on_scene'].includes(a.status));

  useEffect(() => {
    const flush = () => box.flush().then(() => reload());
    const on = () => {
      setOnline(true);
      flush();
    };
    const off = () => setOnline(false);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    flush();
    const i = setInterval(() => {
      if (box.pending().length) flush();
    }, 15_000);
    return () => {
      window.removeEventListener('online', on);
      window.removeEventListener('offline', off);
      clearInterval(i);
    };
  }, [box, reload]);

  const pending = items.filter((i) => i.state !== 'delivered').length;
  const lastSync = box.lastSyncAt();
  if (!snap) return <div className="splash">Loading venue…</div>;

  return (
    <FieldShell title={t('field.title')} extra={pending > 0 ? <span className="queue-pill" title="Saved on this device, not yet confirmed by the server"><CloudOff size={14} /> {pending}</span> : null}>
      <div className={`sync-strip ${pending ? 'has-pending' : ''}`}>
        <span>
          {t('field.lastSync')}: <strong>{lastSync ? `${fmtTime(lastSync, true)} (${ago(lastSync)})` : t('field.never')}</strong>
        </span>
        <span>{pending ? `${pending} ${t('field.notConfirmed')}` : t('field.allConfirmed')}</span>
      </div>
      {!online && <div className="field-offline">{t('field.offlineNote')}</div>}
      <nav className="field-tabs" role="tablist">
        <button role="tab" aria-selected={tab === 'report'} className={tab === 'report' ? 'on' : ''} onClick={() => setTab('report')}>
          {t('field.tab.report')}
        </button>
        <button role="tab" aria-selected={tab === 'mine'} className={tab === 'mine' ? 'on' : ''} onClick={() => setTab('mine')}>
          {t('field.tab.mine')} {pending > 0 && <span className="badge-dot">{pending}</span>}
        </button>
        <button role="tab" aria-selected={tab === 'occupancy'} className={tab === 'occupancy' ? 'on' : ''} onClick={() => setTab('occupancy')}>
          {t('field.tab.occupancy')}
        </button>
        {(snap.responders ?? []).length > 0 && (
          <button role="tab" aria-selected={tab === 'tasks'} className={tab === 'tasks' ? 'on' : ''} onClick={() => setTab('tasks')}>
            My tasks {myTasks.length > 0 && <span className="badge-dot">{myTasks.length}</span>}
          </button>
        )}
      </nav>
      <main className="field-main">
        {tab === 'report' && <ReportForm onSaved={() => setTab('mine')} eventId={eventId!} />}
        {tab === 'mine' && <MyReports />}
        {tab === 'occupancy' && <OccupancyForm eventId={eventId!} />}
        {tab === 'tasks' && (
          <div className="tasks">
            {(snap.assignments ?? []).length === 0 && <p className="muted">No tasks assigned to your team.</p>}
            {[...(snap.assignments ?? [])]
              .sort((a, b) => Number(myTasks.includes(b)) - Number(myTasks.includes(a)) || b.assignedAt.localeCompare(a.assignedAt))
              .map((a) => (
                <AssignmentCard key={a.id} a={a} />
              ))}
          </div>
        )}
      </main>
    </FieldShell>
  );
}

function ReportForm({ eventId, onSaved }: { eventId: string; onSaved: () => void }) {
  const { me } = useSession();
  const { snap } = useLive();
  const { box } = useOutbox(me!.user.id);
  const [category, setCategory] = useState<IncidentCategory | null>(null);
  const [zoneId, setZoneId] = useState<string | null>(null);
  const [point, setPoint] = useState<[number, number] | null>(null);
  const [useMap, setUseMap] = useState(false);
  const [severity, setSeverity] = useState<Severity>('moderate');
  const [urgent, setUrgent] = useState(false);
  const [desc, setDesc] = useState('');
  const [evidence, setEvidence] = useState('');
  const [err, setErr] = useState<string | null>(null);
  const s = snap!;
  const pointZone = useMemo(() => (point ? s.zones.find((z) => pointInPolygon(point, z.polygon)) : null), [point, s.zones]);

  const submit = () => {
    if (!category) return setErr('Choose what is happening.');
    if (!zoneId && !point) return setErr('Choose a zone or tap the map.');
    if (desc.trim().length < 3) return setErr('Add a short description (or tap a quick phrase).');
    box.add({
      kind: 'incident',
      eventId,
      userId: me!.user.id,
      payload: {
        category,
        zoneId: point ? pointZone?.id ?? null : zoneId,
        lat: point?.[0] ?? null,
        lng: point?.[1] ?? null,
        description: desc.trim(),
        severityEstimate: severity,
        urgent,
        attachmentNote: evidence.trim() || null,
      },
    });
    void box.flush();
    setCategory(null);
    setZoneId(null);
    setPoint(null);
    setDesc('');
    setEvidence('');
    setUrgent(false);
    setSeverity('moderate');
    setErr(null);
    onSaved();
  };

  return (
    <form
      className="report-form"
      onSubmit={(e) => {
        e.preventDefault();
        submit();
      }}
    >
      <section>
        <h2>1. {t('field.step.category')}</h2>
        <div className="cat-grid">
          {CATEGORIES.map((c) => (
            <button type="button" key={c.key} className={`cat-btn ${category === c.key ? 'on' : ''}`} aria-pressed={category === c.key} onClick={() => setCategory(c.key)}>
              {(() => {
                const Icon = CAT_ICON[c.key];
                return <Icon className="cat-ico" size={26} aria-hidden />;
              })()}
              {c.short}
            </button>
          ))}
        </div>
      </section>
      <section>
        <h2>2. {t('field.step.location')}</h2>
        <div className="seg seg-full">
          <button type="button" className={!useMap ? 'on' : ''} onClick={() => setUseMap(false)}>
            {t('field.useZone')}
          </button>
          <button type="button" className={useMap ? 'on' : ''} onClick={() => setUseMap(true)}>
            {t('field.useMap')}
          </button>
        </div>
        {!useMap ? (
          <div className="zone-btns">
            {s.zones.map((z) => (
              <button
                type="button"
                key={z.id}
                className={`zone-btn ${zoneId === z.id && !point ? 'on' : ''}`}
                aria-pressed={zoneId === z.id && !point}
                onClick={() => {
                  setZoneId(z.id);
                  setPoint(null);
                }}
              >
                {z.name}
              </button>
            ))}
          </div>
        ) : (
          <div className="field-map">
            <VenueMap snap={s} height={260} compact showControls={false} showLegend={false} onMapClick={(lat, lng) => setPoint([lat, lng])} clickMarker={point} initialLayers={{ incidents: false, responders: false }} />
            <p className="small">{point ? `Pinned in ${pointZone?.name ?? 'an area outside configured zones'}` : 'Tap the map where it is happening.'}</p>
          </div>
        )}
      </section>
      <section>
        <h2>3. {t('field.step.details')}</h2>
        <div className="field-label">{t('field.severity')}</div>
        <div className="seg seg-full sev-seg">
          {SEVERITIES.map((x) => (
            <button type="button" key={x} className={`${severity === x ? 'on' : ''} sev-opt-${x}`} aria-pressed={severity === x} onClick={() => setSeverity(x)}>
              {t(`severity.${x}`)}
            </button>
          ))}
        </div>
        {category && QUICK[category] && (
          <div className="quick">
            {QUICK[category]!.map((q) => (
              <button type="button" key={q} className="quick-chip" onClick={() => setDesc((d) => (d ? `${d}. ${q}` : q))}>
                + {q}
              </button>
            ))}
          </div>
        )}
        <label className="field">
          <span>{t('field.description')}</span>
          <textarea rows={3} value={desc} onChange={(e) => setDesc(e.target.value)} placeholder={t('field.description.placeholder')} maxLength={1000} />
        </label>
        <label className="field">
          <span>
            Evidence note <em className="opt">optional — e.g. “photo shown to supervisor”. Image upload is not supported in this prototype.</em>
          </span>
          <input value={evidence} onChange={(e) => setEvidence(e.target.value)} maxLength={300} />
        </label>
        <label className="urgent-toggle">
          <input type="checkbox" checked={urgent} onChange={(e) => setUrgent(e.target.checked)} />
          <span>
            <AlertTriangle size={16} /> {t('field.urgent')}
          </span>
        </label>
      </section>
      {err && <Notice tone="danger">{err}</Notice>}
      <button className="btn btn-primary btn-xl btn-block">
        <Send size={18} /> {navigator.onLine ? t('field.submit') : t('field.submit.offline')}
      </button>
      <p className="tiny muted">Your report goes to the control room as UNVERIFIED until a coordinator reviews it. Do not include unnecessary personal details.</p>
    </form>
  );
}

function OutboxState({ item }: { item: OutboxItem }) {
  const ds = displayState(item);
  const map = {
    saved: { icon: CloudOff, label: t('field.state.saved'), cls: 'ob-queued' },
    syncing: { icon: UploadCloud, label: t('field.sending'), cls: 'ob-sending' },
    waiting: { icon: Clock, label: t('field.state.waiting'), cls: 'ob-queued' },
    confirmed: { icon: CheckCircle2, label: t('field.state.confirmed'), cls: 'ob-delivered' },
    action: { icon: XCircle, label: t('field.state.action'), cls: 'ob-rejected' },
  }[ds];
  return (
    <span className={`ob ${map.cls}`}>
      <map.icon size={14} aria-hidden /> {map.label}
      {ds !== 'confirmed' && item.attempts > 0 && <em className="ob-attempts"> · {item.attempts} attempt{item.attempts > 1 ? 's' : ''}</em>}
    </span>
  );
}

function MyReports() {
  const { me } = useSession();
  const { snap, reload } = useLive();
  const { box, items } = useOutbox(me!.user.id);
  const s = snap!;
  const serverById = new Map(s.incidents.map((i) => [i.id, i]));
  const outboxIncidents = items.filter((i) => i.kind === 'incident');
  const deliveredIds = new Set(outboxIncidents.map((i) => i.serverId).filter(Boolean));
  const serverOnly = s.incidents.filter((i) => i.reporterId === me!.user.id && !deliveredIds.has(i.id));
  const occ = items.filter((i) => i.kind === 'occupancy').slice(0, 5);

  return (
    <div className="my-reports">
      {items.some((i) => i.state === 'failed' || i.state === 'queued') && (
        <button className="btn btn-block" onClick={() => box.flush().then(reload)}>
          {t('field.retry')}
        </button>
      )}
      {outboxIncidents.length === 0 && serverOnly.length === 0 && <p className="muted">No reports yet.</p>}
      {outboxIncidents.map((o) => {
        const srv = o.serverId ? serverById.get(o.serverId) : undefined;
        const p = o.payload as { category: IncidentCategory; description: string; zoneId: string | null; urgent: boolean };
        return (
          <article key={o.id} className={`rep rep-${o.state}`}>
            <header>
              <strong>{srv?.ref ?? o.serverRef ?? 'Not yet numbered'}</strong> · {CATEGORY_LABEL[p.category]}
              {p.urgent && <span className="tag tag-critical">URGENT</span>}
            </header>
            <p>{p.description}</p>
            <OutboxState item={o} />
            {o.lastError && o.state !== 'delivered' && <div className="tiny text-danger">{o.lastError}</div>}
            {displayState(o) === 'action' && (
              <div className="ob-help">
                {o.state === 'rejected' ? 'The server refused this report. Fix the details and send a new report, or pass it on by radio.' : 'Still not delivered after several attempts. Check your signal and sign-in, tap Retry now, or pass it on by radio.'}
              </div>
            )}
            <dl className="rep-times">
              <dt>{t('field.createdLocal')}</dt>
              <dd>{fmtTime(o.createdLocalAt, true)}</dd>
              <dt>{t('field.receivedServer')}</dt>
              <dd>{o.serverReceivedAt ? fmtTime(o.serverReceivedAt, true) : <em>{t('field.notDelivered')}</em>}</dd>
            </dl>
            {srv && (
              <div className="rep-status">
                Control room: {STATUS_LABEL[srv.status]} <VerifyChip status={srv.status} />
              </div>
            )}
            {o.state === 'rejected' && (
              <button className="btn btn-sm btn-ghost" onClick={() => box.discard(o.id)}>
                Remove from device
              </button>
            )}
          </article>
        );
      })}
      {serverOnly.map((i) => (
        <article key={i.id} className="rep rep-delivered">
          <header>
            <strong>{i.ref}</strong> · {CATEGORY_LABEL[i.category]}
          </header>
          <p>{i.description}</p>
          <dl className="rep-times">
            <dt>{t('field.createdLocal')}</dt>
            <dd>{fmtTime(i.createdLocalAt, true)}</dd>
            <dt>{t('field.receivedServer')}</dt>
            <dd>{fmtTime(i.receivedAt, true)}</dd>
          </dl>
          <div className="rep-status">
            Control room: {STATUS_LABEL[i.status]} <VerifyChip status={i.status} />
          </div>
        </article>
      ))}
      {occ.length > 0 && (
        <>
          <h3>Recent crowd estimates</h3>
          {occ.map((o) => (
            <div key={o.id} className="occ-item">
              {s.zones.find((z) => z.id === (o.payload as { zoneId: string }).zoneId)?.name}: {(o.payload as { value: number }).value} people · <OutboxState item={o} />
            </div>
          ))}
        </>
      )}
    </div>
  );
}

function OccupancyForm({ eventId }: { eventId: string }) {
  const { me } = useSession();
  const { snap } = useLive();
  const { box } = useOutbox(me!.user.id);
  const [zoneId, setZoneId] = useState(snap!.zones[0]?.id ?? '');
  const [value, setValue] = useState('');
  const [source, setSource] = useState('Steward visual estimate');
  const [msg, setMsg] = useState<string | null>(null);
  const zone = snap!.zones.find((z) => z.id === zoneId);
  return (
    <form
      className="report-form"
      onSubmit={(e) => {
        e.preventDefault();
        const v = Number(value);
        if (!Number.isInteger(v) || v < 0) return setMsg('Enter a whole number.');
        box.add({ kind: 'occupancy', eventId, userId: me!.user.id, payload: { zoneId, value: v, source } });
        void box.flush();
        setValue('');
        setMsg('Estimate saved — it will show as delivered once the server receives it (see My reports).');
      }}
    >
      <label className="field">
        <span>{t('field.occupancy.zone')}</span>
        <select value={zoneId} onChange={(e) => setZoneId(e.target.value)}>
          {snap!.zones.map((z) => (
            <option key={z.id} value={z.id}>
              {z.name}
            </option>
          ))}
        </select>
      </label>
      {zone?.capacity && <p className="small muted">Configured capacity: {zone.capacity.toLocaleString('en-IN')}</p>}
      <label className="field">
        <span>{t('field.occupancy.value')}</span>
        <input type="number" inputMode="numeric" min={0} value={value} onChange={(e) => setValue(e.target.value)} required className="big-input" />
      </label>
      <label className="field">
        <span>{t('field.occupancy.source')}</span>
        <select value={source} onChange={(e) => setSource(e.target.value)}>
          <option>Steward visual estimate</option>
          <option>Hand counter / clicker count</option>
          <option>Gate entry count</option>
        </select>
      </label>
      {msg && <Notice tone="ok">{msg}</Notice>}
      <button className="btn btn-primary btn-xl btn-block">{t('field.occupancy.submit')}</button>
    </form>
  );
}
