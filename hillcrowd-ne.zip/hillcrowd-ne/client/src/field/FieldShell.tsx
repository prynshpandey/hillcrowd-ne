import type { ReactNode } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { LogOut, MonitorSmartphone } from 'lucide-react';
import { useSession } from '../lib/session';
import { useLive } from '../lib/live';
import { ConnectionPill } from '../App';
import { DemoBadge } from '../components/ui';
import { can } from '@shared/permissions';
import { t } from '../i18n';

export function FieldShell({ title, children, extra }: { title: string; children: ReactNode; extra?: ReactNode }) {
  const { me, logout } = useSession();
  const { snap } = useLive();
  const nav = useNavigate();
  return (
    <div className="field-app">
      <header className="field-top">
        <div className="field-brand">
          <svg viewBox="0 0 64 64" width="26" height="26" aria-hidden>
            <path d="M4 50 L22 24 L31 36 L41 18 L60 50 Z" fill="#2f6b52" />
            <path d="M4 50 L22 24 L31 36 L41 18 L60 50" fill="none" stroke="#e8efe9" strokeWidth="3.5" strokeLinejoin="round" />
            <circle cx="41" cy="18" r="4.5" fill="#f2b84b" />
          </svg>
          <div>
            <div className="field-title">{title}</div>
            <div className="field-event">{snap?.event.name ?? '…'}</div>
          </div>
        </div>
        <div className="field-top-right">
          {snap?.event.isDemo && <DemoBadge label="DEMO" />}
          <ConnectionPill />
          {extra}
          {can(me?.user.role, 'event.viewOps') && (
            <Link to="/overview" className="icon-btn" aria-label="Control room view" title="Control room view">
              <MonitorSmartphone size={18} />
            </Link>
          )}
          <button
            className="icon-btn"
            aria-label={t('common.signOut')}
            title={`${t('common.signOut')} (${me?.user.displayName})`}
            onClick={async () => {
              await logout();
              nav('/login');
            }}
          >
            <LogOut size={18} />
          </button>
        </div>
      </header>
      <div className="field-user">
        Signed in as <strong>{me?.user.displayName}</strong>
      </div>
      {children}
    </div>
  );
}
