import { useLive } from '../lib/live';
import { FieldShell } from './FieldShell';
import { AssignmentCard } from './AssignmentCard';
import { t } from '../i18n';

export default function ResponderApp() {
  const { snap, error } = useLive();
  if (!snap) return <div className="splash">{error ? `Could not load: ${error}` : 'Loading…'}</div>;
  const all = [...(snap.assignments ?? [])].sort((a, b) => b.assignedAt.localeCompare(a.assignedAt));
  const active = all.filter((a) => ['assigned', 'acknowledged', 'en_route', 'on_scene'].includes(a.status));
  const done = all.filter((a) => !active.includes(a));
  const me = snap.responders?.[0];
  return (
    <FieldShell title={t('responder.title')}>
      <main className="field-main">
        {me && (
          <div className="resp-self">
            <strong>{me.name}</strong> · {me.modes.join(' + ')} · status: {me.status.replace('_', ' ')}
          </div>
        )}
        {active.length === 0 && <p className="muted center">No active assignments. New tasks appear here automatically.</p>}
        {active.map((a) => (
          <AssignmentCard key={a.id} a={a} />
        ))}
        {done.length > 0 && (
          <details className="done-tasks">
            <summary>Completed / closed ({done.length})</summary>
            {done.map((a) => (
              <AssignmentCard key={a.id} a={a} />
            ))}
          </details>
        )}
        <p className="tiny muted center">This app records your status for the control room. It does not share live GPS.</p>
      </main>
    </FieldShell>
  );
}
