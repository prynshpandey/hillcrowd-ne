import { api, ApiError } from '../lib/api';
import { safeStorage } from '../lib/storage';
import { Outbox, SendError, type OutboxItem, type SendResult } from '../lib/outbox';

async function send(item: OutboxItem): Promise<SendResult> {
  try {
    if (item.kind === 'incident') {
      const r = await api.post<{ incident: { id: string; ref: string; receivedAt: string }; duplicateSubmission: boolean }>(`/api/events/${item.eventId}/incidents`, {
        ...item.payload,
        clientId: item.id,
        createdLocalAt: item.createdLocalAt,
      });
      return { id: r.incident.id, ref: r.incident.ref, receivedAt: r.incident.receivedAt, duplicateSubmission: r.duplicateSubmission };
    }
    const r = await api.post<{ id: string; receivedAt: string; duplicateSubmission: boolean }>(`/api/events/${item.eventId}/occupancy`, {
      ...item.payload,
      clientId: item.id,
      observedAt: item.createdLocalAt,
    });
    return { id: r.id, ref: null, receivedAt: r.receivedAt, duplicateSubmission: r.duplicateSubmission };
  } catch (e) {
    if (e instanceof ApiError) {
      if (e.network || e.status === 0 || e.status >= 500 || e.status === 429) throw new SendError(e.message, false);
      if (e.status === 401) throw new SendError('Signed out — sign in again to send.', false);
      throw new SendError(e.message, true);
    }
    throw new SendError('Unexpected error', false);
  }
}

const boxes = new Map<string, Outbox>();
export function outboxFor(userId: string): Outbox {
  if (!boxes.has(userId)) boxes.set(userId, new Outbox(safeStorage, send, `hc.outbox.v1.${userId}`));
  return boxes.get(userId)!;
}
