import en from './en.json';
import { safeStorage } from '../lib/storage';

/**
 * Minimal i18n. Strings live in JSON files keyed by language code. To add Khasi (kha), Garo (grt)
 * or another language, add `<code>.json` with the same keys, register it in LOCALES, and have the
 * translation reviewed by a competent speaker. Missing keys fall back to English.
 * No machine-generated or unverified translations are shipped.
 */
type Dict = Record<string, string>;
export const LOCALES: Record<string, { label: string; dict: Dict; verified: boolean }> = {
  en: { label: 'English', dict: en as Dict, verified: true },
};

let current = safeStorage.get('hc.lang') ?? 'en';
if (!LOCALES[current]) current = 'en';

export function setLanguage(code: string) {
  if (LOCALES[code]) {
    current = code;
    safeStorage.set('hc.lang', code);
  }
}
export const language = () => current;

export function t(key: string, vars: Record<string, string | number> = {}): string {
  const raw = LOCALES[current]?.dict[key] ?? (en as Dict)[key] ?? key;
  return raw.replace(/\{(\w+)\}/g, (_, k) => String(vars[k] ?? `{${k}}`));
}
