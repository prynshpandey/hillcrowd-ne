import type {
  Advisory,
  Assignment,
  ChecklistItem,
  EventRecord,
  Facility,
  Incident,
  IncidentAction,
  NamedRoute,
  NamedRouteValidity,
  Notification,
  Playbook,
  Responder,
  RouteNode,
  RouteSegment,
  User,
  Zone,
  ZoneRisk,
} from '@shared/types';
import type { StageStatus } from '@shared/accountability';
import type { Gap, ResilienceReport, Scenario } from '@shared/resilience';

export interface Readiness {
  total: number;
  notAssessed: number;
  noIssue: number;
  issuesIdentified: number;
  mitigationPlanned: number;
  mitigationVerified: number;
  outstanding: { id: string; label: string; status: string; note: string }[];
  statement: string;
}

export interface ClosureRow {
  id: string;
  segment_id: string;
  segment_name: string;
  status: string;
  reason: string;
  source: string;
  created_at: string;
  lifted_at: string | null;
}

export interface Snapshot {
  serverTime: string;
  demoMode: boolean;
  view: 'ops' | 'responder' | 'steward';
  event: EventRecord;
  zones: Zone[];
  facilities: Facility[];
  nodes: RouteNode[];
  segments: RouteSegment[];
  advisories: Advisory[];
  incidents: Incident[];
  risks?: ZoneRisk[];
  assignments?: Assignment[];
  responders?: Responder[];
  namedRoutes?: NamedRoute[];
  routeValidity?: NamedRouteValidity[];
  actions?: IncidentAction[];
  playbooks?: Playbook[];
  checklist?: ChecklistItem[];
  readiness?: Readiness;
  notifications?: Notification[];
  closures?: ClosureRow[];
  stages?: Record<string, StageStatus>;
  access?: ResilienceReport;
  stressTests?: StressTestRun[];
}

export interface StressTestRun {
  id: string;
  name: string;
  scenario: Scenario;
  summary: ResilienceReport['summary'];
  gaps: Gap[];
  runBy: string | null;
  runAt: string;
}

export interface Me {
  user: User;
  events: { id: string; name: string; state: string; district: string; isDemo: boolean; startsAt: string }[];
  demoMode: boolean;
}
