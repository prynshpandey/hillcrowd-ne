import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import { api, ApiError } from './api';
import { safeStorage } from './storage';
import type { Snapshot } from './types';

export type ConnState = 'live' | 'reconnecting' | 'offline';

interface LiveValue {
  snap: Snapshot | null;
  error: string | null;
  conn: ConnState;
  /** Wall-clock time of the last successful fetch. */
  fetchedAt: number | null;
  /** True when shown data came from the local cache or is older than the freshness limit. */
  stale: boolean;
  fromCache: boolean;
  reload: () => Promise<void>;
}

const LiveCtx = createContext<LiveValue | null>(null);
const STALE_AFTER_MS = 45_000;

export function LiveProvider({ eventId, userId, children }: { eventId: string; userId: string; children: ReactNode }) {
  const cacheKey = `hc.snap.${userId}.${eventId}`;
  const [snap, setSnap] = useState<Snapshot | null>(() => {
    const raw = safeStorage.get(cacheKey);
    try {
      return raw ? (JSON.parse(raw) as Snapshot) : null;
    } catch {
      return null;
    }
  });
  const [fromCache, setFromCache] = useState(!!snap);
  const [error, setError] = useState<string | null>(null);
  const [conn, setConn] = useState<ConnState>(typeof navigator !== 'undefined' && !navigator.onLine ? 'offline' : 'reconnecting');
  const [fetchedAt, setFetchedAt] = useState<number | null>(null);
  const [, tick] = useState(0);
  const inflight = useRef<Promise<void> | null>(null);
  const again = useRef(false);

  const reload = useCallback(async () => {
    if (inflight.current) {
      again.current = true;
      return inflight.current;
    }
    inflight.current = (async () => {
      try {
        const s = await api.get<Snapshot>(`/api/events/${eventId}/snapshot`);
        setSnap(s);
        setFromCache(false);
        setFetchedAt(Date.now());
        setError(null);
        // Cache reference data for low-connectivity use; marked stale when shown from cache.
        safeStorage.set(cacheKey, JSON.stringify(s));
      } catch (e) {
        setError(e instanceof Error ? e.message : 'Failed to load');
        if (e instanceof ApiError && e.network) setConn('offline');
      } finally {
        inflight.current = null;
        if (again.current) {
          again.current = false;
          void reload();
        }
      }
    })();
    return inflight.current;
  }, [eventId, cacheKey]);

  // Server-sent events for change notifications; fall back to polling.
  useEffect(() => {
    let es: EventSource | null = null;
    let poll: ReturnType<typeof setInterval> | null = null;
    let closed = false;
    const connect = () => {
      if (closed) return;
      es = new EventSource(`/api/stream?eventId=${encodeURIComponent(eventId)}`);
      es.addEventListener('hello', () => {
        setConn('live');
        void reload();
      });
      es.addEventListener('change', () => void reload());
      es.onerror = () => {
        setConn(navigator.onLine ? 'reconnecting' : 'offline');
      };
    };
    connect();
    void reload();
    poll = setInterval(() => void reload(), 20_000);
    const online = () => {
      setConn('reconnecting');
      es?.close();
      connect();
      void reload();
    };
    const offline = () => setConn('offline');
    window.addEventListener('online', online);
    window.addEventListener('offline', offline);
    const t = setInterval(() => tick((x) => x + 1), 5000);
    return () => {
      closed = true;
      es?.close();
      if (poll) clearInterval(poll);
      clearInterval(t);
      window.removeEventListener('online', online);
      window.removeEventListener('offline', offline);
    };
  }, [eventId, reload]);

  const stale = fromCache || !fetchedAt || Date.now() - fetchedAt > STALE_AFTER_MS;
  return <LiveCtx.Provider value={{ snap, error, conn, fetchedAt, stale, fromCache, reload }}>{children}</LiveCtx.Provider>;
}

export function useLive() {
  const v = useContext(LiveCtx);
  if (!v) throw new Error('useLive outside provider');
  return v;
}

/** Same as useLive, but returns null outside a LiveProvider. */
export function useLiveOptional() {
  return useContext(LiveCtx);
}
