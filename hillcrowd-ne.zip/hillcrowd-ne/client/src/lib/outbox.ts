/**
 * Offline outbox for field reports.
 *
 * - Every item gets a stable client ID before it is sent; the server treats a repeated ID as the
 *   same submission, so retries after a dropped connection cannot create duplicate incidents.
 * - An item is only "delivered" once the server has answered with its receipt time.
 * - Local creation time and server receipt time are kept separately.
 */
export type OutboxState = 'queued' | 'sending' | 'delivered' | 'failed' | 'rejected';

export interface OutboxItem {
  id: string;
  kind: 'incident' | 'occupancy';
  eventId: string;
  userId: string;
  payload: Record<string, unknown>;
  createdLocalAt: string;
  state: OutboxState;
  attempts: number;
  lastError: string | null;
  lastAttemptAt: string | null;
  serverReceivedAt: string | null;
  serverRef: string | null;
  serverId: string | null;
  duplicateSubmission: boolean;
}

export interface KV {
  get(key: string): string | null;
  set(key: string, value: string): boolean;
}

export interface SendResult {
  receivedAt: string;
  ref: string | null;
  id: string;
  duplicateSubmission: boolean;
}

export class SendError extends Error {
  /** permanent = the server rejected the content (e.g. validation); retrying will not help. */
  constructor(message: string, public permanent: boolean) {
    super(message);
  }
}

export function newClientId(): string {
  const c = globalThis.crypto as Crypto | undefined;
  if (c?.randomUUID) return `c-${c.randomUUID()}`;
  return `c-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
}

export class Outbox {
  private flushing: Promise<void> | null = null;
  private listeners = new Set<() => void>();

  constructor(private kv: KV, private send: (item: OutboxItem) => Promise<SendResult>, private key = 'hc.outbox.v1', private now = () => new Date()) {}

  list(): OutboxItem[] {
    try {
      const raw = this.kv.get(this.key);
      return raw ? (JSON.parse(raw) as OutboxItem[]) : [];
    } catch {
      return [];
    }
  }

  private save(items: OutboxItem[]) {
    this.kv.set(this.key, JSON.stringify(items));
    for (const l of this.listeners) l();
  }

  subscribe(fn: () => void) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private patch(id: string, p: Partial<OutboxItem>) {
    this.save(this.list().map((i) => (i.id === id ? { ...i, ...p } : i)));
  }

  add(input: { kind: OutboxItem['kind']; eventId: string; userId: string; payload: Record<string, unknown>; id?: string }): OutboxItem {
    const item: OutboxItem = {
      id: input.id ?? newClientId(),
      kind: input.kind,
      eventId: input.eventId,
      userId: input.userId,
      payload: input.payload,
      createdLocalAt: this.now().toISOString(),
      state: 'queued',
      attempts: 0,
      lastError: null,
      lastAttemptAt: null,
      serverReceivedAt: null,
      serverRef: null,
      serverId: null,
      duplicateSubmission: false,
    };
    this.save([item, ...this.list()]);
    return item;
  }

  /** Time of the last item confirmed by the server, or null. */
  lastSyncAt(): string | null {
    return this.kv.get(`${this.key}.lastSync`);
  }

  pending(): OutboxItem[] {
    return this.list().filter((i) => i.state === 'queued' || i.state === 'failed' || i.state === 'sending');
  }

  /** Send all pending items once. Concurrent calls share the same run, so an item is never sent twice in parallel. */
  flush(): Promise<void> {
    if (this.flushing) return this.flushing;
    const run = async () => {
      // Oldest first, preserving the order reports were made.
      for (const item of this.pending().reverse()) {
        this.patch(item.id, { state: 'sending', attempts: item.attempts + 1, lastAttemptAt: this.now().toISOString() });
        try {
          const r = await this.send(item);
          this.kv.set(`${this.key}.lastSync`, this.now().toISOString());
          this.patch(item.id, { state: 'delivered', serverReceivedAt: r.receivedAt, serverRef: r.ref, serverId: r.id, duplicateSubmission: r.duplicateSubmission, lastError: null });
        } catch (e) {
          const err = e instanceof SendError ? e : new SendError(e instanceof Error ? e.message : 'Unknown error', false);
          this.patch(item.id, { state: err.permanent ? 'rejected' : 'failed', lastError: err.message });
        }
      }
    };
    // Clear the in-flight marker only after it has been stored. (Clearing it inside `run` would
    // happen synchronously for an empty queue, before assignment, leaving a stale promise forever.)
    const p = run().finally(() => {
      if (this.flushing === p) this.flushing = null;
    });
    this.flushing = p;
    return p;
  }

  /** Remove delivered items older than the cutoff (keeps the local history short). */
  prune(maxDelivered = 30) {
    const items = this.list();
    const delivered = items.filter((i) => i.state === 'delivered');
    if (delivered.length <= maxDelivered) return;
    const drop = new Set(delivered.slice(maxDelivered).map((i) => i.id));
    this.save(items.filter((i) => !drop.has(i.id)));
  }

  discard(id: string) {
    this.save(this.list().filter((i) => !(i.id === id && i.state === 'rejected')));
  }
}

/** After this many failed attempts an item needs the user's attention (it still retries). */
export const ATTENTION_AFTER_ATTEMPTS = 3;

export type DisplayState = 'saved' | 'syncing' | 'waiting' | 'confirmed' | 'action';

/** The four user-facing states. Only 'confirmed' means the control room has the report. */
export function displayState(i: OutboxItem): DisplayState {
  if (i.state === 'delivered') return 'confirmed';
  if (i.state === 'sending') return 'syncing';
  if (i.state === 'rejected') return 'action';
  if (i.state === 'failed') return i.attempts >= ATTENTION_AFTER_ATTEMPTS ? 'action' : 'waiting';
  return 'saved';
}
