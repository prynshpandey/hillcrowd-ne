import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { api, ApiError } from './api';
import { safeStorage } from './storage';
import type { Me } from './types';
import type { User } from '@shared/types';

interface SessionValue {
  me: Me | null;
  loading: boolean;
  error: string | null;
  eventId: string | null;
  setEventId: (id: string) => void;
  login: (username: string, password: string) => Promise<User>;
  logout: () => Promise<void>;
  refresh: () => Promise<void>;
}

const SessionCtx = createContext<SessionValue | null>(null);

export function SessionProvider({ children }: { children: ReactNode }) {
  const [me, setMe] = useState<Me | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [eventId, setEventIdState] = useState<string | null>(safeStorage.get('hc.event'));

  const refresh = useCallback(async () => {
    try {
      const m = await api.get<Me>('/api/auth/me');
      setMe(m);
      setError(null);
      setEventIdState((cur) => {
        const valid = cur && m.events.some((e) => e.id === cur) ? cur : m.events[0]?.id ?? null;
        if (valid) safeStorage.set('hc.event', valid);
        return valid;
      });
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) setMe(null);
      else if (e instanceof ApiError && e.network) {
        // Offline at start-up: keep the last known session for read-only/offline use.
        const cached = safeStorage.get('hc.me');
        if (cached) setMe(JSON.parse(cached));
        setError('Offline — showing the last known session.');
      } else setError(e instanceof Error ? e.message : 'Could not load session.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  useEffect(() => {
    if (me) safeStorage.set('hc.me', JSON.stringify(me));
  }, [me]);

  const setEventId = (id: string) => {
    safeStorage.set('hc.event', id);
    setEventIdState(id);
  };

  const login = async (username: string, password: string) => {
    const { user } = await api.post<{ user: User }>('/api/auth/login', { username, password });
    await refresh();
    return user;
  };

  const logout = async () => {
    try {
      await api.post('/api/auth/logout');
    } finally {
      safeStorage.remove('hc.me');
      setMe(null);
    }
  };

  return <SessionCtx.Provider value={{ me, loading, error, eventId, setEventId, login, logout, refresh }}>{children}</SessionCtx.Provider>;
}

export function useSession() {
  const v = useContext(SessionCtx);
  if (!v) throw new Error('useSession outside provider');
  return v;
}
