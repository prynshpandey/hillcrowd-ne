@echo off
cd /d "%~dp0"
echo Starting HillCrowd NE on http://localhost:4000  (press Ctrl+C to stop)
call npm start
