# HillCrowd NE — Testing

## Commands

| Command | What it runs |
|---|---|
| `npm test` | Vitest: unit tests (risk & trends, routing, resilience, accountability, workflow, offline outbox) and API integration tests (Supertest against an in-memory SQLite database with a controllable clock) |
| `npm run typecheck` | `tsc --noEmit` over shared, server, client and tests |
| `npm run build` | Production client build |
| `npm run test:e2e` | Browser smoke test (`tests/e2e/smoke.ts`) with `playwright-core` against a **running** server. Set `BASE_URL` and `CHROMIUM_PATH` (no browser is downloaded) |

To run the browser smoke test:

```bash
npm run setup && npm start &
BASE_URL=http://localhost:4000 CHROMIUM_PATH=/path/to/chrome npm run test:e2e
```

The browser test resets the demo first, so don't run it against an instance whose demo state you want to keep. Screenshots go to `tests/e2e/screenshots/` (git-ignored).

## Coverage by area

| Area | What is tested |
|---|---|
| **Route resilience** | Single points of failure on the demo venue (the Medical access lane cuts both approved vehicle routes); redundancy counts; first failure → explained detour (extra distance, segments, constraints); second failure → "No approved route available" as a critical gap; second-failure pairs listed only for links without a single point of failure; heavy-rain, required-exit, team-availability and comms-fallback stress tests; **simulation never changes live data**; a clean scenario is never called safe; invalid scenario IDs rejected; stress tests recorded and audited (stewards forbidden); live closures raise an access-gap notification and `MEDICAL_ACCESS_LOST` zone risk |
| **Response accountability** | Severity targets with per-category overrides; the delayed stage and next actor are identified; acceptance and travel are attributed to the responder; reassignment restarts acceptance; closed incidents have no open stage and unreached stages are skipped; an overrunning stage escalates once, naming who must act; after "unable", route feasibility is rechecked for all available teams |
| **Crowd trends** | Rising, stable, falling and unknown trends from timestamped estimates; rapid rise flagged below thresholds; contradictory estimates from different sources flagged, while same-source drift is not |
| **Incident workflow** | Valid submission starts unverified; 7 kinds of invalid reports rejected with messages; the full lifecycle with timestamps; assignment blocked before verification; out-of-order and other-responder updates rejected; decline returns the incident for reassignment; reject/reopen require reasons; history preserved; duplicates flagged and merged without deletion; independent corroboration |
| **Risk engine** | Thresholds; missing data is never treated as "empty"; stale data marked; an unverified report stays unverified; designated critical conditions are not hidden by a low aggregate; egress cut is critical; expired or unknown-validity advisories; pre-event findings |
| **Routing** | Shortest valid route; closures excluded with reasons; no invented routes; mode, access and approval respected; under-review warn/avoid; approved routes invalidated with an alternative |
| **Offline / sync** | Not marked delivered while offline; four display states (saved → waiting → action required → confirmed); last successful sync time; no duplicates on retry, lost responses or concurrent flushes; server idempotency on `clientId` (including cross-user → 409); rejected items not retried; corrupt storage; regression test for the empty-flush bug |
| **Concurrency** | Two simultaneous conflicting transitions on one incident: exactly one succeeds and the other gets 409 |
| **Exercise** | All 9 injects run through normal services, labelled `[SIMULATED]`, audited; required exit blocked → Zone D critical; conflicting estimate flagged; team stood down; repeats refused; stewards forbidden; availability toggles need a reason and are refused mid-assignment |
| **Permissions** | Steward and coordinator restrictions, admin self-role lock, threshold validation, data visibility per role, event isolation, CSRF header |
| **Audit** | UPDATE/DELETE on the audit log and incident history, and DELETE on incidents, rejected by database triggers. This is application-level protection; direct database-file access is outside what the tests can or do claim to prevent |
| **Migration** | A database created with the previous schema gains the new columns on start-up |
| **Demo scenario** | End-to-end steps change the expected records; analytics equal the recorded clock deltas; reset removes only demo data; replayable |
| **Browser (e2e)** | Login and every control-room page, including **Resilience Lab**; full scenario via the demo panel; Resilience Lab first/second failure with the simulation label and single-point-of-failure list; the **Exercise** drawer inject; incident stage timeline; replay plays; mobile steward app offline → "Waiting to sync" → reconnect → "Server confirmed" with last-sync time, and exactly one server copy; responder app; steward 403 on route control; **zero console/page errors** |

## Actual results (this build, 15 Oct 2026, Node 22.22, Linux, Chromium)

| Check | Result |
|---|---|
| `npm run typecheck` | Pass |
| `npm test` | **73 / 73 passed** — routing 9, risk 15, workflow 8, outbox 7, accountability 5, resilience/exercise/robustness 12, api 17 |
| `npm run build` | Pass |
| `npm run test:e2e` against the production build | **24 / 24 checks passed, 0 console/page errors** (desktop 1440×900 and mobile 390×844) |

### Issues found by testing and fixed

1. An empty flush left a stale in-flight promise, so queued offline reports never re-sent (found by the browser test; regression test added).
2. The test bundler rewrote `node:sqlite`; it is now loaded via `createRequire`.
3. New API routes were missing because an insertion point didn't match; caught by the resilience tests (404s) and fixed.
4. Several layout overlaps were fixed: map legend vs. zoom controls, simulation badge vs. tile banner, mini-map labels, and clipped queue columns.

## Not tested / precise limits

- **Map tiles:** the tile servers were unreachable from the test environment, so only the **fallback grid** path was exercised. Real OSM/OpenTopoMap tile display must be checked on the presentation machine.
- **Offline:** tested with Chromium's offline emulation while the page was loaded. It was not tested under real field conditions (weak or intermittent signal, captive portals, long outages, app restarts while offline). The service worker isn't exercised by automated tests.
- **Escalation timing:** tested with a controllable clock, not in real time.
- **Not run at all:** load/performance testing, an accessibility audit beyond semantic markup and non-colour severity cues, and browsers other than Chromium.
